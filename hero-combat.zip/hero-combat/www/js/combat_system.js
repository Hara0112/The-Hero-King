import * as THREE from 'three';
import { HEROES } from './hero_classes.js';

const BOX = new THREE.BoxGeometry(0.18, 0.18, 0.18);
const SPH = new THREE.SphereGeometry(1, 12, 10);
const RING = new THREE.RingGeometry(0.85, 1, 40);
const CARDG = new THREE.BoxGeometry(0.03, 0.7, 0.5);

// Sát thương chỉ được tính trên "host" (G.auth). Mọi máy đều chạy hiệu ứng.
export class Combat {
  constructor(G) { this.G = G; this.proj = []; this.fx = []; this.zones = []; this.mats = {}; this.ac = null; }

  mat(c) { return this.mats[c] || (this.mats[c] = new THREE.MeshBasicMaterial({ color: c })); }

  sfx(k) {
    try {
      const A = this.ac || (this.ac = new (window.AudioContext || window.webkitAudioContext)());
      if (A.state === 'suspended') A.resume();
      const P = {
        melee: [300, 90, .12, 'sawtooth'], projectile: [600, 200, .15, 'square'],
        dash: [200, 700, .2, 'sawtooth'], aoe: [120, 40, .4, 'triangle'],
        buff: [400, 800, .25, 'sine'], heal: [500, 900, .3, 'sine'], hit: [180, 60, .1, 'square']
      }[k] || [300, 100, .1, 'sine'];
      const o = A.createOscillator(), g = A.createGain(), t = A.currentTime;
      o.type = P[3];
      o.frequency.setValueAtTime(P[0], t);
      o.frequency.exponentialRampToValueAtTime(P[1], t + P[2]);
      g.gain.setValueAtTime(0.1, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + P[2]);
      o.connect(g); g.connect(A.destination);
      o.start(t); o.stop(t + P[2]);
    } catch (e) { /* audio không khả dụng */ }
  }

  burst(pos, color, n = 10, sp = 5) {
    if (this.fx.length > 320) return;
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(BOX, this.mat(color));
      m.position.set(pos.x, 1, pos.z);
      const a = Math.random() * 6.283, u = Math.random() * sp;
      this.fx.push({ m, k: 'p', vx: Math.cos(a) * u, vy: 2 + Math.random() * sp, vz: Math.sin(a) * u, life: 0.5 + Math.random() * 0.3 });
      this.G.scene.add(m);
    }
  }

  ring(x, z, color, r, dur = 0.4) {
    const m = new THREE.Mesh(RING, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, 0.1, z); m.scale.setScalar(0.1);
    this.G.scene.add(m);
    this.fx.push({ m, k: 'r', life: dur, max: dur, r });
  }

  crescent(x, z, dx, dz, r, arc) { // vòng cung năng lượng xanh
    const phi = Math.atan2(-dz, dx);
    const m = new THREE.Mesh(new THREE.RingGeometry(r * 0.55, r, 40, 1, phi - arc / 2, arc),
      new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, 0.6, z);
    this.G.scene.add(m); this.fx.push({ m, k: 'c', life: 0.5, max: 0.5, geo: true });
  }

  beam(x, z, dx, dz, len) { // tia chém xuyên
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, len),
      new THREE.MeshBasicMaterial({ color: 0xbff0ff, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending }));
    m.rotation.y = Math.atan2(dx, dz); m.position.set(x + dx * len / 2, 1, z + dz * len / 2);
    this.G.scene.add(m); this.fx.push({ m, k: 'b', life: 0.35, max: 0.35, geo: true });
  }

  holoWall(x, z, dx, dz) { // tường lưới sáng khi đạp tường
    if (!this.gridTex) {
      const c = document.createElement('canvas'); c.width = c.height = 128;
      const g = c.getContext('2d'); g.fillStyle = 'rgba(80,180,255,.28)'; g.fillRect(0, 0, 128, 128);
      g.strokeStyle = '#9fe6ff'; g.lineWidth = 2;
      for (let i = 0; i <= 128; i += 16) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, 128); g.stroke(); g.beginPath(); g.moveTo(0, i); g.lineTo(128, i); g.stroke(); }
      this.gridTex = new THREE.CanvasTexture(c);
    }
    const m = new THREE.Mesh(new THREE.PlaneGeometry(4, 3),
      new THREE.MeshBasicMaterial({ map: this.gridTex, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    m.rotation.y = Math.atan2(-dx, -dz); m.position.set(x, 1.5, z);
    this.G.scene.add(m); this.fx.push({ m, k: 'w', life: 0.7, max: 0.7, geo: true });
  }

  skull(pos) { // đầu lâu bay lên khi bị xử tử
    if (!this.skullTex) {
      const c = document.createElement('canvas'); c.width = c.height = 64;
      const g = c.getContext('2d'); g.font = '48px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('💀', 32, 34);
      this.skullTex = new THREE.CanvasTexture(c);
    }
    const m = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.skullTex, transparent: true, depthTest: false }));
    m.scale.set(1.6, 1.6, 1); m.position.set(pos.x, 2.6, pos.z);
    this.G.scene.add(m); this.fx.push({ m, k: 's', life: 1.2, max: 1.2 });
  }

  warpFx(x, z, r, dur) { // vòng đồng hồ tím xoay dưới đất
    if (!this.clockTex) {
      const c = document.createElement('canvas'); c.width = c.height = 256;
      const g = c.getContext('2d'), grad = g.createRadialGradient(128, 128, 10, 128, 128, 124);
      grad.addColorStop(0, 'rgba(150,80,255,.55)'); grad.addColorStop(1, 'rgba(90,30,180,.25)');
      g.fillStyle = grad; g.beginPath(); g.arc(128, 128, 124, 0, 6.283); g.fill();
      g.strokeStyle = '#ffd36a'; g.lineWidth = 5; g.beginPath(); g.arc(128, 128, 120, 0, 6.283); g.stroke();
      g.lineWidth = 3; g.beginPath(); g.arc(128, 128, 96, 0, 6.283); g.stroke();
      for (let k = 0; k < 12; k++) { const a = (k / 12) * 6.283; g.beginPath(); g.moveTo(128 + Math.sin(a) * 100, 128 - Math.cos(a) * 100); g.lineTo(128 + Math.sin(a) * 116, 128 - Math.cos(a) * 116); g.stroke(); }
      g.lineWidth = 6; g.beginPath(); g.moveTo(128, 128); g.lineTo(128, 50); g.stroke(); g.beginPath(); g.moveTo(128, 128); g.lineTo(190, 150); g.stroke();
      this.clockTex = new THREE.CanvasTexture(c);
    }
    const m = new THREE.Mesh(new THREE.CircleGeometry(1, 48), new THREE.MeshBasicMaterial({ map: this.clockTex, transparent: true, opacity: 0.7, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, 0.08, z); m.scale.setScalar(r);
    this.G.scene.add(m); this.fx.push({ m, k: 'z', life: dur, max: dur, geo: true });
  }

  hourglassFx(x, z) { // đồng hồ cát khổng lồ khi dùng Time Rewind
    const mt = new THREE.MeshBasicMaterial({ color: 0xffd36a, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending });
    const grp = new THREE.Group(), geos = [];
    const part = (geo, px, py, rx) => { geos.push(geo); const q = new THREE.Mesh(geo, mt); q.position.set(px, py, 0); q.rotation.x = rx; grp.add(q); };
    part(new THREE.ConeGeometry(1.2, 1.6, 16), 0, 0.9, Math.PI); part(new THREE.ConeGeometry(1.2, 1.6, 16), 0, -0.9, 0);
    part(new THREE.CylinderGeometry(1.35, 1.35, 0.12, 16), 0, 1.8, 0); part(new THREE.CylinderGeometry(1.35, 1.35, 0.12, 16), 0, -1.8, 0);
    grp.position.set(x, 2.8, z); this.G.scene.add(grp);
    this.fx.push({ m: grp, k: 'h', life: 0.9, max: 0.9, mat: mt, geos });
  }

  dropFx(f) {
    this.G.scene.remove(f.m);
    if (f.k === 'p') return;
    if (f.m.material) f.m.material.dispose();
    if (f.geo) f.m.geometry.dispose();
    if (f.mat) f.mat.dispose();
    if (f.geos) f.geos.forEach(g => g.dispose());
  }

  enemies(p) { return [...this.G.players.values()].filter(t => t.alive && t.team !== p.team); }

  cast(p, i, dx, dz) {
    const G = this.G, H = HEROES[p.hero], s = H.skills[i], col = H.color;
    const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
    p.cd[i] = s.cd; p.oc = 0; p.face = Math.atan2(dx, dz); p.swing = 0.25;
    const px = p.pos.x, pz = p.pos.z, host = G.auth;
    this.sfx({ leap: 'dash', storm: 'aoe', warp: 'aoe', rewind: 'buff' }[s.type] || s.type);

    if (s.type === 'melee') {
      this.ring(px + dx * 1.5, pz + dz * 1.5, col, s.range * 0.6, 0.25);
      this.burst({ x: px + dx * 2, z: pz + dz * 2 }, col, 6, 3);
      if (host) for (const t of this.enemies(p)) {
        const ox = t.pos.x - px, oz = t.pos.z - pz, d = Math.hypot(ox, oz) || 1;
        if (d <= s.range + 0.5 && (ox * dx + oz * dz) / d > Math.cos(s.arc / 2)) this.damage(p, t, s.dmg, s, ox / d, oz / d);
      }
    } else if (s.type === 'projectile') {
      const n = s.count || 1;
      for (let k = 0; k < n; k++) {
        const a = (k - (n - 1) / 2) * (s.spread || 0), c = Math.cos(a), sn = Math.sin(a);
        const vx = dx * c - dz * sn, vz = dx * sn + dz * c;
        let m;
        if (s.card) { // lá bài dẹt, xoay quanh trục bay
          m = new THREE.Mesh(CARDG, this.mat(s.color || col)); m.rotation.order = 'YXZ'; m.rotation.y = Math.atan2(vx, vz); m.scale.setScalar(s.radius * 1.3);
        } else { m = new THREE.Mesh(SPH, this.mat(s.color || col)); m.scale.setScalar(s.radius); }
        m.position.set(px + vx, 1.2, pz + vz);
        G.scene.add(m);
        this.proj.push({ m, o: p, s, vx, vz, life: s.life, card: !!s.card, hits: new Set() });
      }
    } else if (s.type === 'dash') {
      const T = s.dist / s.speed;
      p.dash = { t: T, T, vx: dx * s.speed, vz: dz * s.speed, nx: dx, nz: dz, sk: s, hit: new Set(), kind: s.kick ? 'kick' : 'dash', air: false, h: s.kick ? 0.8 : 0 };
      if (s.rebound) { // đạp tường rồi bật ngược ra sau
        const r = s.rebound, T2 = r.dist / r.speed;
        p.dash.next = { t: T2, T: T2, vx: -dx * r.speed, vz: -dz * r.speed, nx: -dx, nz: -dz, sk: { dmg: 0 }, hit: new Set(), kind: 'rebound', air: true, h: 1.6 };
        setTimeout(() => { if (G.running) { this.holoWall(p.pos.x + dx * 1.2, p.pos.z + dz * 1.2, dx, dz); this.burst(p.pos, 0x9fe0ff, 14, 5); this.sfx('hit'); } }, T * 1000);
      }
      this.ring(px, pz, col, 2, 0.3);
    } else if (s.type === 'leap') { // nhảy mèo: bay qua vật cản, tiếp đất nổ vùng
      const T = s.dist / s.speed;
      p.dash = { t: T, T, vx: dx * s.speed, vz: dz * s.speed, nx: dx, nz: dz, sk: { dmg: 0 }, hit: new Set(), kind: 'leap', air: true, h: 2.2 };
      this.ring(px, pz, col, 2, 0.3);
      setTimeout(() => {
        if (!G.running) return;
        const lx = p.pos.x, lz = p.pos.z;
        this.ring(lx, lz, col, s.radius, 0.45); this.burst({ x: lx, z: lz }, col, 14, s.radius); this.sfx('aoe');
        if (p.alive) p.pose = { k: 'land', t: 0.3 };
        if (!G.auth) return;
        for (const t of this.enemies(p)) {
          const ox = t.pos.x - lx, oz = t.pos.z - lz, d = Math.hypot(ox, oz) || 1;
          if (d <= s.radius + 0.5) this.damage(p, t, s.dmg, s, ox / d, oz / d);
        }
      }, T * 1000);
    } else if (s.type === 'storm') { // Storm Slash: khoanh kiếm -> lao tới -> chém vòng cung -> xử tử
      p.pose = { k: 'cross', t: s.wind };
      this.ring(px, pz, 0x66ccff, 3, s.wind); this.burst(p.pos, 0x66ccff, 10, 3);
      setTimeout(() => {
        if (!G.running) return;
        if (!p.alive || p.stun > 0) { p.pose = null; return; } // bị choáng thì hủy
        const T = s.dist / s.speed;
        p.pose = { k: 'rush', t: T + 0.05 };
        p.dash = { t: T, T, vx: dx * s.speed, vz: dz * s.speed, nx: dx, nz: dz, sk: { dmg: s.rushDmg, stun: 0.4, knock: 3 }, hit: new Set(), kind: 'rush', air: false, h: 0 };
        this.sfx('dash');
        setTimeout(() => {
          if (!G.running || !p.alive) return;
          const fx = p.pos.x, fz = p.pos.z;
          p.pose = { k: 'slash', t: 0.4 };
          this.crescent(fx + dx * 1.5, fz + dz * 1.5, dx, dz, s.range, s.arc);
          this.beam(fx, fz, dx, dz, s.range + 2);
          this.ring(fx + dx * 4, fz + dz * 4, 0x9fe0ff, 3.5, 0.7); this.burst({ x: fx + dx * 4, z: fz + dz * 4 }, 0x9fe0ff, 30, 7); this.sfx('aoe');
          if (!G.auth) return;
          for (const t of this.enemies(p)) {
            const ox = t.pos.x - fx, oz = t.pos.z - fz, d = Math.hypot(ox, oz) || 1;
            if (d <= s.range + 0.5 && (ox * dx + oz * dz) / d > Math.cos(s.arc / 2)) {
              const ex = t.hp <= t.maxhp * s.exec;
              this.damage(p, t, ex ? 99999 : s.dmg, { stun: s.stun, knock: s.knock, exec: ex }, ox / d, oz / d);
            }
          }
        }, T * 1000);
      }, s.wind * 1000);
    } else if (s.type === 'warp') { // Time Warp: vùng xoáy thời gian (chậm địch, tăng tốc đồng đội)
      const zx = px + dx * s.offset, zz = pz + dz * s.offset;
      this.zones.push({ x: zx, z: zz, r: s.radius, t: s.dur, team: p.team, slow: s.slow, haste: s.haste });
      this.warpFx(zx, zz, s.radius, s.dur); this.burst({ x: zx, z: zz }, 0xb06bff, 20, s.radius);
    } else if (s.type === 'rewind') { // Time Rewind: đóng băng địch, quay ngược vị trí + máu, hoàn hồi chiêu
      const e = p.hist && p.hist.length ? p.hist[Math.max(0, p.hist.length - 1 - Math.round(s.back / 0.2))] : null;
      p.pose = { k: 'rewind', t: 0.9 };
      this.hourglassFx(px, pz); this.ring(px, pz, 0xffd36a, s.radius, 0.8); this.ring(px, pz, 0xb06bff, s.radius * 0.6, 1.0);
      for (let q = 0; q < 4; q++) p.cd[q] = 0;
      if (G.auth) for (const t of this.enemies(p)) {
        const ox = t.pos.x - px, oz = t.pos.z - pz, d = Math.hypot(ox, oz) || 1;
        if (d <= s.radius + 0.5) this.damage(p, t, s.dmg, { stun: s.stun, knock: 0 }, ox / d, oz / d);
      }
      setTimeout(() => {
        if (!G.running || !p.alive || !e) return;
        this.ring(p.pos.x, p.pos.z, 0xb06bff, 3, 0.6); this.burst(p.pos, 0xb06bff, 16, 5);
        p.pos.set(e.x, 0, e.z); p.kv = { x: 0, z: 0 }; p.dash = null;
        if (!p.ctl) p.tg = { x: e.x, z: e.z, f: p.face };
        this.ring(e.x, e.z, 0xffd36a, 3, 0.6); this.burst({ x: e.x, z: e.z }, 0xffd36a, 24, 6); this.sfx('heal');
        if (G.auth && e.hp > p.hp) this.heal(p, e.hp - p.hp);
      }, 600);
    } else if (s.type === 'aoe') {
      const cx = px + dx * (s.offset || 0), cz = pz + dz * (s.offset || 0);
      const run = () => {
        this.ring(cx, cz, col, s.radius, 0.5);
        this.burst({ x: cx, z: cz }, col, s.ult ? 30 : 14, s.radius);
        this.sfx('aoe');
        if (!G.auth) return;
        for (const t of this.enemies(p)) {
          const ox = t.pos.x - cx, oz = t.pos.z - cz, d = Math.hypot(ox, oz) || 1;
          if (d <= s.radius + 0.5) this.damage(p, t, s.dmg, s, ox / d, oz / d);
        }
      };
      if (s.delay) { this.ring(cx, cz, 0xff3333, s.radius, s.delay); setTimeout(() => { if (G.running) run(); }, s.delay * 1000); }
      else run();
    } else if (s.type === 'buff') {
      p.buff = { speed: s.speed || 1, dmg: s.dmg || 1, t: s.dur };
      if (s.shield) { p.shield = s.shield; p.shieldT = s.dur; }
      this.ring(px, pz, col, 2, 0.5);
    } else if (s.type === 'heal') {
      this.ring(px, pz, 0x69f0ae, s.radius, 0.6);
      this.burst(p.pos, 0x69f0ae, 16, s.radius);
      if (host) for (const t of G.players.values()) {
        if (!t.alive) continue;
        const ox = t.pos.x - px, oz = t.pos.z - pz, d = Math.hypot(ox, oz) || 1;
        if (d > s.radius) continue;
        if (t.team === p.team) this.heal(t, s.amount);
        else if (s.dmg) this.damage(p, t, s.dmg, s, ox / d, oz / d);
      }
    }
  }

  heal(t, n) {
    if (!t.alive) return;
    t.hp = Math.min(t.maxhp, t.hp + n);
    const m = { t: 'hit', id: t.id, hp: Math.round(t.hp), dmg: -n, stun: 0, kx: 0, kz: 0 };
    if (this.G.net) this.G.net.bcast(m);
    this.applyHit(m);
  }

  zoneHit(t, a) {
    if (!this.G.auth || !t.alive) return;
    t.hp = Math.max(0, t.hp - a);
    const m = { t: 'hit', id: t.id, hp: Math.round(t.hp), dmg: Math.round(a), stun: 0, kx: 0, kz: 0, zone: true };
    if (this.G.net) this.G.net.bcast(m);
    this.applyHit(m);
    if (t.hp <= 0) this.G.kill(t, null);
  }

  damage(src, t, dmg, s, dx, dz) {
    const G = this.G;
    if (!G.auth || !t.alive) return;
    let a = dmg * (1 - (HEROES[t.hero].dr || 0)) * ((src.buff && src.buff.dmg) || 1);
    if (t.shield > 0) { const b = Math.min(t.shield, a); t.shield -= b; a -= b; }
    t.hp = Math.max(0, t.hp - a);
    const m = { t: 'hit', id: t.id, hp: Math.round(t.hp), dmg: Math.round(a), stun: s.stun || 0, kx: dx * (s.knock || 0), kz: dz * (s.knock || 0), sid: src.id, exec: !!s.exec };
    const ls = HEROES[src.hero].ls;
    if (ls && a > 0) { src.hp = Math.min(src.maxhp, src.hp + a * ls); m.shp = Math.round(src.hp); }
    const cu = HEROES[src.hero].curse;
    if (cu && a > 0) { m.cs = cu.dur; m.cm = cu.mult; }
    if (G.net) G.net.bcast(m);
    this.applyHit(m);
    if (t.hp <= 0) G.kill(t, src);
  }

  applyHit(m) {
    const t = this.G.players.get(m.id);
    if (!t) return;
    t.hp = m.hp;
    if (m.dmg > 0) {
      if (!m.zone) t.oc = 0;
      if (m.stun > t.stun) t.stun = m.stun;
      if (t.ctl) { t.kv.x += m.kx; t.kv.z += m.kz; }
      this.burst(t.pos, 0xff5252, 8, 4); this.sfx('hit');
      if (m.exec) this.skull(t.pos);
      if (m.cs) { t.slow = { m: m.cm, t: m.cs }; this.burst(t.pos, 0xb06bff, 6, 3); }
    } else if (m.dmg < 0) this.burst(t.pos, 0x69f0ae, 6, 2);
    if (m.sid && m.shp) { const s = this.G.players.get(m.sid); if (s) s.hp = m.shp; }
  }

  update(dt) {
    const G = this.G;
    for (let i = this.zones.length - 1; i >= 0; i--) if ((this.zones[i].t -= dt) <= 0) this.zones.splice(i, 1);
    // Đạn
    for (let i = this.proj.length - 1; i >= 0; i--) {
      const q = this.proj[i], s = q.s;
      q.m.position.x += q.vx * s.speed * dt; q.m.position.z += q.vz * s.speed * dt;
      q.life -= dt;
      if (q.card) q.m.rotation.z += dt * 14;
      if (Math.random() < 0.4) this.burst({ x: q.m.position.x, z: q.m.position.z }, s.color || HEROES[q.o.hero].color, 1, 0.5);
      let hit = false;
      const wall = G.hitsWall && G.hitsWall(q.m.position.x, q.m.position.z);
      if (G.auth && !wall) for (const t of this.enemies(q.o)) {
        if (Math.hypot(t.pos.x - q.m.position.x, t.pos.z - q.m.position.z) < s.radius + 0.7) {
          const d = Math.hypot(q.vx, q.vz) || 1;
          if (s.pierce) {
            if (q.hits.has(t.id)) continue;
            q.hits.add(t.id); this.burst({ x: t.pos.x, z: t.pos.z }, s.color || 0xffffff, 8, 4);
            this.damage(q.o, t, s.dmg, s, q.vx / d, q.vz / d);
          } else { this.damage(q.o, t, s.dmg, s, q.vx / d, q.vz / d); hit = true; break; }
        }
      }
      if (hit || wall || q.life <= 0) {
        if (hit || wall) this.burst({ x: q.m.position.x, z: q.m.position.z }, s.color || 0xffffff, 8, 4);
        G.scene.remove(q.m); this.proj.splice(i, 1);
      }
    }
    // Sát thương khi lướt (host)
    if (G.auth) for (const p of G.players.values()) {
      const d = p.dash;
      if (!d || !d.sk.dmg || !p.alive) continue;
      for (const t of this.enemies(p)) {
        if (d.hit.has(t.id)) continue;
        if (Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z) < 1.8) { d.hit.add(t.id); this.damage(p, t, d.sk.dmg, d.sk, d.nx, d.nz); }
      }
    }
    for (const p of G.players.values()) if (p.dash && Math.random() < 0.7) this.burst(p.pos, HEROES[p.hero].color, 1, 1);
    // Hiệu ứng
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.life -= dt;
      if (f.k === 'p') { f.vy -= 12 * dt; f.m.position.x += f.vx * dt; f.m.position.y += f.vy * dt; f.m.position.z += f.vz * dt; if (f.m.position.y < 0.05) f.m.position.y = 0.05; }
      else {
        const k = 1 - f.life / f.max;
        if (f.k === 'r') { f.m.scale.setScalar(f.r * k + 0.1); f.m.material.opacity = 0.8 * (1 - k); }
        else if (f.k === 'c') { f.m.scale.setScalar(0.7 + 0.5 * k); f.m.material.opacity = 0.9 * (1 - k); }
        else if (f.k === 'b') { f.m.scale.set(1 - k * 0.8, 1 - k * 0.8, 1); f.m.material.opacity = 0.9 * (1 - k); }
        else if (f.k === 'w') f.m.material.opacity = 0.8 * Math.min(1, (1 - k) * 2);
        else if (f.k === 's') { f.m.position.y += dt * 1.5; f.m.material.opacity = Math.min(1, (1 - k) * 1.6); }
        else if (f.k === 'z') { f.m.rotation.z += dt * 0.6; f.m.material.opacity = 0.7 * Math.min(1, f.life * 2, (f.max - f.life) * 5); }
        else if (f.k === 'h') { f.m.rotation.y += dt * 2.5; f.m.position.y = 2.8 + k * 0.8; f.mat.opacity = 0.85 * Math.min(1, (1 - k) * 2, k * 6); }
      }
      if (f.life <= 0) { this.dropFx(f); this.fx.splice(i, 1); }
    }
  }

  reset() {
    for (const q of this.proj) this.G.scene.remove(q.m);
    for (const f of this.fx) this.dropFx(f);
    this.zones = [];
    this.proj = []; this.fx = [];
  }
}
