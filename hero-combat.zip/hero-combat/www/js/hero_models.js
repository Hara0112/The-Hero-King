import * as THREE from 'three';
import { HEROES } from './hero_classes.js';

// ---------- Công cụ dựng mô hình: gộp các khối cùng vật liệu thành 1 mesh để nhẹ cho điện thoại ----------
const M4 = new THREE.Matrix4(), QT = new THREE.Quaternion(), EU = new THREE.Euler(), V3 = new THREE.Vector3(), S3 = new THREE.Vector3(1, 1, 1);

function mergeGeos(list) {
  const gs = list.map(g => (g.index ? g.toNonIndexed() : g));
  let n = 0; for (const g of gs) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3);
  let o = 0;
  for (const g of gs) {
    pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3);
    o += g.attributes.position.count;
  }
  const r = new THREE.BufferGeometry();
  r.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  r.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  return r;
}

class Limb {
  constructor(x = 0, y = 0, z = 0) { this.g = new THREE.Group(); this.g.position.set(x, y, z); this.b = new Map(); }
  put(geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
    EU.set(rx, ry, rz); QT.setFromEuler(EU); V3.set(x, y, z);
    M4.compose(V3, QT, S3); geo.applyMatrix4(M4);
    if (!this.b.has(mat)) this.b.set(mat, []);
    this.b.get(mat).push(geo); return this;
  }
  box(w, h, d, mat, x, y, z, rx, ry, rz) { return this.put(new THREE.BoxGeometry(w, h, d), mat, x, y, z, rx, ry, rz); }
  cyl(rt, rb, h, seg, mat, x, y, z, rx, ry, rz) { return this.put(new THREE.CylinderGeometry(rt, rb, h, seg), mat, x, y, z, rx, ry, rz); }
  sph(r, mat, x, y, z, sx = 1, sy = 1, sz = 1) { const g = new THREE.SphereGeometry(r, 12, 10); g.scale(sx, sy, sz); return this.put(g, mat, x, y, z); }
  done(parent) {
    for (const [m, l] of this.b) this.g.add(new THREE.Mesh(mergeGeos(l), m));
    this.b.clear(); if (parent) parent.add(this.g); return this.g;
  }
}

const mat = (color, rough = 0.5, metal = 0.3, emissive = 0x000000, ei = 1) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, emissive, emissiveIntensity: ei });

// ======================= ASASIN – ninja công nghệ mặt nạ sọ =======================
function asasin() {
  const carbon = mat(0x16181d, 0.4, 0.7), dark = mat(0x0b0d12, 0.6, 0.5), steel = mat(0x4a5058, 0.35, 0.8);
  const navy = mat(0x141c3c, 0.9, 0), bone = mat(0xb9bec4, 0.7, 0.1);
  const neon = mat(0x2aa8ff, 0.3, 0.2, 0x2aa8ff, 1.8), orange = mat(0xff7a1a, 0.4, 0.2, 0xff6a00, 1.3);
  const blade = mat(0x9fe0ff, 0.2, 0.1, 0x6ccaff, 2.2);
  const flash = [carbon, dark, steel];
  const rot = new THREE.Group(), root = new THREE.Group();
  root.scale.setScalar(0.92); rot.add(root);

  // --- Thân (gốc ở hông, cao 1.0) ---
  const torso = new Limb(0, 1.0, 0);
  torso.box(0.62, 0.3, 0.38, dark, 0, 0.15, 0).box(0.98, 0.6, 0.52, carbon, 0, 0.62, 0).box(0.8, 0.2, 0.46, carbon, 0, 0.98, 0)
    .box(0.7, 0.1, 0.42, steel, 0, 0.05, 0).box(0.12, 0.08, 0.04, orange, 0, 0.05, 0.22)
    .box(0.06, 0.5, 0.03, neon, -0.2, 0.66, 0.27, 0, 0, 0.45).box(0.06, 0.5, 0.03, neon, 0.2, 0.66, 0.27, 0, 0, -0.45)
    .box(0.5, 0.04, 0.03, neon, 0, 0.92, 0.27)
    .box(0.08, 0.06, 0.03, orange, -0.42, 0.86, 0.27).box(0.08, 0.06, 0.03, orange, 0.42, 0.86, 0.27)
    .box(0.22, 0.07, 0.04, steel, 0, 0.08, 0.2).box(0.22, 0.07, 0.04, steel, 0, 0.17, 0.2).box(0.22, 0.07, 0.04, steel, 0, 0.26, 0.2)
    .cyl(0.15, 0.17, 0.18, 8, dark, 0, 1.09, 0)
    // ba lô + đường neon sau lưng
    .box(0.55, 0.6, 0.22, carbon, 0, 0.7, -0.36).box(0.04, 0.45, 0.02, neon, 0, 0.7, -0.48).box(0.3, 0.08, 0.02, steel, 0, 0.52, -0.48);
  // katana đeo chéo sau lưng
  const ang = -0.62, dx = -Math.sin(ang), dy = Math.cos(ang);
  const kx = 0, ky = 0.75, kz = -0.52;
  const kb = new Limb(0, 0, 0); // katana sau lưng (ẩn khi rút ra)
  kb.box(0.07, 1.35, 0.07, dark, kx, ky, kz, 0, 0, ang)
    .cyl(0.035, 0.035, 0.36, 6, dark, kx + dx * 0.86, ky + dy * 0.86, kz, 0, 0, ang)
    .cyl(0.09, 0.09, 0.02, 10, steel, kx + dx * 0.68, ky + dy * 0.68, kz, 0, 0, ang)
    .cyl(0.04, 0.04, 0.05, 6, neon, kx + dx * 0.78, ky + dy * 0.78, kz, 0, 0, ang)
    .cyl(0.04, 0.04, 0.05, 6, neon, kx + dx * 0.94, ky + dy * 0.94, kz, 0, 0, ang)
    .box(0.03, 0.18, 0.02, neon, kx + dx * 1.1, ky + dy * 1.1 - 0.05, kz);
  kb.done(torso.g);

  // --- Đầu: mũ giáp + mặt nạ sọ mắt xanh + tai nghe ---
  const head = new Limb(0, 1.1, 0);
  head.sph(0.3, carbon, 0, 0.17, 0, 1, 1.05, 1.1).box(0.04, 0.03, 0.5, neon, 0, 0.48, -0.02)
    .sph(0.2, bone, 0, 0.14, 0.2, 1, 1.15, 0.8)
    .box(0.09, 0.075, 0.06, dark, -0.085, 0.2, 0.34).box(0.09, 0.075, 0.06, dark, 0.085, 0.2, 0.34)
    .box(0.075, 0.045, 0.03, neon, -0.085, 0.2, 0.37, 0, 0, 0.3).box(0.075, 0.045, 0.03, neon, 0.085, 0.2, 0.37, 0, 0, -0.3)
    .box(0.04, 0.05, 0.03, dark, 0, 0.11, 0.36)
    .box(0.17, 0.07, 0.05, bone, 0, 0.03, 0.3)
    .box(0.012, 0.06, 0.02, dark, -0.04, 0.03, 0.33).box(0.012, 0.06, 0.02, dark, 0, 0.03, 0.33).box(0.012, 0.06, 0.02, dark, 0.04, 0.03, 0.33)
    .cyl(0.09, 0.09, 0.08, 10, carbon, -0.3, 0.17, 0, 0, 0, Math.PI / 2).cyl(0.09, 0.09, 0.08, 10, carbon, 0.3, 0.17, 0, 0, 0, Math.PI / 2)
    .cyl(0.06, 0.06, 0.1, 10, neon, -0.3, 0.17, 0, 0, 0, Math.PI / 2).cyl(0.06, 0.06, 0.1, 10, neon, 0.3, 0.17, 0, 0, 0, Math.PI / 2)
    // khăn quàng cổ xanh navy
    .put(new THREE.TorusGeometry(0.26, 0.1, 6, 14), navy, 0, 0, 0, Math.PI / 2, 0, 0)
    .box(0.5, 0.28, 0.12, navy, 0, -0.08, 0.2, -0.3, 0, 0).box(0.06, 0.04, 0.02, neon, 0.12, -0.05, 0.27);
  head.done(torso.g);

  // --- Đuôi khăn bay phấp phới (4 đoạn nối nhau) ---
  const tailBase = new THREE.Group(); tailBase.position.set(0, 1.02, -0.3); torso.g.add(tailBase);
  const tail = []; let pg = tailBase;
  for (let i = 0; i < 4; i++) {
    const s = new Limb(0, 0, i ? -0.34 : 0);
    s.box(0.24 - 0.03 * i, 0.05, 0.34, navy, 0, 0, -0.17).box(0.02, 0.055, 0.34, neon, 0.11 - 0.015 * i, 0, -0.17);
    s.done(pg); pg = s.g; tail.push(s.g);
  }

  // --- Tay: giáp vai cam/xanh, bao tay và lưỡi kiếm năng lượng ---
  const arms = [], fores = [];
  for (const s of [-1, 1]) {
    const arm = new Limb(s * 0.66, 0.88, 0);
    arm.box(0.45, 0.32, 0.52, carbon, 0, 0.08, 0).box(0.5, 0.1, 0.56, steel, 0, -0.12, 0).box(0.4, 0.025, 0.03, neon, 0, 0.25, 0.2)
      .box(0.06, 0.05, 0.04, orange, s * 0.17, 0.1, 0.27).cyl(0.12, 0.1, 0.5, 8, dark, 0, -0.4, 0).box(0.24, 0.2, 0.26, carbon, 0, -0.68, 0);
    const fore = new Limb(0, -0.68, 0);
    fore.box(0.26, 0.5, 0.28, carbon, 0, -0.3, 0).box(0.025, 0.38, 0.22, neon, s * 0.135, -0.3, 0).box(0.2, 0.1, 0.03, neon, 0, -0.28, 0.15)
      .box(0.2, 0.2, 0.22, dark, 0, -0.62, 0).box(0.22, 0.05, 0.24, steel, 0, -0.54, 0)
      .put(new THREE.ConeGeometry(0.06, 0.95, 4), blade, 0, -1.06, 0, Math.PI, Math.PI / 4, 0);
    fore.done(arm.g); arm.done(torso.g);
    arm.g.rotation.z = s * 0.1; fore.g.rotation.x = -0.25;
    arms.push(arm.g); fores.push(fore.g);
  }
  // katana cầm tay phải (chỉ hiện khi dùng Bão Kiếm Chém)
  const bladeS = mat(0xcfe8ff, 0.2, 0.9, 0x3a7bd5, 0.6);
  const kh = new Limb(0, -0.62, 0);
  kh.cyl(0.035, 0.035, 0.34, 6, dark, 0, -0.05, 0).cyl(0.09, 0.09, 0.02, 10, steel, 0, -0.24, 0).box(0.045, 1.2, 0.012, bladeS, 0, -0.84, 0)
    .box(0.012, 1.2, 0.03, neon, 0, -0.84, 0).put(new THREE.ConeGeometry(0.03, 0.14, 4), bladeS, 0, -1.5, 0, Math.PI, Math.PI / 4, 0);
  kh.done(fores[1]); kh.g.visible = false;
  torso.done(root);

  // --- Chân ---
  const legs = [];
  for (const s of [-1, 1]) {
    const leg = new Limb(s * 0.22, 1.0, 0);
    leg.box(0.34, 0.5, 0.38, carbon, 0, -0.25, 0).box(0.38, 0.16, 0.42, steel, 0, -0.04, 0)
      .box(0.025, 0.4, 0.1, neon, s * 0.18, -0.26, 0).box(0.05, 0.08, 0.03, orange, s * 0.1, -0.1, 0.21);
    const knee = new Limb(0, -0.5, 0);
    knee.box(0.3, 0.2, 0.34, carbon, 0, 0, 0.04).box(0.05, 0.1, 0.03, orange, 0, 0, 0.22).box(0.3, 0.4, 0.32, carbon, 0, -0.22, 0)
      .box(0.02, 0.32, 0.18, neon, s * 0.16, -0.22, 0.02).box(0.28, 0.26, 0.12, steel, 0, -0.2, -0.15)
      .box(0.34, 0.1, 0.36, steel, 0, -0.36, 0).box(0.32, 0.14, 0.56, dark, 0, -0.43, 0.1);
    knee.done(leg.g); leg.done(root);
    legs.push({ hip: leg.g, knee: knee.g });
  }

  // --- Hoạt ảnh: chạy, nhảy mèo, đạp tường, khoanh kiếm, chém vòng cung ---
  let T = 0;
  const update = (p, dt) => {
    T += dt;
    const mv = p.moving ? 1 : 0, boost = p.oc > 4 || (p.buff && p.buff.speed > 1.5) ? 1 : 0;
    const st = Math.sin(p.bob) * mv, d = p.dash, pose = p.pose, amp = 0.9 + 0.3 * boost, lean = mv * (0.2 + 0.25 * boost);
    rot.position.y = 0;
    legs[0].hip.rotation.set(st * amp, 0, 0); legs[1].hip.rotation.set(-st * amp, 0, 0);
    legs[0].knee.rotation.x = Math.max(0, st) * 1.1; legs[1].knee.rotation.x = Math.max(0, -st) * 1.1;
    arms[0].rotation.set(-st * 0.9 - 0.15 * mv, 0, -0.1); arms[1].rotation.set(st * 0.9 - 0.15 * mv, 0, 0.1);
    fores[0].rotation.x = fores[1].rotation.x = -0.25 - 0.9 * mv;
    torso.g.rotation.set(lean, 0, 0); torso.g.scale.y = 1 + Math.sin(T * 2) * 0.012;
    head.g.rotation.set(-lean * 0.7 + (p.stun > 0 ? 0.45 : 0), 0, 0);
    let glow = 0, useK = false;

    if (d && (d.kind === 'leap' || d.kind === 'rebound')) { // nhảy mèo: co chân, vung tay, bay lên cao
      const k = Math.min(1, 1 - d.t / d.T), tk = Math.sin(k * Math.PI);
      legs[0].hip.rotation.x = -1.3 * tk - 0.1; legs[1].hip.rotation.x = -0.8 * tk;
      legs[0].knee.rotation.x = 1.6 * tk; legs[1].knee.rotation.x = 1.3 * tk;
      arms[0].rotation.set(-0.6 - 0.6 * tk, 0, -0.1); arms[1].rotation.set(0.5 * tk, 0, 0.1);
      fores[0].rotation.x = fores[1].rotation.x = -1.2;
      torso.g.rotation.x = 0.3 + 0.3 * tk; rot.position.y = tk * (d.h || 2); glow = 1;
    } else if (d && d.kind === 'kick') { // đạp tường: người ngang, một chân đá thẳng
      const tk = Math.sin(Math.min(1, 1 - d.t / d.T) * Math.PI);
      torso.g.rotation.x = 0.9; legs[0].hip.rotation.x = -1.5; legs[0].knee.rotation.x = 0;
      legs[1].hip.rotation.x = 0.5; legs[1].knee.rotation.x = 1.0;
      arms[0].rotation.x = arms[1].rotation.x = 0.9; rot.position.y = tk * (d.h || 0.8); glow = 1;
    } else if (d && d.kind === 'rush') { // lao tới cầm katana
      const s2 = Math.sin(T * 22);
      torso.g.rotation.x = 0.6; legs[0].hip.rotation.x = s2 * 0.9; legs[1].hip.rotation.x = -s2 * 0.9;
      legs[0].knee.rotation.x = Math.max(0, s2); legs[1].knee.rotation.x = Math.max(0, -s2);
      arms[1].rotation.set(1.0, 0, 0.1); fores[1].rotation.x = -0.3; arms[0].rotation.set(-0.5, 0, -0.1);
      useK = true; glow = 2;
    } else if (d) { // lướt thường
      torso.g.rotation.x = 0.55; arms[0].rotation.x = arms[1].rotation.x = 0.9;
      legs[0].hip.rotation.x = 0.6; legs[1].hip.rotation.x = -0.6; glow = 1;
    }

    if (pose) {
      if (pose.k === 'cross') { // khoanh hai lưỡi kiếm chéo trước ngực, dang chân
        legs[0].hip.rotation.set(-0.2, 0, -0.25); legs[1].hip.rotation.set(-0.2, 0, 0.25);
        legs[0].knee.rotation.x = legs[1].knee.rotation.x = 0.5;
        arms[0].rotation.set(-1.25, 0, 0.95); arms[1].rotation.set(-1.25, 0, -0.95);
        fores[0].rotation.x = fores[1].rotation.x = -1.5; torso.g.rotation.x = -0.1; glow = 3;
      } else if (pose.k === 'slash') { // chém từ trên đầu xuống
        const k = Math.min(1, Math.max(0, 1 - pose.t / 0.4));
        arms[1].rotation.set(-3.0 + 2.3 * k, 0, 0.1); fores[1].rotation.x = -0.4; arms[0].rotation.set(-0.9, 0, -0.1);
        torso.g.rotation.set(0.1 + 0.3 * k, 0.5 * (1 - k), 0);
        legs[0].hip.rotation.x = -0.7; legs[0].knee.rotation.x = 0.5; legs[1].hip.rotation.x = 0.5; legs[1].knee.rotation.x = 0.3;
        useK = true; glow = 4;
      } else if (pose.k === 'land') { // tiếp đất kiểu lunge
        torso.g.rotation.x = 0.45; legs[0].hip.rotation.x = -0.9; legs[0].knee.rotation.x = 0.6;
        legs[1].hip.rotation.x = 0.7; legs[1].knee.rotation.x = 0.2;
        arms[0].rotation.set(-0.5, 0, -0.1); arms[1].rotation.set(0.7, 0, 0.1);
      }
    } else if (p.swing > 0 && !d) { // chém thường: tay phải rồi tay trái
      const k = 1 - p.swing / 0.25, r1 = Math.sin(Math.min(1, k) * Math.PI), r2 = Math.sin(Math.min(1, Math.max(0, k * 1.3 - 0.15)) * Math.PI);
      arms[1].rotation.x = -2.3 * r1; fores[1].rotation.x = -0.25 - 0.6 * r1;
      arms[0].rotation.x = -1.8 * r2; fores[0].rotation.x = -0.25 - 0.5 * r2;
      torso.g.rotation.y = 0.6 * (r1 - r2); glow = 1;
    }

    kb.g.visible = !useK; kh.g.visible = useK;
    const run = mv || d ? 1 : 0;
    for (let i = 0; i < tail.length; i++) { // khăn bay dài ra sau khi chạy/lao
      tail[i].rotation.y = Math.sin(T * 5 + i * 0.8) * 0.35 * (0.5 + run);
      tail[i].rotation.x = (run ? 0.02 : 0.2) + Math.sin(T * 4 + i) * 0.12;
    }
    neon.emissiveIntensity = 1.5 + 0.4 * Math.sin(T * 3) + glow * 0.5;
    blade.emissiveIntensity = 2 + glow;
  };
  return { rot, flash, update };
}

// ======================= Mô hình mặc định cho hero chưa có skin =======================
function generic(key) {
  const H = HEROES[key] || { color: 0xcccccc };
  const m = mat(H.color, 0.6, 0.2), rot = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.45, 0.9, 4, 10), m); body.position.y = 1; rot.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), mat(0xffd7b0)); head.position.y = 1.95; rot.add(head);
  return { rot, flash: [m], update: (p) => { rot.position.y = p.moving ? Math.abs(Math.sin(p.bob)) * 0.1 : 0; } };
}

// Trả về { rot, flash, update(p, dt) } – mỗi người chơi có bộ vật liệu riêng
export function buildModel(key) { return key === 'asasin' ? asasin() : generic(key); }
