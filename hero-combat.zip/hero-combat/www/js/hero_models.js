import * as THREE from 'three';
import { HEROES } from './hero_classes.js';

// ---------- Công cụ dựng mô hình: gộp các khối cùng vật liệu thành 1 mesh để nhẹ cho điện thoại ----------
const M4 = new THREE.Matrix4(), QT = new THREE.Quaternion(), EU = new THREE.Euler(), V3 = new THREE.Vector3(), S3 = new THREE.Vector3(1, 1, 1);

function mergeGeos(list) {
  const gs = list.map(g => (g.index ? g.toNonIndexed() : g));
  let n = 0; for (const g of gs) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3);
  let o = 0;
  for (const g of gs) {
    pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3);
    o += g.attributes.position.count;
  }
  const r = new THREE.BufferGeometry();
  r.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  r.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  return r;
}

class Limb {
  constructor(x = 0, y = 0, z = 0) { this.g = new THREE.Group(); this.g.position.set(x, y, z); this.b = new Map(); }
  put(geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
    EU.set(rx, ry, rz); QT.setFromEuler(EU); V3.set(x, y, z);
    M4.compose(V3, QT, S3); geo.applyMatrix4(M4);
    if (!this.b.has(mat)) this.b.set(mat, []);
    this.b.get(mat).push(geo); return this;
  }
  box(w, h, d, mat, x, y, z, rx, ry, rz) { return this.put(new THREE.BoxGeometry(w, h, d), mat, x, y, z, rx, ry, rz); }
  cyl(rt, rb, h, seg, mat, x, y, z, rx, ry, rz) { return this.put(new THREE.CylinderGeometry(rt, rb, h, seg), mat, x, y, z, rx, ry, rz); }
  sph(r, mat, x, y, z, sx = 1, sy = 1, sz = 1) { const g = new THREE.SphereGeometry(r, 12, 10); g.scale(sx, sy, sz); return this.put(g, mat, x, y, z); }
  done(parent) {
    const all = [];
    for (const [m, l] of this.b) { this.g.add(new THREE.Mesh(mergeGeos(l), m)); if (!m.transparent) all.push(...l); }
    if (all.length) this.g.add(new THREE.Mesh(smoothNormals(mergeGeos(all)), OUTLINE)); // viền đen kiểu hoạt hình
    this.b.clear(); if (parent) parent.add(this.g); return this.g;
  }
}

// ---- Phong cách "mobile MOBA": đổ bóng 3 bậc (cel-shading), viền đen quanh nhân vật, rim-light màu hero ----
const GRAD = (() => { const t = new THREE.DataTexture(new Uint8Array([85, 165, 255]), 3, 1, THREE.RedFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
let RIM = 0x2aa8ff; // màu ánh sáng viền của hero đang dựng
const mat = (color, rough = 0.5, metal = 0.3, emissive = 0x000000, ei = 1) => {
  const m = new THREE.MeshToonMaterial({ color, gradientMap: GRAD, emissive, emissiveIntensity: ei });
  const rim = new THREE.Color(RIM);
  m.onBeforeCompile = sh => {
    sh.uniforms.rimC = { value: rim };
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 rimC;')
      .replace('#include <opaque_fragment>', 'outgoingLight += rimC * pow(1.0 - saturate(dot(normalize(normal), normalize(vViewPosition))), 3.0) * 0.7;\n#include <opaque_fragment>');
  };
  return m;
};
const OUTLINE = new THREE.MeshBasicMaterial({ color: 0x07080d, side: THREE.BackSide });
OUTLINE.onBeforeCompile = sh => { sh.vertexShader = sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n  transformed += normalize(normal) * 0.022;'); };

// làm mịn pháp tuyến theo vị trí đỉnh để viền không bị hở ở góc khối hộp
function smoothNormals(g) {
  const pos = g.attributes.position.array, nor = g.attributes.normal.array, map = new Map(), keys = [];
  for (let i = 0; i < pos.length; i += 3) {
    const k = Math.round(pos[i] * 400) + ',' + Math.round(pos[i + 1] * 400) + ',' + Math.round(pos[i + 2] * 400);
    keys.push(k);
    let e = map.get(k); if (!e) { e = [0, 0, 0]; map.set(k, e); }
    e[0] += nor[i]; e[1] += nor[i + 1]; e[2] += nor[i + 2];
  }
  const out = new Float32Array(nor.length);
  for (let i = 0, j = 0; i < pos.length; i += 3, j++) {
    const e = map.get(keys[j]), l = Math.hypot(e[0], e[1], e[2]) || 1;
    out[i] = e[0] / l; out[i + 1] = e[1] / l; out[i + 2] = e[2] / l;
  }
  const r = new THREE.BufferGeometry();
  r.setAttribute('position', g.attributes.position); r.setAttribute('normal', new THREE.BufferAttribute(out, 3));
  return r;
}

// ======================= ASASIN – ninja công nghệ mặt nạ sọ =======================
function asasin() {
  RIM = 0x39b6ff;
  const carbon = mat(0x16181d, 0.4, 0.7), dark = mat(0x0b0d12, 0.6, 0.5), steel = mat(0x4a5058, 0.35, 0.8);
  const navy = mat(0x141c3c, 0.9, 0), bone = mat(0xb9bec4, 0.7, 0.1);
  const neon = mat(0x2aa8ff, 0.3, 0.2, 0x2aa8ff, 1.8), orange = mat(0xff7a1a, 0.4, 0.2, 0xff6a00, 1.3);
  const blade = mat(0x9fe0ff, 0.2, 0.1, 0x6ccaff, 2.2);
  const flash = [carbon, dark, steel];
  const rot = new THREE.Group(), root = new THREE.Group();
  root.scale.setScalar(0.92); rot.add(root);

  // --- Thân (gốc ở hông, cao 1.0) ---
  const torso = new Limb(0, 1.0, 0);
  torso.box(0.62, 0.3, 0.38, dark, 0, 0.15, 0).box(0.98, 0.6, 0.52, carbon, 0, 0.62, 0).box(0.8, 0.2, 0.46, carbon, 0, 0.98, 0)
    .box(0.7, 0.1, 0.42, steel, 0, 0.05, 0).box(0.12, 0.08, 0.04, orange, 0, 0.05, 0.22)
    .box(0.06, 0.5, 0.03, neon, -0.2, 0.66, 0.27, 0, 0, 0.45).box(0.06, 0.5, 0.03, neon, 0.2, 0.66, 0.27, 0, 0, -0.45)
    .box(0.5, 0.04, 0.03, neon, 0, 0.92, 0.27)
    .box(0.08, 0.06, 0.03, orange, -0.42, 0.86, 0.27).box(0.08, 0.06, 0.03, orange, 0.42, 0.86, 0.27)
    .box(0.22, 0.07, 0.04, steel, 0, 0.08, 0.2).box(0.22, 0.07, 0.04, steel, 0, 0.17, 0.2).box(0.22, 0.07, 0.04, steel, 0, 0.26, 0.2)
    .cyl(0.15, 0.17, 0.18, 8, dark, 0, 1.09, 0)
    // ba lô + đường neon sau lưng
    .box(0.55, 0.6, 0.22, carbon, 0, 0.7, -0.36).box(0.04, 0.45, 0.02, neon, 0, 0.7, -0.48).box(0.3, 0.08, 0.02, steel, 0, 0.52, -0.48);
  // katana đeo chéo sau lưng
  const ang = -0.62, dx = -Math.sin(ang), dy = Math.cos(ang);
  const kx = 0, ky = 0.75, kz = -0.52;
  const kb = new Limb(0, 0, 0); // katana sau lưng (ẩn khi rút ra)
  kb.box(0.07, 1.35, 0.07, dark, kx, ky, kz, 0, 0, ang)
    .cyl(0.035, 0.035, 0.36, 6, dark, kx + dx * 0.86, ky + dy * 0.86, kz, 0, 0, ang)
    .cyl(0.09, 0.09, 0.02, 10, steel, kx + dx * 0.68, ky + dy * 0.68, kz, 0, 0, ang)
    .cyl(0.04, 0.04, 0.05, 6, neon, kx + dx * 0.78, ky + dy * 0.78, kz, 0, 0, ang)
    .cyl(0.04, 0.04, 0.05, 6, neon, kx + dx * 0.94, ky + dy * 0.94, kz, 0, 0, ang)
    .box(0.03, 0.18, 0.02, neon, kx + dx * 1.1, ky + dy * 1.1 - 0.05, kz);
  kb.done(torso.g);

  // --- Đầu: mũ giáp + mặt nạ sọ mắt xanh + tai nghe ---
  const head = new Limb(0, 1.1, 0);
  head.sph(0.3, carbon, 0, 0.17, 0, 1, 1.05, 1.1).box(0.04, 0.03, 0.5, neon, 0, 0.48, -0.02)
    .sph(0.2, bone, 0, 0.14, 0.2, 1, 1.15, 0.8)
    .box(0.09, 0.075, 0.06, dark, -0.085, 0.2, 0.34).box(0.09, 0.075, 0.06, dark, 0.085, 0.2, 0.34)
    .box(0.075, 0.045, 0.03, neon, -0.085, 0.2, 0.37, 0, 0, 0.3).box(0.075, 0.045, 0.03, neon, 0.085, 0.2, 0.37, 0, 0, -0.3)
    .box(0.04, 0.05, 0.03, dark, 0, 0.11, 0.36)
    .box(0.17, 0.07, 0.05, bone, 0, 0.03, 0.3)
    .box(0.012, 0.06, 0.02, dark, -0.04, 0.03, 0.33).box(0.012, 0.06, 0.02, dark, 0, 0.03, 0.33).box(0.012, 0.06, 0.02, dark, 0.04, 0.03, 0.33)
    .cyl(0.09, 0.09, 0.08, 10, carbon, -0.3, 0.17, 0, 0, 0, Math.PI / 2).cyl(0.09, 0.09, 0.08, 10, carbon, 0.3, 0.17, 0, 0, 0, Math.PI / 2)
    .cyl(0.06, 0.06, 0.1, 10, neon, -0.3, 0.17, 0, 0, 0, Math.PI / 2).cyl(0.06, 0.06, 0.1, 10, neon, 0.3, 0.17, 0, 0, 0, Math.PI / 2)
    // khăn quàng cổ xanh navy
    .put(new THREE.TorusGeometry(0.26, 0.1, 6, 14), navy, 0, 0, 0, Math.PI / 2, 0, 0)
    .box(0.5, 0.28, 0.12, navy, 0, -0.08, 0.2, -0.3, 0, 0).box(0.06, 0.04, 0.02, neon, 0.12, -0.05, 0.27);
  head.done(torso.g); head.g.scale.setScalar(1.08);

  // --- Đuôi khăn bay phấp phới (4 đoạn nối nhau) ---
  const tailBase = new THREE.Group(); tailBase.position.set(0, 1.02, -0.3); torso.g.add(tailBase);
  const tail = []; let pg = tailBase;
  for (let i = 0; i < 4; i++) {
    const s = new Limb(0, 0, i ? -0.34 : 0);
    s.box(0.24 - 0.03 * i, 0.05, 0.34, navy, 0, 0, -0.17).box(0.02, 0.055, 0.34, neon, 0.11 - 0.015 * i, 0, -0.17);
    s.done(pg); pg = s.g; tail.push(s.g);
  }

  // --- Tay: giáp vai cam/xanh, bao tay và lưỡi kiếm năng lượng ---
  const arms = [], fores = [];
  for (const s of [-1, 1]) {
    const arm = new Limb(s * 0.66, 0.88, 0);
    arm.box(0.45, 0.32, 0.52, carbon, 0, 0.08, 0).box(0.5, 0.1, 0.56, steel, 0, -0.12, 0).box(0.4, 0.025, 0.03, neon, 0, 0.25, 0.2)
      .box(0.06, 0.05, 0.04, orange, s * 0.17, 0.1, 0.27).cyl(0.12, 0.1, 0.5, 8, dark, 0, -0.4, 0).box(0.24, 0.2, 0.26, carbon, 0, -0.68, 0);
    const fore = new Limb(0, -0.68, 0);
    fore.box(0.26, 0.5, 0.28, carbon, 0, -0.3, 0).box(0.025, 0.38, 0.22, neon, s * 0.135, -0.3, 0).box(0.2, 0.1, 0.03, neon, 0, -0.28, 0.15)
      .box(0.2, 0.2, 0.22, dark, 0, -0.62, 0).box(0.22, 0.05, 0.24, steel, 0, -0.54, 0)
      .put(new THREE.ConeGeometry(0.06, 0.95, 4), blade, 0, -1.06, 0, Math.PI, Math.PI / 4, 0);
    fore.done(arm.g); arm.done(torso.g);
    arm.g.rotation.z = s * 0.1; fore.g.rotation.x = -0.25;
    arms.push(arm.g); fores.push(fore.g);
  }
  // katana cầm tay phải (chỉ hiện khi dùng Bão Kiếm Chém)
  const bladeS = mat(0xcfe8ff, 0.2, 0.9, 0x3a7bd5, 0.6);
  const kh = new Limb(0, -0.62, 0);
  kh.cyl(0.035, 0.035, 0.34, 6, dark, 0, -0.05, 0).cyl(0.09, 0.09, 0.02, 10, steel, 0, -0.24, 0).box(0.045, 1.2, 0.012, bladeS, 0, -0.84, 0)
    .box(0.012, 1.2, 0.03, neon, 0, -0.84, 0).put(new THREE.ConeGeometry(0.03, 0.14, 4), bladeS, 0, -1.5, 0, Math.PI, Math.PI / 4, 0);
  kh.done(fores[1]); kh.g.visible = false;
  torso.done(root);

  // --- Chân ---
  const legs = [];
  for (const s of [-1, 1]) {
    const leg = new Limb(s * 0.22, 1.0, 0);
    leg.box(0.34, 0.5, 0.38, carbon, 0, -0.25, 0).box(0.38, 0.16, 0.42, steel, 0, -0.04, 0)
      .box(0.025, 0.4, 0.1, neon, s * 0.18, -0.26, 0).box(0.05, 0.08, 0.03, orange, s * 0.1, -0.1, 0.21);
    const knee = new Limb(0, -0.5, 0);
    knee.box(0.3, 0.2, 0.34, carbon, 0, 0, 0.04).box(0.05, 0.1, 0.03, orange, 0, 0, 0.22).box(0.3, 0.4, 0.32, carbon, 0, -0.22, 0)
      .box(0.02, 0.32, 0.18, neon, s * 0.16, -0.22, 0.02).box(0.28, 0.26, 0.12, steel, 0, -0.2, -0.15)
      .box(0.34, 0.1, 0.36, steel, 0, -0.36, 0).box(0.32, 0.14, 0.56, dark, 0, -0.43, 0.1);
    knee.done(leg.g); leg.done(root);
    legs.push({ hip: leg.g, knee: knee.g });
  }

  // --- Hoạt ảnh: chạy, nhảy mèo, đạp tường, khoanh kiếm, chém vòng cung ---
  let T = 0;
  const update = (p, dt) => {
    T += dt;
    const mv = p.moving ? 1 : 0, boost = p.oc > 4 || (p.buff && p.buff.speed >= 1.4) ? 1 : 0;
    const st = Math.sin(p.bob) * mv, d = p.dash, pose = p.pose, amp = 0.9 + 0.3 * boost, lean = mv * (0.2 + 0.25 * boost);
    rot.position.y = 0;
    legs[0].hip.rotation.set(st * amp, 0, 0); legs[1].hip.rotation.set(-st * amp, 0, 0);
    legs[0].knee.rotation.x = Math.max(0, st) * 1.1; legs[1].knee.rotation.x = Math.max(0, -st) * 1.1;
    arms[0].rotation.set(-st * 0.9 - 0.15 * mv, 0, -0.1); arms[1].rotation.set(st * 0.9 - 0.15 * mv, 0, 0.1);
    fores[0].rotation.x = fores[1].rotation.x = -0.25 - 0.9 * mv;
    torso.g.rotation.set(lean, 0, 0); torso.g.scale.y = 1 + Math.sin(T * 2) * 0.012;
    head.g.rotation.set(-lean * 0.7 + (p.stun > 0 ? 0.45 : 0), 0, 0);
    let glow = 0, useK = false;

    if (p.y > 0.25 && !d) { // đang nhảy: co chân, vung tay
      legs[0].hip.rotation.x = -0.6; legs[0].knee.rotation.x = 1.0; legs[1].hip.rotation.x = 0.3; legs[1].knee.rotation.x = 0.5;
      arms[0].rotation.x = -0.8; arms[1].rotation.x = -0.4; torso.g.rotation.x = 0.1;
    }
    if (d && (d.kind === 'leap' || d.kind === 'rebound')) { // nhảy mèo: co chân, vung tay, bay lên cao
      const k = Math.min(1, 1 - d.t / d.T), tk = Math.sin(k * Math.PI);
      legs[0].hip.rotation.x = -1.3 * tk - 0.1; legs[1].hip.rotation.x = -0.8 * tk;
      legs[0].knee.rotation.x = 1.6 * tk; legs[1].knee.rotation.x = 1.3 * tk;
      arms[0].rotation.set(-0.6 - 0.6 * tk, 0, -0.1); arms[1].rotation.set(0.5 * tk, 0, 0.1);
      fores[0].rotation.x = fores[1].rotation.x = -1.2;
      torso.g.rotation.x = 0.3 + 0.3 * tk; rot.position.y = tk * (d.h || 2); glow = 1;
    } else if (d && d.kind === 'kick') { // đạp tường: người ngang, một chân đá thẳng
      const tk = Math.sin(Math.min(1, 1 - d.t / d.T) * Math.PI);
      torso.g.rotation.x = 0.9; legs[0].hip.rotation.x = -1.5; legs[0].knee.rotation.x = 0;
      legs[1].hip.rotation.x = 0.5; legs[1].knee.rotation.x = 1.0;
      arms[0].rotation.x = arms[1].rotation.x = 0.9; rot.position.y = tk * (d.h || 0.8); glow = 1;
    } else if (d && d.kind === 'rush') { // lao tới cầm katana
      const s2 = Math.sin(T * 22);
      torso.g.rotation.x = 0.6; legs[0].hip.rotation.x = s2 * 0.9; legs[1].hip.rotation.x = -s2 * 0.9;
      legs[0].knee.rotation.x = Math.max(0, s2); legs[1].knee.rotation.x = Math.max(0, -s2);
      arms[1].rotation.set(1.0, 0, 0.1); fores[1].rotation.x = -0.3; arms[0].rotation.set(-0.5, 0, -0.1);
      useK = true; glow = 2;
    } else if (d) { // lướt thường
      torso.g.rotation.x = 0.55; arms[0].rotation.x = arms[1].rotation.x = 0.9;
      legs[0].hip.rotation.x = 0.6; legs[1].hip.rotation.x = -0.6; glow = 1;
    }

    if (pose) {
      if (pose.k === 'cross') { // khoanh hai lưỡi kiếm chéo trước ngực, dang chân
        legs[0].hip.rotation.set(-0.2, 0, -0.25); legs[1].hip.rotation.set(-0.2, 0, 0.25);
        legs[0].knee.rotation.x = legs[1].knee.rotation.x = 0.5;
        arms[0].rotation.set(-1.25, 0, 0.95); arms[1].rotation.set(-1.25, 0, -0.95);
        fores[0].rotation.x = fores[1].rotation.x = -1.5; torso.g.rotation.x = -0.1; glow = 3;
      } else if (pose.k === 'slash') { // chém từ trên đầu xuống
        const k = Math.min(1, Math.max(0, 1 - pose.t / 0.4));
        arms[1].rotation.set(-3.0 + 2.3 * k, 0, 0.1); fores[1].rotation.x = -0.4; arms[0].rotation.set(-0.9, 0, -0.1);
        torso.g.rotation.set(0.1 + 0.3 * k, 0.5 * (1 - k), 0);
        legs[0].hip.rotation.x = -0.7; legs[0].knee.rotation.x = 0.5; legs[1].hip.rotation.x = 0.5; legs[1].knee.rotation.x = 0.3;
        useK = true; glow = 4;
      } else if (pose.k === 'land') { // tiếp đất kiểu lunge
        torso.g.rotation.x = 0.45; legs[0].hip.rotation.x = -0.9; legs[0].knee.rotation.x = 0.6;
        legs[1].hip.rotation.x = 0.7; legs[1].knee.rotation.x = 0.2;
        arms[0].rotation.set(-0.5, 0, -0.1); arms[1].rotation.set(0.7, 0, 0.1);
      }
    } else if (p.swing > 0 && !d) { // chém thường: tay phải rồi tay trái
      const k = 1 - p.swing / 0.25, r1 = Math.sin(Math.min(1, k) * Math.PI), r2 = Math.sin(Math.min(1, Math.max(0, k * 1.3 - 0.15)) * Math.PI);
      arms[1].rotation.x = -2.3 * r1; fores[1].rotation.x = -0.25 - 0.6 * r1;
      arms[0].rotation.x = -1.8 * r2; fores[0].rotation.x = -0.25 - 0.5 * r2;
      torso.g.rotation.y = 0.6 * (r1 - r2); glow = 1;
    }

    kb.g.visible = !useK; kh.g.visible = useK;
    const run = mv || d ? 1 : 0;
    for (let i = 0; i < tail.length; i++) { // khăn bay dài ra sau khi chạy/lao
      tail[i].rotation.y = Math.sin(T * 5 + i * 0.8) * 0.35 * (0.5 + run);
      tail[i].rotation.x = (run ? 0.02 : 0.2) + Math.sin(T * 4 + i) * 0.12;
    }
    neon.emissiveIntensity = 1.5 + 0.4 * Math.sin(T * 3) + glow * 0.5;
    blade.emissiveIntensity = 2 + glow;
  };
  return { rot, flash, update, h: 2.3 };
}


// ======================= TIME CLOWN – Hề Thời Gian (pháp sư / sát thủ) =======================
function timeclown() {
  RIM = 0xc08aff;
  const black = mat(0x0d0a14, 0.5, 0.15), white = mat(0xf3efe8, 0.7, 0.05);
  const purple = mat(0x6a2fd0, 0.45, 0.2, 0x5a20c0, 0.5), gold = mat(0xe6b43c, 0.3, 0.9, 0x7a5200, 0.5);
  const skin = mat(0xf3dccf, 0.8, 0), hair = mat(0xece9f5, 0.85, 0);
  const halo = new THREE.MeshStandardMaterial({ color: 0xffd36a, emissive: 0xffb400, emissiveIntensity: 1.5, roughness: 0.4, transparent: true, opacity: 0.4, depthWrite: false });
  const flash = [black, white, purple];
  const rot = new THREE.Group(), root = new THREE.Group();
  root.scale.setScalar(0.92); rot.add(root);

  // tấm áo khoác ca-rô: nửa trên/nửa dưới khác màu, viền vàng, hình thoi
  const panel = (limb, x, w, h, cTop, cBot, cDia) => {
    limb.box(w, h * 0.55, 0.05, cTop, x, -h * 0.275, 0).box(w, h * 0.45, 0.05, cBot, x, -h * 0.775, 0)
      .box(w + 0.02, 0.03, 0.055, gold, x, -h, 0).box(0.11, 0.11, 0.055, cDia, x, -h * 0.55, 0, 0, 0, Math.PI / 4);
  };

  // --- Thân ---
  const torso = new Limb(0, 1.0, 0);
  torso.box(0.5, 0.26, 0.3, black, 0, 0.12, 0).box(0.54, 0.06, 0.34, gold, 0, 0.02, 0).box(0.1, 0.1, 0.02, gold, 0, 0.02, 0.18)
    .cyl(0.04, 0.04, 0.02, 10, white, 0, 0.02, 0.2, Math.PI / 2, 0, 0)
    .box(0.62, 0.5, 0.34, black, 0, 0.56, 0).box(0.2, 0.46, 0.02, white, 0, 0.56, 0.18)
    .box(0.04, 0.04, 0.02, gold, 0, 0.42, 0.2).box(0.04, 0.04, 0.02, gold, 0, 0.56, 0.2).box(0.04, 0.04, 0.02, gold, 0, 0.7, 0.2)
    .box(0.13, 0.4, 0.02, purple, -0.25, 0.56, 0.18).box(0.02, 0.5, 0.025, gold, 0.2, 0.56, 0.18)
    .box(0.78, 0.14, 0.38, black, 0, 0.86, 0).box(0.8, 0.03, 0.4, gold, 0, 0.94, 0)
    .box(0.34, 0.12, 0.1, white, 0, 0.84, 0.2).put(new THREE.OctahedronGeometry(0.045), purple, 0, 0.78, 0.26)
    .box(0.02, 0.62, 0.02, gold, 0.12, 0.5, 0.2, 0, 0, 0.65).box(0.02, 0.62, 0.02, gold, -0.12, 0.5, 0.2, 0, 0, -0.65)
    .cyl(0.07, 0.07, 0.025, 12, gold, 0.26, 0.3, 0.2, Math.PI / 2, 0, 0).cyl(0.055, 0.055, 0.03, 12, white, 0.26, 0.3, 0.2, Math.PI / 2, 0, 0)
    .box(0.015, 0.2, 0.015, gold, 0.26, 0.42, 0.2).box(0.015, 0.45, 0.015, gold, 0.3, -0.1, 0.14, 0, 0, 0.12)
    .sph(0.07, gold, 0.42, 0.9, 0).sph(0.07, gold, -0.42, 0.9, 0).cyl(0.07, 0.08, 0.14, 8, skin, 0, 1.0, 0);

  // --- Đầu: tóc trắng, bịt mắt, dấu kim cương tím, mũ hề 3 sừng có chuông + mặt đồng hồ ---
  const head = new Limb(0, 1.07, 0);
  head.sph(0.22, skin, 0, 0.24, 0, 0.95, 1.08, 1)
    .sph(0.1, hair, -0.2, 0.3, 0.02).sph(0.1, hair, 0.2, 0.3, 0.02).sph(0.09, hair, -0.22, 0.18, -0.05).sph(0.09, hair, 0.22, 0.18, -0.05)
    .sph(0.11, hair, 0, 0.22, -0.2).sph(0.09, hair, -0.08, 0.4, 0.14).sph(0.08, hair, 0.1, 0.38, 0.16)
    .box(0.05, 0.03, 0.02, purple, 0.09, 0.29, 0.21).box(0.09, 0.075, 0.02, black, -0.09, 0.29, 0.215)
    .put(new THREE.TorusGeometry(0.05, 0.012, 6, 12), gold, -0.09, 0.29, 0.225)
    .box(0.15, 0.02, 0.02, black, 0, 0.14, 0.215).box(0.025, 0.03, 0.02, black, -0.08, 0.155, 0.215, 0, 0, 0.5).box(0.025, 0.03, 0.02, black, 0.08, 0.155, 0.215, 0, 0, -0.5)
    .box(0.035, 0.045, 0.015, purple, 0.1, 0.2, 0.215, 0, 0, Math.PI / 4)
    .sph(0.27, black, 0, 0.42, 0, 1, 0.7, 1.05).put(new THREE.TorusGeometry(0.26, 0.025, 6, 16), gold, 0, 0.34, 0, Math.PI / 2, 0, 0)
    .put(new THREE.TorusGeometry(0.085, 0.015, 6, 14), gold, 0, 0.43, 0.27).cyl(0.075, 0.075, 0.015, 12, white, 0, 0.43, 0.268, Math.PI / 2, 0, 0)
    .box(0.012, 0.06, 0.01, black, 0, 0.45, 0.278).box(0.045, 0.012, 0.01, black, 0.02, 0.43, 0.278)
    .box(0.06, 0.06, 0.015, white, -0.16, 0.4, 0.22, 0, 0.3, Math.PI / 4).box(0.06, 0.06, 0.015, purple, 0.16, 0.4, 0.22, 0, -0.3, Math.PI / 4)
    .cyl(0.14, 0.17, 0.1, 8, black, 0, 0, 0).put(new THREE.TorusGeometry(0.15, 0.015, 6, 12), gold, 0, 0.05, 0, Math.PI / 2, 0, 0);
  const horn = (bx, by, bz, kind) => { // sừng mũ hề cong, đuôi gắn chuông vàng
    const h = new Limb(bx, by, bz), TH = kind === 'B' ? [0.6, 1.1, 1.6, 2.0] : [0.45, 0.85, 1.35, 1.85], cols = [black, white, purple, black];
    let x = 0, y = 0, z = 0;
    for (let i = 0; i < 4; i++) {
      const th = TH[i], len = 0.17, rb = 0.08 - i * 0.015, rt = rb - 0.015;
      let dx = 0, dz = 0, rx = 0, rz = 0;
      if (kind === 'L') { dx = -Math.sin(th); rz = th; } else if (kind === 'R') { dx = Math.sin(th); rz = -th; } else { dz = -Math.sin(th); rx = -th; }
      const dy = Math.cos(th);
      h.cyl(rt, rb, len, 6, cols[i], x + (dx * len) / 2, y + (dy * len) / 2, z + (dz * len) / 2, rx, 0, rz);
      x += dx * len; y += dy * len; z += dz * len;
    }
    h.sph(0.055, gold, x, y, z);
    return h;
  };
  const hornL = horn(-0.17, 0.5, 0, 'L'), hornR = horn(0.17, 0.5, 0, 'R'), hornB = horn(0, 0.48, -0.18, 'B');
  hornL.done(head.g); hornR.done(head.g); hornB.done(head.g);
  head.done(torso.g); head.g.scale.setScalar(1.1);

  // --- Đồng hồ cát nổi trước tay trái ---
  const hg = new Limb(-0.5, 1.0, 0.95);
  hg.cyl(0.13, 0.13, 0.025, 10, gold, 0, 0.2, 0).cyl(0.13, 0.13, 0.025, 10, gold, 0, -0.2, 0)
    .cyl(0.012, 0.012, 0.4, 4, gold, 0.1, 0, 0).cyl(0.012, 0.012, 0.4, 4, gold, -0.05, 0, 0.087).cyl(0.012, 0.012, 0.4, 4, gold, -0.05, 0, -0.087)
    .put(new THREE.ConeGeometry(0.1, 0.18, 10), purple, 0, 0.1, 0, Math.PI, 0, 0).put(new THREE.ConeGeometry(0.1, 0.18, 10), purple, 0, -0.1, 0);
  hg.done(torso.g);

  // --- Tay: tay áo loe, tay trái đưa ra đỡ đồng hồ cát, tay phải cầm lá bài ---
  const arms = [], fores = [];
  for (const s of [-1, 1]) {
    const arm = new Limb(s * 0.45, 0.84, 0);
    arm.cyl(0.09, 0.08, 0.42, 8, black, 0, -0.21, 0).put(new THREE.TorusGeometry(0.085, 0.015, 6, 10), gold, 0, -0.42, 0, Math.PI / 2, 0, 0);
    const fore = new Limb(0, -0.42, 0);
    fore.cyl(0.085, 0.15, 0.42, 8, black, 0, -0.21, 0).cyl(0.152, 0.155, 0.06, 8, purple, 0, -0.36, 0).cyl(0.16, 0.16, 0.03, 8, gold, 0, -0.43, 0)
      .box(0.12, 0.14, 0.14, black, 0, -0.52, 0);
    if (s === 1) fore.box(0.2, 0.3, 0.012, white, 0, -0.62, 0.09, 0.4, 0, 0).box(0.215, 0.315, 0.01, gold, 0, -0.62, 0.085, 0.4, 0, 0);
    fore.done(arm.g); arm.done(torso.g);
    arm.g.rotation.z = s * 0.1; arms.push(arm.g); fores.push(fore.g);
  }
  torso.done(root);

  // --- Áo khoác: 3 vạt sau + 2 vạt trước (phấp phới khi chạy) ---
  const tailB = new Limb(0, 1.02, -0.17);
  panel(tailB, -0.22, 0.3, 0.95, black, purple, white); panel(tailB, 0, 0.3, 1.05, white, black, purple); panel(tailB, 0.22, 0.3, 0.95, black, white, purple);
  tailB.done(root);
  const flapL = new Limb(-0.26, 1.03, 0.17); panel(flapL, 0, 0.3, 0.75, black, white, purple); flapL.done(root);
  const flapR = new Limb(0.26, 1.03, 0.17); panel(flapR, 0, 0.3, 0.75, white, purple, black); flapR.done(root);

  // --- Chân: quần ca-rô đen/trắng, giày bốt to viền vàng ---
  const legs = [];
  for (const s of [-1, 1]) {
    const leg = new Limb(s * 0.2, 1.0, 0);
    for (let r = 0; r < 4; r++) leg.box(0.3, 0.125, 0.3, (r + (s > 0 ? 1 : 0)) % 2 ? white : black, 0, -0.0625 - 0.125 * r, 0);
    leg.box(0.34, 0.03, 0.34, gold, 0, -0.5, 0).box(0.09, 0.09, 0.02, purple, 0, -0.19, 0.155, 0, 0, Math.PI / 4);
    const knee = new Limb(0, -0.5, 0);
    for (let r = 0; r < 4; r++) knee.box(0.26, 0.1, 0.26, (r + (s > 0 ? 0 : 1)) % 2 ? white : black, 0, -0.05 - 0.1 * r, 0);
    knee.box(0.3, 0.16, 0.5, black, 0, -0.42, 0.07).box(0.28, 0.1, 0.16, white, 0, -0.44, 0.28).box(0.29, 0.06, 0.06, gold, 0, -0.44, 0.37)
      .box(0.34, 0.04, 0.56, gold, 0, -0.49, 0.06).box(0.32, 0.03, 0.2, gold, 0, -0.36, 0.1).sph(0.045, gold, s * 0.16, -0.36, 0);
    knee.done(leg.g); leg.done(root); legs.push({ hip: leg.g, knee: knee.g });
  }

  // --- Lá bài bay quanh người ---
  const cards = [];
  for (let i = 0; i < 3; i++) {
    const c = new Limb(0, 0, 0);
    c.box(0.3, 0.42, 0.012, white, 0, 0, 0).box(0.33, 0.45, 0.01, gold, 0, 0, -0.006)
      .box(0.09, 0.09, 0.014, black, 0, 0.04, 0.002, 0, 0, Math.PI / 4).box(0.025, 0.08, 0.014, black, 0, -0.05, 0.002)
      .box(0.04, 0.04, 0.014, purple, -0.1, 0.17, 0.002, 0, 0, Math.PI / 4);
    c.done(root); cards.push(c.g);
  }

  // --- Vòng đồng hồ vàng: sau lưng + dưới chân ---
  const haloG = new THREE.Group(); haloG.position.set(0, 1.5, -0.65); root.add(haloG);
  const hl = new Limb(0, 0, 0);
  hl.put(new THREE.TorusGeometry(0.8, 0.025, 6, 36), halo, 0, 0, 0);
  for (let k = 0; k < 12; k++) { const a = (k / 12) * Math.PI * 2; hl.box(0.03, k % 3 ? 0.08 : 0.15, 0.02, halo, Math.sin(a) * 0.72, Math.cos(a) * 0.72, 0, 0, 0, -a); }
  hl.done(haloG);
  const hand1 = new Limb(0, 0, 0); hand1.box(0.03, 0.55, 0.02, halo, 0, 0.275, 0); hand1.done(haloG);
  const hand2 = new Limb(0, 0, 0); hand2.box(0.04, 0.36, 0.02, halo, 0, 0.18, 0); hand2.done(haloG);
  const ground = new Limb(0, 0.04, 0);
  ground.put(new THREE.TorusGeometry(1.15, 0.025, 6, 40), halo, 0, 0, 0, Math.PI / 2, 0, 0);
  for (let k = 0; k < 12; k++) { const a = (k / 12) * Math.PI * 2; ground.box(0.05, 0.02, 0.18, halo, Math.sin(a) * 1.05, 0, Math.cos(a) * 1.05, 0, a, 0); }
  ground.done(root);

  // --- Hoạt ảnh ---
  let T = 0;
  const update = (p, dt) => {
    T += dt;
    const mv = p.moving ? 1 : 0, st = Math.sin(p.bob) * mv, d = p.dash, lean = 0.15 * mv;
    rot.position.y = 0.04 + Math.sin(T * 2) * 0.03;
    legs[0].hip.rotation.x = st * 0.85; legs[1].hip.rotation.x = -st * 0.85;
    legs[0].knee.rotation.x = Math.max(0, st) * 1.0; legs[1].knee.rotation.x = Math.max(0, -st) * 1.0;
    arms[0].rotation.set(-1.2 + Math.sin(T * 1.5) * 0.05, 0, -0.2); fores[0].rotation.x = -0.5; // tay trái đỡ đồng hồ cát
    arms[1].rotation.set(st * 0.8 - 0.1 * mv, 0, 0.12); fores[1].rotation.x = -0.3 - 0.6 * mv;
    torso.g.rotation.set(lean, 0, 0); torso.g.scale.y = 1 + Math.sin(T * 2) * 0.01;
    head.g.rotation.set(-lean * 0.6 + (p.stun > 0 ? 0.45 : 0), 0, Math.sin(T * 1.3) * 0.05);
    let glow = 0;
    if (p.y > 0.25 && !d) { legs[0].hip.rotation.x = -0.6; legs[0].knee.rotation.x = 1.0; legs[1].hip.rotation.x = 0.3; legs[1].knee.rotation.x = 0.5; arms[1].rotation.x = -0.4; }
    if (d) { torso.g.rotation.x = 0.5; arms[1].rotation.x = 0.8; legs[0].hip.rotation.x = 0.6; legs[1].hip.rotation.x = -0.6; glow = 1; }
    else if (p.swing > 0) { // ném bài: tay phải vung, thân xoay
      const k = 1 - p.swing / 0.25, r = Math.sin(Math.min(1, k) * Math.PI);
      arms[1].rotation.x = -2.2 * r; fores[1].rotation.x = -0.2; torso.g.rotation.y = -0.5 * r; glow = 1;
    }
    const rw = p.pose && p.pose.k === 'rewind'; // Time Rewind: giơ hai tay, đồng hồ cát phóng to trên đầu
    if (rw) {
      arms[0].rotation.set(-2.6, 0, -0.5); arms[1].rotation.set(-2.6, 0, 0.5); fores[0].rotation.x = fores[1].rotation.x = -0.3;
      torso.g.rotation.x = -0.15; rot.position.y = 0.45 + Math.sin(T * 3) * 0.05; glow = 3;
    }
    const sway = 0.1 + 0.5 * mv * (0.6 + 0.4 * Math.sin(T * 9)) + (d ? 0.8 : 0);
    tailB.g.rotation.x = sway + Math.sin(T * 3) * 0.05;
    flapL.g.rotation.set(sway * 0.8, 0, -(0.05 + 0.2 * mv)); flapR.g.rotation.set(sway * 0.8, 0, 0.05 + 0.2 * mv);
    hornL.g.rotation.z = Math.sin(T * 3.1) * 0.12 + mv * Math.sin(T * 9) * 0.1;
    hornR.g.rotation.z = -Math.sin(T * 2.7) * 0.12 - mv * Math.sin(T * 9.5) * 0.1;
    hornB.g.rotation.x = Math.sin(T * 2.2) * 0.1;
    if (rw) { hg.g.position.set(0, 2.1 + Math.sin(T * 3) * 0.1, 0.2); hg.g.scale.setScalar(2.2); }
    else { hg.g.position.set(-0.5, 1.0 + Math.sin(T * 2) * 0.05, 0.95); hg.g.scale.setScalar(1); }
    hg.g.rotation.y = T * (rw ? 4 : 1.2);
    for (let i = 0; i < 3; i++) {
      const a = T * (1.2 + 0.8 * mv) + i * 2.094;
      cards[i].position.set(Math.cos(a) * 1.05, 1.4 + Math.sin(T * 1.5 + i) * 0.12, Math.sin(a) * 1.05);
      cards[i].rotation.set(0, Math.PI / 2 - a, 0.2 * Math.sin(T * 2 + i));
    }
    haloG.rotation.z = T * (rw ? 2 : 0.3); hand1.g.rotation.z = -T * 0.6; hand2.g.rotation.z = -T * 0.08; ground.g.rotation.y = T * 0.5;
    gold.emissiveIntensity = 0.5 + 0.2 * Math.sin(T * 3) + glow * 0.4;
    purple.emissiveIntensity = 0.5 + 0.2 * Math.sin(T * 2 + 1) + glow * 0.5;
  };
  return { rot, flash, update, h: 2.7 };
}


// ======================= Khung dùng chung cho tướng mới: dựng từng bộ phận + hoạt ảnh chạy/nhảy/lướt/chém =======================
function stdPose(p, T, R) {
  const mv = p.moving ? 1 : 0, st = Math.sin(p.bob) * mv, d = p.dash, lean = 0.2 * mv;
  R.rot.position.y = 0;
  R.legs[0].hip.rotation.set(st * 0.9, 0, 0); R.legs[1].hip.rotation.set(-st * 0.9, 0, 0);
  R.legs[0].knee.rotation.x = Math.max(0, st) * 1.1; R.legs[1].knee.rotation.x = Math.max(0, -st) * 1.1;
  R.arms[0].rotation.set(-st * 0.9 - 0.15 * mv, 0, -0.1); R.arms[1].rotation.set(st * 0.9 - 0.15 * mv, 0, 0.1);
  R.fores[0].rotation.x = R.fores[1].rotation.x = -0.25 - 0.8 * mv;
  R.torso.g.rotation.set(lean, 0, 0); R.torso.g.scale.y = 1 + Math.sin(T * 2) * 0.012;
  R.head.g.rotation.set(-lean * 0.7 + (p.stun > 0 ? 0.45 : 0), 0, 0);
  if (p.y > 0.25 && !d) { // đang nhảy
    R.legs[0].hip.rotation.x = -0.6; R.legs[0].knee.rotation.x = 1.0; R.legs[1].hip.rotation.x = 0.3; R.legs[1].knee.rotation.x = 0.5;
    R.arms[0].rotation.x = -0.8; R.arms[1].rotation.x = -0.4;
  }
  let glow = 0;
  if (d) { // lướt / lao
    const hh = d.kind === 'leap' || d.kind === 'rebound' ? Math.sin(Math.min(1, 1 - d.t / d.T) * Math.PI) * (d.h || 2) : 0;
    R.torso.g.rotation.x = 0.55; R.arms[0].rotation.x = R.arms[1].rotation.x = 0.9;
    R.legs[0].hip.rotation.x = 0.6; R.legs[1].hip.rotation.x = -0.6; R.rot.position.y = hh; glow = 1;
  } else if (p.swing > 0) { // ra đòn: tay phải rồi tay trái
    const k = 1 - p.swing / 0.25, r1 = Math.sin(Math.min(1, k) * Math.PI), r2 = Math.sin(Math.min(1, Math.max(0, k * 1.3 - 0.15)) * Math.PI);
    R.arms[1].rotation.x = -2.2 * r1; R.fores[1].rotation.x = -0.25 - 0.6 * r1; R.arms[0].rotation.x = -1.6 * r2; R.fores[0].rotation.x = -0.25 - 0.5 * r2;
    R.torso.g.rotation.y = 0.5 * (r1 - r2); glow = 1;
  }
  return { mv, st, d, glow };
}

function rig(cfg) {
  const rot = new THREE.Group(), root = new THREE.Group();
  root.scale.setScalar(cfg.scale || 1); rot.add(root);
  const torso = new Limb(0, cfg.hip || 1.0, 0); cfg.torso(torso);
  const head = new Limb(0, cfg.neck || 1.1, 0); cfg.head(head); head.done(torso.g); head.g.scale.setScalar(cfg.headScale || 1.08);
  const arms = [], fores = [];
  for (const s of [-1, 1]) {
    const arm = new Limb(s * (cfg.shx || 0.5), cfg.shy || 0.85, 0); cfg.arm(arm, s);
    const fore = new Limb(0, -(cfg.upper || 0.42), 0); cfg.fore(fore, s);
    fore.done(arm.g); arm.done(torso.g); arm.g.rotation.z = s * 0.1; arms.push(arm.g); fores.push(fore.g);
  }
  torso.done(root);
  const legs = [];
  for (const s of [-1, 1]) {
    const leg = new Limb(s * (cfg.hipx || 0.2), cfg.hip || 1.0, 0); cfg.leg(leg, s);
    const knee = new Limb(0, -0.5, 0); cfg.knee(knee, s); knee.done(leg.g); leg.done(root); legs.push({ hip: leg.g, knee: knee.g });
  }
  const ex = cfg.extra ? cfg.extra(root) : null, R = { rot, torso, head, arms, fores, legs };
  let T = 0;
  const update = (p, dt) => { T += dt; const r = stdPose(p, T, R); if (ex) ex(p, T, r.mv, r.d, r.glow); };
  return { rot, flash: cfg.flash, update, h: cfg.h };
}

// ======================= FROST EMPRESS – Nữ hoàng băng (pháp sư) =======================
function frostempress() {
  RIM = 0x9fe6ff;
  const ice = mat(0x8fe3ff, 0.3, 0.4, 0x3aa8e0, 0.7), white = mat(0xf4fcff, 0.7, 0.05), dress = mat(0x2b5db8, 0.6, 0.1), silver = mat(0xc7d3e0, 0.3, 0.8);
  const skin = mat(0xf3e1d8, 0.8, 0), hair = mat(0xe6f4ff, 0.85, 0), crystal = mat(0xbff2ff, 0.2, 0.3, 0x66ccff, 1.2);
  const halo = new THREE.MeshStandardMaterial({ color: 0x9fe6ff, emissive: 0x66ccff, emissiveIntensity: 1.4, transparent: true, opacity: 0.45, depthWrite: false });
  return rig({
    flash: [dress, white, silver], h: 2.5, scale: 0.94, shx: 0.36, shy: 0.86,
    torso: L => L.box(0.36, 0.3, 0.24, dress, 0, 0.15, 0).box(0.46, 0.46, 0.28, white, 0, 0.6, 0).box(0.5, 0.1, 0.3, ice, 0, 0.38, 0).box(0.04, 0.4, 0.02, ice, 0, 0.6, 0.15)
      .box(0.62, 0.12, 0.3, white, 0, 0.9, 0).put(new THREE.OctahedronGeometry(0.06), crystal, 0, 0.72, 0.17).cyl(0.07, 0.08, 0.16, 8, skin, 0, 1.0, 0)
      .put(new THREE.ConeGeometry(0.05, 0.25, 5), ice, -0.2, 1.0, -0.05, 0, 0, 0.4).put(new THREE.ConeGeometry(0.05, 0.25, 5), ice, 0.2, 1.0, -0.05, 0, 0, -0.4)
      .put(new THREE.ConeGeometry(0.05, 0.3, 5), ice, 0, 1.05, -0.15, -0.4, 0, 0),
    head: L => L.sph(0.21, skin, 0, 0.22, 0, 0.95, 1.08, 1).sph(0.24, hair, 0, 0.3, -0.05, 1.05, 1, 1.05).cyl(0.1, 0.2, 0.7, 8, hair, 0, -0.1, -0.15)
      .box(0.06, 0.035, 0.02, ice, -0.08, 0.25, 0.19).box(0.06, 0.035, 0.02, ice, 0.08, 0.25, 0.19).box(0.05, 0.015, 0.02, dress, 0, 0.15, 0.2)
      .put(new THREE.ConeGeometry(0.05, 0.28, 5), ice, 0, 0.58, 0.05).put(new THREE.ConeGeometry(0.04, 0.2, 5), ice, -0.14, 0.52, 0.03, 0, 0, 0.4)
      .put(new THREE.ConeGeometry(0.04, 0.2, 5), ice, 0.14, 0.52, 0.03, 0, 0, -0.4).put(new THREE.ConeGeometry(0.035, 0.16, 5), ice, -0.22, 0.44, 0, 0, 0, 0.7)
      .put(new THREE.ConeGeometry(0.035, 0.16, 5), ice, 0.22, 0.44, 0, 0, 0, -0.7).put(new THREE.TorusGeometry(0.2, 0.02, 6, 14), silver, 0, 0.42, 0, Math.PI / 2, 0, 0),
    arm: L => L.cyl(0.07, 0.06, 0.42, 8, dress, 0, -0.21, 0).put(new THREE.OctahedronGeometry(0.07), ice, 0, 0.02, 0),
    fore: L => L.cyl(0.06, 0.16, 0.42, 8, white, 0, -0.21, 0).cyl(0.165, 0.165, 0.04, 8, ice, 0, -0.42, 0).box(0.1, 0.12, 0.12, skin, 0, -0.5, 0).put(new THREE.OctahedronGeometry(0.09), crystal, 0, -0.62, 0),
    leg: L => L.box(0.24, 0.5, 0.24, dress, 0, -0.25, 0),
    knee: L => L.box(0.2, 0.4, 0.2, dress, 0, -0.22, 0).box(0.24, 0.16, 0.4, silver, 0, -0.43, 0.08).box(0.2, 0.1, 0.2, ice, 0, -0.34, 0.02),
    extra: root => {
      const sk = new Limb(0, 1.0, 0); // váy dài + viền băng
      sk.cyl(0.27, 0.58, 0.6, 14, dress, 0, -0.3, 0).cyl(0.58, 0.64, 0.35, 14, white, 0, -0.78, 0).put(new THREE.TorusGeometry(0.63, 0.025, 6, 20), ice, 0, -0.95, 0, Math.PI / 2, 0, 0);
      sk.done(root);
      const orb = []; // 4 tinh thể băng quay quanh người
      for (let i = 0; i < 4; i++) { const c = new Limb(0, 0, 0); c.put(new THREE.OctahedronGeometry(0.14), crystal, 0, 0, 0); c.done(root); c.g.scale.set(0.7, 1.3, 0.7); orb.push(c.g); }
      const gr = new Limb(0, 0.04, 0); // hoa tuyết dưới chân
      gr.put(new THREE.TorusGeometry(1.1, 0.025, 6, 36), halo, 0, 0, 0, Math.PI / 2, 0, 0);
      for (let k = 0; k < 3; k++) gr.box(0.05, 0.02, 2.0, halo, 0, 0, 0, 0, (k / 3) * Math.PI, 0);
      gr.done(root);
      return (p, T, mv) => {
        sk.g.scale.set(1 + 0.04 * mv * Math.sin(T * 8), 1, 1 + 0.04 * mv * Math.sin(T * 8)); sk.g.rotation.x = 0.06 * mv;
        orb.forEach((o, i) => { const a = T * 1.4 + (i * Math.PI) / 2; o.position.set(Math.cos(a) * 1.05, 1.5 + Math.sin(T * 2 + i) * 0.12, Math.sin(a) * 1.05); o.rotation.y = T * 2 + i; });
        gr.g.rotation.y = T * 0.4;
      };
    }
  });
}

// ======================= CRIMSON SAMURAI – Kiếm sĩ giáp đỏ =======================
function crimsonsamurai() {
  RIM = 0xff6659;
  const red = mat(0xc62828, 0.5, 0.3), dark = mat(0x1b1b22, 0.6, 0.3), gold = mat(0xd4a017, 0.3, 0.9, 0x6a4a00, 0.4), steel = mat(0xe0e8ee, 0.2, 0.9, 0x4a6a8a, 0.3);
  const cloth = mat(0x2b2b33, 0.9, 0), skin = mat(0xe8c4a0, 0.8, 0), glow = mat(0xff5a4a, 0.3, 0.2, 0xff3b30, 1.4);
  return rig({
    flash: [red, dark, cloth], h: 2.5, scale: 0.94, shx: 0.56, shy: 0.86, neck: 1.12,
    torso: L => L.box(0.5, 0.3, 0.34, dark, 0, 0.15, 0).box(0.78, 0.56, 0.46, red, 0, 0.62, 0).box(0.8, 0.05, 0.48, dark, 0, 0.5, 0).box(0.8, 0.05, 0.48, dark, 0, 0.64, 0).box(0.8, 0.05, 0.48, dark, 0, 0.78, 0)
      .box(0.7, 0.14, 0.42, gold, 0, 0.04, 0).box(0.14, 0.14, 0.02, glow, 0, 0.04, 0.22).box(0.9, 0.16, 0.46, red, 0, 0.96, 0).box(0.92, 0.03, 0.48, gold, 0, 1.04, 0)
      .cyl(0.1, 0.12, 0.16, 8, dark, 0, 1.06, 0).box(0.04, 1.3, 0.04, dark, 0.2, 0.9, -0.3).box(0.4, 0.55, 0.02, red, 0.4, 1.4, -0.3).box(0.14, 0.14, 0.025, gold, 0.4, 1.4, -0.31)
      .box(0.07, 0.95, 0.07, dark, -0.34, -0.02, 0.18, 0, 0, 0.25),
    head: L => L.sph(0.2, skin, 0, 0.22, 0, 0.95, 1.05, 1).sph(0.27, dark, 0, 0.34, 0, 1, 0.75, 1.05).put(new THREE.TorusGeometry(0.3, 0.03, 6, 16, Math.PI), gold, 0, 0.42, 0.14)
      .box(0.46, 0.18, 0.12, red, 0, 0.12, 0.14).box(0.3, 0.14, 0.1, dark, 0, 0.06, 0.2).box(0.04, 0.07, 0.02, steel, -0.07, 0.02, 0.26).box(0.04, 0.07, 0.02, steel, 0.07, 0.02, 0.26)
      .box(0.07, 0.03, 0.02, glow, -0.08, 0.27, 0.2).box(0.07, 0.03, 0.02, glow, 0.08, 0.27, 0.2)
      .box(0.5, 0.12, 0.1, red, 0, 0.24, -0.2).box(0.55, 0.1, 0.1, dark, 0, 0.14, -0.22).box(0.6, 0.1, 0.1, red, 0, 0.04, -0.24),
    arm: L => L.box(0.46, 0.1, 0.5, red, 0, 0.1, 0).box(0.5, 0.08, 0.52, dark, 0, 0, 0).box(0.48, 0.1, 0.5, red, 0, -0.1, 0).box(0.52, 0.03, 0.54, gold, 0, -0.16, 0).cyl(0.1, 0.09, 0.42, 8, cloth, 0, -0.3, 0),
    fore: (L, s) => {
      L.cyl(0.09, 0.1, 0.42, 8, red, 0, -0.21, 0).box(0.16, 0.34, 0.16, dark, 0, -0.22, 0).box(0.16, 0.2, 0.16, dark, 0, -0.52, 0);
      if (s === 1) L.cyl(0.03, 0.03, 0.36, 6, dark, 0, -0.52, 0).cyl(0.1, 0.1, 0.02, 10, gold, 0, -0.72, 0).box(0.04, 1.15, 0.015, steel, 0, -1.3, 0)
        .box(0.012, 1.15, 0.03, glow, 0, -1.3, 0).put(new THREE.ConeGeometry(0.025, 0.12, 4), steel, 0, -1.92, 0, Math.PI, Math.PI / 4, 0); // katana cầm tay phải
    },
    leg: L => L.box(0.4, 0.5, 0.34, cloth, 0, -0.25, 0).box(0.44, 0.04, 0.38, gold, 0, -0.5, 0),
    knee: L => L.box(0.32, 0.4, 0.3, cloth, 0, -0.2, 0).box(0.28, 0.26, 0.28, red, 0, -0.22, 0.02).box(0.3, 0.14, 0.3, dark, 0, -0.36, 0).box(0.3, 0.14, 0.52, dark, 0, -0.43, 0.08).box(0.34, 0.04, 0.56, gold, 0, -0.49, 0.06),
    extra: root => {
      const fF = new Limb(0, 1.04, 0.26); fF.box(0.5, 0.45, 0.04, red, 0, -0.22, 0).box(0.52, 0.04, 0.05, gold, 0, -0.45, 0).box(0.16, 0.16, 0.045, dark, 0, -0.2, 0, 0, 0, Math.PI / 4); fF.done(root);
      const fB = new Limb(0, 1.04, -0.24); fB.box(0.5, 0.45, 0.04, red, 0, -0.22, 0).box(0.52, 0.04, 0.05, gold, 0, -0.45, 0); fB.done(root);
      const base = new THREE.Group(); base.position.set(0, 2.05, -0.28); root.add(base); // khăn đỏ bay
      const tail = []; let pg = base;
      for (let i = 0; i < 3; i++) { const sg = new Limb(0, 0, i ? -0.3 : 0); sg.box(0.2 - 0.03 * i, 0.05, 0.3, red, 0, 0, -0.15).box(0.02, 0.055, 0.3, gold, 0.09 - 0.015 * i, 0, -0.15); sg.done(pg); pg = sg.g; tail.push(sg.g); }
      return (p, T, mv, d) => {
        const sw = 0.05 + 0.5 * mv * (0.6 + 0.4 * Math.sin(T * 9)) + (d ? 0.6 : 0);
        fF.g.rotation.x = -sw * 0.8; fB.g.rotation.x = sw;
        tail.forEach((g, i) => { g.rotation.y = Math.sin(T * 5 + i * 0.8) * 0.3 * (0.5 + mv); g.rotation.x = (mv || d ? 0.02 : 0.2) + Math.sin(T * 4 + i) * 0.1; });
      };
    }
  });
}

// ======================= TITAN BRAWLER – Võ sĩ trâu =======================
function titanbrawler() {
  RIM = 0xffb04a;
  const skin = mat(0xc68a5e, 0.8, 0), stone = mat(0x6d5b4b, 0.9, 0.1), glowM = mat(0xff8f00, 0.3, 0.2, 0xff7a00, 1.3), gold = mat(0xd4a017, 0.3, 0.9, 0x6a4a00, 0.4);
  const pants = mat(0x2a2320, 0.8, 0), beard = mat(0x3b2a1e, 0.9, 0);
  return rig({
    flash: [skin, stone, pants], h: 2.9, scale: 1.12, shx: 0.72, shy: 0.98, neck: 1.22, upper: 0.46, hipx: 0.26,
    torso: L => L.box(0.7, 0.3, 0.42, pants, 0, 0.15, 0).box(1.0, 0.72, 0.56, skin, 0, 0.7, 0).box(1.1, 0.22, 0.58, skin, 0, 1.1, 0)
      .box(0.9, 0.14, 0.5, gold, 0, 0.04, 0).box(0.3, 0.2, 0.04, gold, 0, 0.04, 0.28).box(0.12, 0.12, 0.045, glowM, 0, 0.04, 0.3)
      .box(0.4, 0.3, 0.1, skin, -0.25, 0.88, 0.3).box(0.4, 0.3, 0.1, skin, 0.25, 0.88, 0.3)
      .box(0.05, 0.5, 0.03, glowM, -0.22, 0.6, 0.29).box(0.05, 0.5, 0.03, glowM, 0.22, 0.6, 0.29).box(0.5, 0.04, 0.03, glowM, 0, 0.7, 0.29)
      .cyl(0.16, 0.2, 0.2, 8, skin, 0, 1.28, 0),
    head: L => L.sph(0.26, skin, 0, 0.2, 0, 1, 1.05, 1).box(0.34, 0.16, 0.14, beard, 0, 0.04, 0.17).sph(0.1, beard, 0, 0.0, 0.2).box(0.4, 0.06, 0.1, beard, 0, 0.34, 0.16)
      .box(0.07, 0.04, 0.02, glowM, -0.1, 0.24, 0.24).box(0.07, 0.04, 0.02, glowM, 0.1, 0.24, 0.24).put(new THREE.TorusGeometry(0.26, 0.03, 6, 14), gold, 0, 0.36, 0, Math.PI / 2, 0, 0),
    arm: L => L.cyl(0.2, 0.17, 0.46, 8, skin, 0, -0.23, 0).box(0.62, 0.28, 0.62, stone, 0, 0.12, 0).box(0.64, 0.04, 0.64, glowM, 0, -0.04, 0),
    fore: L => L.cyl(0.17, 0.2, 0.4, 8, skin, 0, -0.2, 0).box(0.44, 0.5, 0.44, stone, 0, -0.38, 0).box(0.46, 0.04, 0.46, glowM, 0, -0.14, 0)
      .box(0.05, 0.3, 0.03, glowM, 0, -0.38, 0.23).box(0.38, 0.34, 0.38, stone, 0, -0.78, 0).box(0.4, 0.04, 0.4, glowM, 0, -0.64, 0),
    leg: L => L.box(0.44, 0.5, 0.4, pants, 0, -0.25, 0),
    knee: L => L.box(0.38, 0.4, 0.36, pants, 0, -0.22, 0).box(0.4, 0.22, 0.42, stone, 0, -0.05, 0.06).box(0.04, 0.16, 0.04, glowM, 0, -0.05, 0.28).box(0.4, 0.2, 0.56, stone, 0, -0.43, 0.08),
    extra: root => {
      const rocks = []; // 3 tảng đá quay quanh người
      for (let i = 0; i < 3; i++) { const r = new Limb(0, 0, 0); r.box(0.22, 0.22, 0.22, stone, 0, 0, 0).box(0.24, 0.03, 0.24, glowM, 0, 0.12, 0); r.done(root); rocks.push(r.g); }
      return (p, T) => rocks.forEach((g, i) => { const a = T + i * 2.094; g.position.set(Math.cos(a) * 1.3, 1.7 + Math.sin(T * 1.7 + i) * 0.15, Math.sin(a) * 1.3); g.rotation.set(T + i, T * 1.3, 0); });
    }
  });
}

// ======================= Mô hình mặc định cho hero chưa có skin =======================
function generic(key) {
  const H = HEROES[key] || { color: 0xcccccc }, sc = H.scale || 1;
  RIM = H.color;
  const body = mat(H.color, 0.7, 0.1), dark = mat(0x2a2a30, 0.7, 0.2), skin = mat(0xe0b99a, 0.8, 0), accent = mat(0xffd54f, 0.5, 0.3, 0x553300, 0.4);
  const rot = new THREE.Group(), root = new THREE.Group(); root.scale.setScalar(sc); rot.add(root);
  const torso = new Limb(0, 0.85, 0);
  torso.cyl(0.38, 0.34, 0.8, 10, body, 0, 0.4, 0).box(0.8, 0.12, 0.45, dark, 0, 0.02, 0).sph(0.3, skin, 0, 1.02, 0).box(0.5, 0.14, 0.4, dark, 0, 1.2, 0);
  if (H.mob) torso.box(0.1, 0.1, 0.02, accent, 0, 0.6, 0.36);
  const arms = [];
  for (const s2 of [-1, 1]) {
    const a2 = new Limb(s2 * 0.5, 0.78, 0);
    a2.cyl(0.12, 0.1, 0.7, 8, body, 0, -0.35, 0).sph(0.12, skin, 0, -0.75, 0);
    if (s2 === 1 && H.mob) a2.box(0.08, 0.08, 0.9, dark, 0, -0.75, 0.45); // vũ khí
    a2.done(torso.g); arms.push(a2.g);
  }
  torso.done(root);
  const legs = [];
  for (const s2 of [-1, 1]) {
    const l2 = new Limb(s2 * 0.18, 0.85, 0);
    l2.cyl(0.15, 0.13, 0.85, 8, dark, 0, -0.42, 0).box(0.26, 0.12, 0.4, body, 0, -0.85, 0.06);
    l2.done(root); legs.push(l2.g);
  }
  const update = p => {
    const mv = p.moving ? 1 : 0, st = Math.sin(p.bob) * mv;
    legs[0].rotation.x = st * 0.8; legs[1].rotation.x = -st * 0.8; arms[0].rotation.x = -st * 0.6; arms[1].rotation.x = st * 0.6;
    if (p.swing > 0) arms[1].rotation.x = -2.0 * Math.sin(Math.min(1, 1 - p.swing / 0.25) * Math.PI);
    torso.g.rotation.x = 0.08 * mv;
  };
  return { rot, flash: [body, dark], update, h: 2.2 * sc };
}

// Trả về { rot, flash, update(p, dt) } – mỗi người chơi có bộ vật liệu riêng
const MODELS = { asasin, timeclown, frostempress, crimsonsamurai, titanbrawler };
export function buildModel(key) { return (MODELS[key] || generic.bind(null, key))(); }
