import * as THREE from 'three';
import { HEROES } from './hero_classes.js';
import { Combat } from './combat_system.js';
import { MODES, TEAM_COLORS, assign, registerKill, checkEnd, scoreText, zoneAt, CAMPS, questFor, xpNeed, LV_MAX } from './game_modes.js';
import { Controls } from './controls.js';
import { Net } from './network.js';
import { buildArena, WORLD } from './arena.js';
import { buildModel } from './hero_models.js';

const $ = s => document.querySelector(s);
const hex = c => '#' + c.toString(16).padStart(6, '0');
const G = {
  players: new Map(), running: false, ended: false, auth: true, net: null, myId: 'host', me: null,
  mode: null, score: {}, stats: {}, time: 0, lobby: [], hero: 'asasin', yaw: 0, pitch: 0.32, zoom: 1, lock: false, shake: 0, modeKey: '1v1', R: 22
};
window.G = G;

// ---------- Three.js scene ----------
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x14210f);
scene.fog = new THREE.Fog(0x14210f, 60, 150);
const camera = new THREE.PerspectiveCamera(65, 1, 0.3, 260);
G.scene = scene; G.camera = camera;
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

scene.add(new THREE.HemisphereLight(0xaaccff, 0x222244, 1.1));
const sun = new THREE.DirectionalLight(0xffffff, 1.2); sun.position.set(10, 25, 10); scene.add(sun);
const arena = buildArena(scene);
G.hitsWall = arena.hits;
const zoneMesh = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 60, 64, 1, true),
  new THREE.MeshBasicMaterial({ color: 0xff3b30, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false, fog: false }));
zoneMesh.position.y = 30; zoneMesh.visible = false; scene.add(zoneMesh);

const combat = new Combat(G); G.combat = combat;
const controls = new Controls(canvas, a => onAction(a));
function onAction(a) {
  if (typeof a === 'number') tryCast(a);
  else if (a === 'jump') tryJump();
  else if (a === 'dash') tryDash();
  else if (a === 'lock') { G.lock = !G.lock; $('#bLock').classList.toggle('on', G.lock); } // khóa vai: nhân vật luôn quay theo camera
}
const ray = new THREE.Raycaster();

// ---------- Người chơi ----------
function label(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const x = c.getContext('2d');
  x.font = 'bold 34px sans-serif'; x.textAlign = 'center'; x.lineWidth = 5; x.strokeStyle = '#000'; x.fillStyle = hex(color);
  x.strokeText(text, 128, 44); x.fillText(text, 128, 44);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
  s.scale.set(3, 0.75, 1); return s;
}

function makeMesh(p) {
  const root = new THREE.Group(), model = buildModel(p.hero), rot = model.rot;
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.8, 1, 24), new THREE.MeshBasicMaterial({ color: TEAM_COLORS[p.team % TEAM_COLORS.length], side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.y = 0.05; root.add(ring);
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(1.1, 20), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.04; root.add(shadow); // bóng mờ dưới chân cho nhân vật bám đất
  root.add(rot);
  const bar = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.18), new THREE.MeshBasicMaterial({ color: 0x000000, depthTest: false }));
  const fg = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.18), new THREE.MeshBasicMaterial({ color: p.id === G.myId ? 0x4ade80 : 0xff5252, depthTest: false }));
  fg.position.z = 0.01; bg.renderOrder = 10; fg.renderOrder = 11; bar.add(bg, fg); bar.position.y = (model.h || 2.3) + 0.4; root.add(bar);
  const nm = label(p.name, TEAM_COLORS[p.team % TEAM_COLORS.length]); nm.position.y = (model.h || 2.3) + 0.9; root.add(nm);
  const curse = new THREE.Mesh(new THREE.RingGeometry(1.2, 1.4, 32), new THREE.MeshBasicMaterial({ color: 0xb06bff, side: THREE.DoubleSide, transparent: true, opacity: 0.8, depthWrite: false }));
  curse.rotation.x = -Math.PI / 2; curse.position.y = 0.09; curse.visible = false; root.add(curse); // vòng tím khi bị nguyền/chậm
  const mark = new THREE.Mesh(new THREE.RingGeometry(0.75, 0.95, 4), new THREE.MeshBasicMaterial({ color: 0xff3b30, side: THREE.DoubleSide, transparent: true, opacity: 0.9, depthWrite: false }));
  mark.rotation.x = -Math.PI / 2; mark.position.y = 0.11; mark.visible = false; root.add(mark); // dấu ấn săn mồi (hình thoi đỏ)
  const aura = new THREE.Mesh(new THREE.SphereGeometry(1.9, 16, 12), new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.22, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }));
  aura.position.y = 1.2; aura.visible = false; root.add(aura); // cầu Aether khi bất tử
  root.userData = { rot, model, bar, fg, curse, mark, aura, ring, shadow };
  scene.add(root); return root;
}

function addPlayer(i) {
  const H = HEROES[i.hero];
  const p = {
    id: i.id, name: i.name, hero: i.hero, team: i.team, bot: i.bot, hp: i.mhp || H.hp, maxhp: i.mhp || H.hp,
    pos: new THREE.Vector3(i.x, 0, i.z), spawn: { x: i.x, z: i.z }, kv: { x: 0, z: 0 }, cd: [0, 0, 0, 0, 0],
    stun: 0, alive: true, face: Math.atan2(-i.x, -i.z), swing: 0, dash: null, buff: null, shield: 0, shieldT: 0,
    ai: { t: 0, s: 1, a: 0.5 }, tg: { x: i.x, z: i.z, f: 0 }, bob: 0, moving: false, rg: 0, oc: 10, pose: null, hist: [], hT: 0, slow: null, mark: null, combo: 0, comboT: 0, en: H.energy ? H.energy.max : 0, stk: 0, stkT: 0, inv: 0, float: 0, floatMax: 0, y: 0, vy: 0, grounded: true, jumps: 0, dcd: 0, hitF: 0, fz: 0, fzT: 0, frozen: 0
  };
  p.ctl = p.id === G.myId || ((p.bot || i.mob) && G.auth);
  if (i.mob) { p.mob = true; p.lvl = i.lvl; p.camp = i.camp; p.dmgMul = i.dmgMul; p.xpv = i.xpv; p.beliv = i.beliv; p.boss = !!i.boss; p.home = { x: i.x, z: i.z }; }
  else if (G.adv) { p.lvl = 1; p.xp = 0; p.beli = 0; p.pts = 0; p.st = { hp: 0, dmg: 0, spd: 0 }; p.quest = questFor(1); p.dmgMul = 1; }
  p.mesh = makeMesh(p);
  G.players.set(p.id, p); return p;
}

function removePlayer(id) {
  const p = G.players.get(id); if (!p) return;
  scene.remove(p.mesh); G.players.delete(id);
}

// ---------- Di chuyển ----------
function step(p, dt, mx, mz) {
  const H = HEROES[p.hero];
  let vx = 0, vz = 0;
  const l = Math.hypot(mx, mz);
  if (p.dash) { vx = p.dash.vx; vz = p.dash.vz; }
  else if (p.stun <= 0 && l > 0.05 && !(p.pose && (p.pose.k === 'cross' || p.pose.k === 'rewind'))) {
    const sp = H.speed * (p.buff ? p.buff.speed : 1) * (p.oc > 4 && !p.mob ? 1.9 : 1) * (1 + ((p.st && p.st.spd) || 0) * 0.01) * (p.slow ? p.slow.m : 1) * (1 + (p.stk || 0) * (H.stackSpeed || 0)); // chạy nhanh khi ngoài giao tranh
    vx = (mx / Math.max(l, 1)) * sp; vz = (mz / Math.max(l, 1)) * sp;
    p.face = Math.atan2(mx, mz);
  }
  p.moving = Math.hypot(vx, vz) > 0.5;
  const k = Math.exp(-7 * dt); p.kv.x *= k; p.kv.z *= k;
  p.pos.x += (vx + p.kv.x) * dt; p.pos.z += (vz + p.kv.z) * dt;
  arena.resolve(p.pos, p.dash && p.dash.air ? -1 : 0.5, p.y || 0); // đang nhảy thì bay qua vật cản
  const fl = arena.floorAt(p.pos.x, p.pos.z, p.y || 0); // trọng lực, đứng được trên đỉnh tường/cột
  p.vy = (p.vy || 0) - 30 * dt; p.y = (p.y || 0) + p.vy * dt;
  if (p.y <= fl) { p.y = fl; p.vy = 0; }
  p.grounded = p.y <= fl + 0.05; if (p.grounded) p.jumps = 0;
}

// ---------- Bot AI (chỉ chạy trên host) ----------
function botAI(p, dt) {
  if (p.pose) return { x: 0, z: 0 };
  const Z = zoneAt(G), dc = Math.hypot(p.pos.x - Z.cx, p.pos.z - Z.cz);
  if (dc > Z.r - 15) return { x: -(p.pos.x - Z.cx) / dc, z: -(p.pos.z - Z.cz) / dc }; // chạy vào vùng an toàn
  const en = combat.enemies(p);
  if (!en.length || p.stun > 0) return { x: 0, z: 0 };
  let tg = en[0], bd = 1e9;
  for (const t of en) { const d = Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z); if (d < bd) { bd = d; tg = t; } }
  const dx = tg.pos.x - p.pos.x, dz = tg.pos.z - p.pos.z, d = Math.hypot(dx, dz) || 1, nx = dx / d, nz = dz / d;
  const H = HEROES[p.hero], ranged = H.skills[0].type === 'projectile', pref = ranged ? 9 : 2.2;
  p.ai.t -= dt; if (p.ai.t <= 0) { p.ai.t = 1 + Math.random() * 1.5; p.ai.s = Math.random() < 0.5 ? -1 : 1; }
  let mx = 0, mz = 0;
  if (d > pref + 1) { mx = nx; mz = nz; } else if (ranged && d < pref - 2) { mx = -nx; mz = -nz; }
  mx += -nz * p.ai.s * 0.5; mz += nx * p.ai.s * 0.5;
  // chống kẹt tường/cây: nếu gần như đứng yên thì đi vòng sang bên
  p.ai.k = (p.ai.k || 0) - dt;
  if (p.ai.k <= 0) {
    p.ai.k = 0.6;
    if (p.ai.px !== undefined && Math.hypot(p.pos.x - p.ai.px, p.pos.z - p.ai.pz) < 0.8 && d > pref + 2) p.ai.u = 1.2 + Math.random();
    p.ai.px = p.pos.x; p.ai.pz = p.pos.z;
  }
  if (p.ai.u > 0) { p.ai.u -= dt; mx = -nz * p.ai.s; mz = nx * p.ai.s; }
  p.ai.a -= dt;
  if (p.ai.a <= 0) {
    for (const i of [4, 1, 2, 3, 0]) {
      const s = H.skills[i]; if (p.cd[i] > 0 || (s.cost && p.en < s.cost)) continue;
      let ok = false;
      if (s.type === 'melee') ok = d < s.range + 0.5;
      else if (s.type === 'projectile') ok = d < 14;
      else if (s.type === 'dash') ok = s.dmg > 0 ? (d < s.dist + 1 && d > 2.5) : (d < 4 && p.hp < p.maxhp * 0.4);
      else if (s.type === 'hook') ok = d > 8 && d < 21;
      else if (s.type === 'aurora') ok = d < 8 || p.hp < p.maxhp * 0.5;
      else if (s.type === 'warp') ok = d < (s.offset || 0) + s.radius;
      else if (s.type === 'rewind') ok = p.hp < p.maxhp * 0.45 && d < 12;
      else if (s.type === 'leap') ok = d < s.dist + 2 && d > 4;
      else if (s.type === 'storm') ok = d < s.dist + 4 && d > 2;
      else if (s.type === 'aoe') ok = d < (s.offset || 0) + s.radius;
      else if (s.type === 'buff') ok = d < 10;
      else if (s.type === 'heal') ok = p.hp < p.maxhp * 0.7 || (s.dmg && d < s.radius);
      if (ok && (i !== 4 || Math.random() < 0.5)) {
        combat.cast(p, i, nx, nz, d);
        if (G.net) G.net.bcast({ t: 'cast', id: p.id, i, dx: nx, dz: nz, x: d });
        break;
      }
    }
    p.ai.a = 0.3 + Math.random() * 0.4;
  }
  return { x: mx * 0.9, z: mz * 0.9 };
}

// ---------- Cast của người chơi ----------
// kẻ địch đang nằm trong tâm ngắm (hút nhắm): trả về { t, d } hoặc null
function findTarget(p) {
  const fx = Math.sin(G.yaw), fz = Math.cos(G.yaw), cone = Math.cos(controls.touch ? 0.6 : 0.25);
  let best = null, bd = 22;
  for (const t of combat.enemies(p)) {
    const ox = t.pos.x - p.pos.x, oz = t.pos.z - p.pos.z, d = Math.hypot(ox, oz);
    if (d > 0.1 && d < bd && (ox * fx + oz * fz) / d > cone) { bd = d; best = t; }
  }
  return best ? { t: best, d: bd } : null;
}
function aimDir(p) {
  const f = findTarget(p);
  if (f) return { x: (f.t.pos.x - p.pos.x) / f.d, z: (f.t.pos.z - p.pos.z) / f.d };
  // không có mục tiêu: nhắm vào điểm tâm ngắm cách 30m (bù độ lệch vai của camera)
  const fx = Math.sin(G.yaw), fz = Math.cos(G.yaw), cp = Math.cos(G.pitch), D = G.camD || 6.5, off = G.camOff || 0.7;
  const ax = fx * (30 - D * cp) - fz * off, az = fz * (30 - D * cp) + fx * off, l = Math.hypot(ax, az) || 1;
  return { x: ax / l, z: az / l };
}

function tryJump() { // nhảy, bấm lần 2 trên không = nhảy đôi
  const p = G.me;
  if (!G.running || !p || !p.alive || p.stun > 0 || p.float > 0) return;
  if (p.grounded) { p.vy = 11; p.jumps = 1; p.grounded = false; combat.sfx('dash'); }
  else if ((p.jumps || 0) < 2) { p.vy = 9.5; p.jumps = 2; combat.ring(p.pos.x, p.pos.z, HEROES[p.hero].color, 1.4, 0.3); combat.burst(p.pos, HEROES[p.hero].color, 6, 3); }
}
function startDash(p, dx, dz) { // lướt ngắn theo hướng chạy (hoặc hướng camera nếu đứng yên)
  const T = 6 / 34;
  p.dash = { t: T, T, vx: dx * 34, vz: dz * 34, nx: dx, nz: dz, sk: { dmg: 0 }, hit: new Set(), kind: 'dash', air: false, h: 0 };
  p.face = Math.atan2(dx, dz); combat.ring(p.pos.x, p.pos.z, HEROES[p.hero].color, 1.6, 0.25); combat.sfx('dash');
}
function tryDash() {
  const p = G.me;
  if (!G.running || !p || !p.alive || p.stun > 0 || p.float > 0 || p.pose || p.dash || p.dcd > 0) return;
  const m = controls.getMove(), fx = Math.sin(G.yaw), fz = Math.cos(G.yaw);
  let mx = fx, mz = fz;
  if (Math.hypot(m.x, m.z) > 0.2) { mx = fx * -m.z - fz * m.x; mz = fz * -m.z + fx * m.x; }
  const l = Math.hypot(mx, mz) || 1; mx /= l; mz /= l;
  p.dcd = 2.5; startDash(p, mx, mz);
  if (G.net) G.net.send({ t: 'dsh', id: p.id, dx: mx, dz: mz });
}
function flashEnergy() { const e = $('#en'); e.classList.add('low'); setTimeout(() => e.classList.remove('low'), 300); }
function tryCast(i) {
  const p = G.me;
  if (!G.running || !p || !p.alive || p.stun > 0 || p.cd[i] > 0 || (p.pose && p.pose.k !== 'land')) return;
  const a = aimDir(p), SK = HEROES[p.hero].skills[i];
  if (SK.cost && p.en < SK.cost) { flashEnergy(); return; }
  let xr; if (SK.type === 'hook') { const f = findTarget(p); xr = f ? f.d : -1; } // khoảng cách tới mục tiêu đang khóa
  combat.cast(p, i, a.x, a.z, xr);
  if (G.net) G.net.send({ t: 'cast', id: p.id, i, dx: a.x, dz: a.z, x: xr });
}

// ---------- Hạ gục / hồi sinh / kết thúc ----------
function feed(t) {
  const d = document.createElement('div'); d.textContent = t; $('#feed').appendChild(d);
  setTimeout(() => d.remove(), 4000);
}
function onDead(m) {
  const v = G.players.get(m.id); if (!v) return;
  v.alive = false; v.hp = 0; v.dash = null; v.mesh.visible = false;
  G.score = m.score; G.stats = m.stats;
  const k = m.by && G.players.get(m.by);
  if (!v.mob || v.boss) feed(`${k ? k.name + ' ⚔ ' : '☠ Bo ⚔ '}${v.name}`);
  combat.burst(v.pos, HEROES[v.hero].color, 24, 6);
}
function respawn(m) {
  const p = G.players.get(m.id); if (!p) return;
  if (p === G.me) { G.yaw = Math.atan2(-m.x, -m.z); G.cam = null; }
  p.alive = true; p.hp = p.maxhp; p.pos.set(m.x, 0, m.z); p.tg = { x: m.x, z: m.z, f: p.face };
  p.stun = 0; p.kv = { x: 0, z: 0 }; p.shield = 0; p.mesh.visible = true;
  combat.ring(m.x, m.z, 0xffffff, 3, 0.6);
}
function respawnPos(v) {
  const Z = zoneAt(G); let x = v.spawn.x, z = v.spawn.z;
  if (Math.hypot(x - Z.cx, z - Z.cz) > Z.r * 0.85) { const a = Math.random() * 6.283, r = Z.r * 0.6 * Math.random(); x = Z.cx + Math.cos(a) * r; z = Z.cz + Math.sin(a) * r; }
  return { x, z };
}
G.kill = function (v, src) {
  if (!v.alive) return;
  registerKill(G, v, src);
  if (v.mob) { mobKilled(v, src); return; }
  if (G.adv) { v.beli = Math.floor((v.beli || 0) * 0.9); sendProg(v, {}); } // chết mất 10% Beli
  const m = { t: 'dead', id: v.id, by: src ? src.id : null, score: G.score, stats: G.stats };
  if (G.net) G.net.bcast(m);
  onDead(m);
  setTimeout(() => {
    if (!G.running) return;
    const sp = respawnPos(v);
    const r = { t: 'respawn', id: v.id, x: sp.x, z: sp.z };
    if (G.net) G.net.bcast(r);
    respawn(r);
  }, 3000);
};
function endGame(labelText) {
  if (G.ended) return;
  const m = { t: 'end', label: labelText, stats: G.stats, score: G.score };
  if (G.net) G.net.bcast(m);
  showEnd(m);
}
function showEnd(m) {
  if (G.ended) return;
  G.ended = true; G.running = false; G.stats = m.stats;
  const rows = [...G.players.values()].sort((a, b) => (G.stats[b.id]?.[0] || 0) - (G.stats[a.id]?.[0] || 0))
    .map(p => `<tr><td>${p.name}</td><td>${HEROES[p.hero].name}</td><td>${G.stats[p.id]?.[0] || 0}</td><td>${G.stats[p.id]?.[1] || 0}</td></tr>`).join('');
  $('#endTitle').textContent = m.label;
  $('#endTable').innerHTML = '<tr><th>Tên</th><th>Tướng</th><th>Hạ</th><th>Chết</th></tr>' + rows;
  $('#end').classList.remove('hide');
}
$('#bBack').onclick = () => location.reload();

// ---------- Bắt đầu ván ----------
function startGame(mode, list) {
  for (const p of G.players.values()) scene.remove(p.mesh);
  G.players.clear(); combat.reset();
  G.mode = mode; G.stats = {}; G.score = {}; G.ended = false; G.adv = !!MODES[mode].adv;
  list.forEach(i => { addPlayer(i); G.stats[i.id] = [0, 0]; G.score[i.team] = 0; });
  G.me = G.players.get(G.myId);
  G.yaw = Math.atan2(-G.me.pos.x, -G.me.pos.z); G.pitch = 0.32; G.cam = null; // nhìn về tâm bản đồ
  G.time = MODES[mode].time; G.running = true; G.zt = 0; zoneMesh.visible = !G.adv;
  $('#menu').classList.add('hide'); $('#pick').classList.add('hide'); clearInterval(G.pt); $('#hud').classList.remove('hide'); $('#adv').classList.toggle('hide', !G.adv); $('#stats').classList.add('hide'); if (G.adv) renderStats(); $('#end').classList.add('hide');
  $('#feed').innerHTML = '';
  const H = HEROES[G.me.hero];
  document.querySelectorAll('#btns button[data-i]').forEach(b => { b.querySelector('b').textContent = H.skills[+b.dataset.i].n; });
  combat.sfx('buff');
}
function hostStart() {
  clearInterval(G.pt); G.phase = 'play';
  const keys = Object.keys(HEROES).filter(k => !HEROES[k].mob);
  G.lobby.forEach(x => { if (!HEROES[x.hero]) x.hero = keys[Math.floor(Math.random() * keys.length)]; });
  const list = assign(G.modeKey, G.lobby);
  if (G.net) G.net.bcast({ t: 'start', mode: G.modeKey, players: list });
  startGame(G.modeKey, list);
}

// ---------- Chế độ Phiêu Lưu: quái, kinh nghiệm, nhiệm vụ, chỉ số ----------
function mobAI(p, dt) { // chỉ chạy trên host
  if (p.stun > 0) return { x: 0, z: 0 };
  let tg = null, bd = 1e9;
  for (const t of combat.enemies(p)) {
    if (Math.hypot(t.pos.x, t.pos.z - 2) < 12) continue; // quảng trường trung tâm là khu an toàn
    const d = Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z); if (d < bd) { bd = d; tg = t; }
  }
  const hx = p.home.x - p.pos.x, hz = p.home.z - p.pos.z, hd = Math.hypot(hx, hz);
  if (!tg || bd > (p.agro ? 40 : 18) || hd > 45) { // mất mục tiêu: về trại, hồi máu
    p.agro = false;
    if (hd > 3) return { x: hx / hd, z: hz / hd };
    if (G.auth && p.hp < p.maxhp) { p.rgm = (p.rgm || 0) + dt * p.maxhp * 0.2; if (p.rgm >= 10) { combat.heal(p, Math.floor(p.rgm)); p.rgm = 0; } }
    return { x: 0, z: 0 };
  }
  p.agro = true;
  const nx = (tg.pos.x - p.pos.x) / bd, nz = (tg.pos.z - p.pos.z) / bd, sk = HEROES[p.hero].skills[0], ranged = sk.type === 'projectile', pref = ranged ? 8 : sk.range * 0.8;
  p.ai.a -= dt;
  if (p.ai.a <= 0 && p.cd[0] <= 0 && bd < (ranged ? 16 : sk.range + 0.5)) {
    combat.cast(p, 0, nx, nz); if (G.net) G.net.bcast({ t: 'cast', id: p.id, i: 0, dx: nx, dz: nz }); p.ai.a = 0.2;
  }
  if (bd > pref) return { x: nx * 0.9, z: nz * 0.9 };
  if (ranged && bd < pref - 3) return { x: -nx * 0.6, z: -nz * 0.6 };
  return { x: 0, z: 0 };
}
function applyStats(h) {
  const old = h.maxhp;
  h.maxhp = HEROES[h.hero].hp + (h.lvl - 1) * 25 + h.st.hp * 40;
  h.dmgMul = 1 + (h.lvl - 1) * 0.03 + h.st.dmg * 0.04;
  if (h.maxhp > old) h.hp = Math.min(h.maxhp, h.hp + (h.maxhp - old));
}
function sendProg(h, f) {
  const m = { t: 'prog', id: h.id, lvl: h.lvl, xp: h.xp, beli: h.beli, pts: h.pts, st: h.st, q: h.quest, mhp: h.maxhp, hp: Math.round(h.hp), dm: h.dmgMul, up: !!f.up, done: !!f.done };
  if (G.net) G.net.bcast(m);
  applyProg(m);
}
function applyProg(m) {
  const p = G.players.get(m.id); if (!p) return;
  p.lvl = m.lvl; p.xp = m.xp; p.beli = m.beli; p.pts = m.pts; p.st = m.st; p.quest = m.q; p.maxhp = m.mhp; p.hp = m.hp; p.dmgMul = m.dm;
  if (p === G.me) { if (m.up) feed('⬆ LÊN CẤP ' + m.lvl + '! +3 điểm chỉ số'); if (m.done) feed('✔ Hoàn thành nhiệm vụ!'); renderStats(); }
}
function awardKill(src, v) { // mọi người chơi trong 25m quanh quái đều nhận thưởng (co-op)
  const group = [...G.players.values()].filter(h => !h.mob && h.alive && (h === src || Math.hypot(h.pos.x - v.pos.x, h.pos.z - v.pos.z) < 25));
  for (const h of group) {
    h.xp += v.xpv; h.beli += v.beliv;
    let done = false, up = false; const q = h.quest;
    if (q && q.camp === v.camp) { q.got += v.boss ? 3 : 1; if (q.got >= q.need) { h.xp += q.xp; h.beli += q.beli; done = true; } }
    while (h.lvl < LV_MAX && h.xp >= xpNeed(h.lvl)) { h.xp -= xpNeed(h.lvl); h.lvl++; h.pts += 3; up = true; }
    if (done) h.quest = questFor(h.lvl);
    applyStats(h); if (up) h.hp = h.maxhp;
    sendProg(h, { up, done });
  }
}
function mobKilled(v, src) {
  const m = { t: 'dead', id: v.id, by: src ? src.id : null, score: G.score, stats: G.stats };
  if (G.net) G.net.bcast(m);
  onDead(m);
  if (src && !src.mob) awardKill(src, v);
  setTimeout(() => {
    if (!G.running) return;
    const r = { t: 'respawn', id: v.id, x: v.home.x, z: v.home.z };
    if (G.net) G.net.bcast(r); respawn(r);
  }, v.boss ? 90000 : 25000);
}
function hostStat(h, k) { if (!h || h.mob || h.pts <= 0 || !['hp', 'dmg', 'spd'].includes(k)) return; h.pts--; h.st[k]++; applyStats(h); sendProg(h, {}); }
function statUp(k) { if (G.net && !G.net.isHost) G.net.send({ t: 'stat', k }); else hostStat(G.me, k); }
function renderStats() {
  const me = G.me; if (!G.adv || !me || !me.st) return;
  $('#pts').textContent = me.pts ? '+' + me.pts : '';
  $('#stats').innerHTML = [['hp', 'Sinh lực (+40 máu)'], ['dmg', 'Sát thương (+4%)'], ['spd', 'Tốc độ (+1%)']]
    .map(([k, n]) => `<div class="sr"><span>${n}: ${me.st[k]}</span><button data-k="${k}" ${me.pts ? '' : 'disabled'}>+</button></div>`).join('') + `<small>Điểm còn lại: ${me.pts}</small>`;
  $('#stats').querySelectorAll('button').forEach(b => { b.onclick = () => statUp(b.dataset.k); });
}
$('#bStat').onclick = () => { $('#stats').classList.toggle('hide'); renderStats(); };

// ---------- Mạng ----------
function onMsg(m, conn) {
  const host = G.net && G.net.isHost;
  switch (m.t) {
    case 'join': {
      if (!host || G.running || !HEROES[m.hero]) return;
      const pid = conn.peer, nmv = String(m.name || 'Player').slice(0, 12);
      const e = G.lobby.find(x => x.id === pid);
      if (e) { e.name = nmv; e.hero = m.hero; e.ready = !!m.ready; }
      else if (G.phase !== 'pick' && G.lobby.length < 8) G.lobby.push({ id: pid, name: nmv, hero: m.hero, ready: false });
      G.net.bcast({ t: 'lobby', list: G.lobby }); renderLobby(); checkAllReady(); break;
    }
    case 'lobby': G.lobby = m.list; renderLobby(); break;
    case 'pick': openPick(m.mode, m.secs); break;
    case 'start': startGame(m.mode, m.players); break;
    case 'st': {
      if (host && m.id !== conn.peer) break;
      const p = G.players.get(m.id);
      if (p && !p.ctl) p.tg = { x: m.x, z: m.z, f: m.f, y: m.y || 0 };
      if (host) G.net.bcast(m, conn);
      break;
    }
    case 'cast': {
      if (host && m.id !== conn.peer) break;
      const p = G.players.get(m.id);
      if (p && !p.ctl && p.alive) combat.cast(p, m.i, m.dx, m.dz, m.x);
      if (host) G.net.bcast(m, conn);
      break;
    }
    case 'hit': combat.applyHit(m); break;
    case 'dead': onDead(m); break;
    case 'respawn': respawn(m); break;
    case 'end': showEnd(m); break;
    case 'left': removePlayer(m.id); break;
    case 'prog': applyProg(m); break;
    case 'dsh': { if (host && m.id !== conn.peer) break; const p = G.players.get(m.id); if (p && !p.ctl && p.alive) startDash(p, m.dx, m.dz); if (host) G.net.bcast(m, conn); break; }
    case 'stat': if (host) hostStat(G.players.get(conn.peer), m.k); break;
  }
}
function onClose(id) {
  if (G.net && G.net.isHost) {
    G.lobby = G.lobby.filter(x => x.id !== id);
    if (G.running) { removePlayer(id); G.net.bcast({ t: 'left', id }); } else { G.net.bcast({ t: 'lobby', list: G.lobby }); renderLobby(); checkAllReady(); }
  } else { alert('Mất kết nối với chủ phòng.'); location.reload(); }
}

// ---------- Menu ----------
const ICON = { asasin: '🥷', timeclown: '🤡', frostempress: '❄️', crimsonsamurai: '⚔️', titanbrawler: '👊' };
const ic = k => ICON[k] || '⚔️';
const TYPE_VI = { melee: 'Cận chiến', projectile: 'Đạn bay', dash: 'Lướt', leap: 'Nhảy', hook: 'Móc kéo', aurora: 'Tuyệt kỹ', storm: 'Tuyệt kỹ', warp: 'Vùng thời gian', rewind: 'Tuyệt kỹ', aoe: 'Vùng', buff: 'Tăng cường', heal: 'Hồi máu' };
const SLOT = ['Đánh thường', 'Kỹ năng 1', 'Kỹ năng 2', 'Kỹ năng 3', 'Tuyệt chiêu'];
const MODE_DESC = { '1v1': 'Song đấu', '2v2': 'Đội 2 người', '3v3': 'Đội 3 người', '4v4': 'Đội 4 người', adv: 'Co-op: cày cấp, nhiệm vụ, trùm', 'ffa': '8 người tự đấu' };
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nm = () => ($('#name').value.trim() || 'Hero').slice(0, 12);
const msg = t => { $('#msg').textContent = t; };
G.locked = false; G.phase = 'menu';

function checkAllReady() {
  if (G.phase === 'pick' && G.auth && G.lobby.length && G.lobby.every(x => x.ready)) hostStart();
}
function syncLobbyMe() {
  if (!G.net || G.net.isHost) {
    const e = G.lobby.find(x => x.id === 'host');
    if (e) { e.name = nm(); e.hero = G.hero; e.ready = !!G.locked; }
    if (G.net) G.net.bcast({ t: 'lobby', list: G.lobby });
    renderLobby(); checkAllReady();
  } else G.net.send({ t: 'join', id: G.myId, name: nm(), hero: G.hero, ready: !!G.locked });
}

// chế độ chơi
const mc = $('#modes');
for (const k in MODES) {
  const b = document.createElement('button');
  b.className = 'mode' + (k === G.modeKey ? ' sel' : '');
  b.innerHTML = `<b>${MODES[k].label}</b><small>${MODE_DESC[k]}</small>`;
  b.onclick = () => { G.modeKey = k; [...mc.children].forEach(c => c.classList.remove('sel')); b.classList.add('sel'); };
  mc.appendChild(b);
}

// màn chọn tướng (hiện khi bắt đầu trận)
const hc = $('#heroes');
for (const k in HEROES) {
  if (HEROES[k].mob) continue;
  const H = HEROES[k], d = document.createElement('div');
  d.className = 'tile'; d.dataset.k = k; d.style.setProperty('--c', hex(H.color));
  d.innerHTML = `<span class="ic">${ic(k)}</span><b>${H.name}</b><small>${H.role}</small>`;
  d.onclick = () => { if (G.locked) return; G.hero = k; showHero(); syncLobbyMe(); };
  hc.appendChild(d);
}
function showHero() {
  const H = HEROES[G.hero];
  [...hc.children].forEach(t => t.classList.toggle('sel', t.dataset.k === G.hero));
  const dt = $('#detail'); dt.style.setProperty('--c', hex(H.color));
  dt.innerHTML = `<div class="dn"><span>${ic(G.hero)}</span><div><h3>${H.name}</h3><em>${H.role}</em></div></div>
    <div class="st"><label>Máu</label><i><u style="width:${H.hp / 12}%"></u></i><span>${H.hp}</span></div>
    <div class="st"><label>Tốc độ</label><i><u style="width:${(H.speed / 7.4) * 100}%"></u></i><span>${H.speed}</span></div>
    <p class="pas">⭐ ${H.passive}</p>
    <ul>${H.skills.map((s, i) => `<li><b>${SLOT[i]}: ${s.n}</b><small>${TYPE_VI[s.type]} · hồi chiêu ${s.cd}s</small><small>${s.d || ''}</small></li>`).join('')}</ul>`;
}
function renderLobby() {
  $('#plist').innerHTML = G.lobby.map(x => `<div class="pl"><span>${x.id === 'host' ? '👑' : '👤'} ${esc(x.name)}</span></div>`).join('');
  $('#roster').innerHTML = G.lobby.map(x => `<div class="pl"><span>${esc(x.name)}</span><em class="${x.ready ? 'ok' : ''}">${x.ready && HEROES[x.hero] ? '✓ ' + HEROES[x.hero].name : 'đang chọn…'}</em></div>`).join('');
}
const pkTick = () => { $('#pkTime').textContent = '⏱ ' + Math.max(0, G.pickT) + 's'; };
function openPick(mode, secs) {
  G.modeKey = mode; G.phase = 'pick'; G.locked = false;
  $('#menu').classList.add('hide'); $('#pick').classList.remove('hide');
  $('#pkMode').textContent = MODES[mode].label;
  const b = $('#bReady'); b.disabled = false; b.textContent = 'SẴN SÀNG'; hc.classList.remove('lock');
  showHero(); renderLobby(); syncLobbyMe();
  clearInterval(G.pt); G.pickT = secs; pkTick();
  G.pt = setInterval(() => { G.pickT--; pkTick(); if (G.pickT <= 0) { clearInterval(G.pt); if (G.auth) hostStart(); } }, 1000);
}
function beginPick() {
  G.lobby.forEach(x => { x.ready = false; });
  if (G.net) { G.net.bcast({ t: 'pick', mode: G.modeKey, secs: 25 }); G.net.bcast({ t: 'lobby', list: G.lobby }); }
  openPick(G.modeKey, 25);
}
$('#bReady').onclick = () => {
  if (G.locked) return;
  G.locked = true; $('#bReady').disabled = true; $('#bReady').textContent = 'ĐÃ SẴN SÀNG ✓'; hc.classList.add('lock');
  syncLobbyMe();
};
$('#bLeave').onclick = () => location.reload();

function showLobby(code, isHost) {
  $('#home').classList.add('hide'); $('#lobby').classList.remove('hide');
  $('#rc').textContent = code; renderLobby();
  $('#bStart').classList.toggle('hide', !isHost); $('#wait').classList.toggle('hide', isHost);
  mc.classList.toggle('dis', !isHost);
}
$('#bOff').onclick = () => {
  G.auth = true; G.net = null; G.myId = 'host';
  G.lobby = [{ id: 'host', name: nm(), hero: G.hero, ready: false }]; beginPick();
};
$('#bHost').onclick = async () => {
  const code = String(Math.floor(10000 + Math.random() * 90000)), net = new Net();
  net.onmsg = onMsg; net.onclose = onClose; msg('Đang tạo phòng…');
  try { await net.host(code); } catch (e) { msg('Không tạo được phòng: ' + (e.type || e)); return; }
  msg(''); G.net = net; G.auth = true; G.myId = 'host';
  G.lobby = [{ id: 'host', name: nm(), hero: G.hero, ready: false }]; showLobby(code, true);
};
$('#bJoin').onclick = async () => {
  const code = $('#code').value.trim(); if (!code) { msg('Nhập mã phòng'); return; }
  const net = new Net(); net.onmsg = onMsg; net.onclose = onClose; msg('Đang vào phòng…');
  try { await net.join(code); } catch (e) { msg('Không vào được phòng: ' + (e.type || e)); return; }
  msg(''); G.net = net; G.auth = false; G.myId = net.id;
  net.send({ t: 'join', id: net.id, name: nm(), hero: G.hero, ready: false }); showLobby(code, false);
};
$('#bStart').onclick = beginPick;

// ---------- Xem trước 3D hero ở màn chọn tướng ----------
const prevScene = new THREE.Scene(); prevScene.background = new THREE.Color(0x0d1530);
prevScene.add(new THREE.HemisphereLight(0x9fb8ff, 0x101830, 1.1));
const prevSun = new THREE.DirectionalLight(0xffffff, 1.4); prevSun.position.set(3, 5, 4); prevScene.add(prevSun);
const prevRim = new THREE.PointLight(0x2aa8ff, 30, 12); prevRim.position.set(-2.5, 2.2, -2.5); prevScene.add(prevRim);
const prevFloor = new THREE.Mesh(new THREE.CircleGeometry(1.6, 40), new THREE.MeshStandardMaterial({ color: 0x101a3a, roughness: 0.8 }));
prevFloor.rotation.x = -Math.PI / 2; prevScene.add(prevFloor);
const prevRing = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.6, 48), new THREE.MeshBasicMaterial({ color: 0x2aa8ff, side: THREE.DoubleSide }));
prevRing.rotation.x = -Math.PI / 2; prevRing.position.y = 0.01; prevScene.add(prevRing);
const prevCam = new THREE.PerspectiveCamera(32, 1, 0.1, 50);
let prevModel = null, prevKey = null, prevRot = 0.6, prevT = 0, dragX = null;
const prevEl = $('#prev');
prevEl.addEventListener('pointerdown', e => { dragX = e.clientX; prevEl.setPointerCapture(e.pointerId); });
prevEl.addEventListener('pointermove', e => { if (dragX !== null) { prevRot += (e.clientX - dragX) * 0.012; dragX = e.clientX; } });
const endDrag = () => { dragX = null; };
prevEl.addEventListener('pointerup', endDrag); prevEl.addEventListener('pointercancel', endDrag);
function renderPreview(dt) {
  const r = prevEl.getBoundingClientRect();
  if (r.width < 10 || r.height < 10) return false;
  if (!prevModel || prevKey !== G.hero) {
    if (prevModel) prevScene.remove(prevModel.rot);
    prevModel = buildModel(G.hero); prevKey = G.hero; prevScene.add(prevModel.rot);
  }
  prevT += dt; if (dragX === null) prevRot += dt * 0.5;
  const k = prevT % 9, fake = { moving: false, swing: 0, dash: null, pose: null, stun: 0, bob: 0, oc: 0 };
  if (k < 0.25) fake.swing = 0.25 - k;
  else if (k >= 0.5 && k < 1.6) { fake.moving = true; fake.bob = prevT * 10; fake.oc = 10; }
  else if (k >= 2 && k < 3) fake.dash = { kind: 'leap', t: 3 - k, T: 1, h: 2.2 };
  else if (k >= 4 && k < 4.5) fake.pose = { k: G.hero === 'timeclown' ? 'rewind' : 'cross', t: 4.5 - k };
  else if (k >= 4.5 && k < 5.5) { fake.dash = { kind: 'rush', t: 5.5 - k, T: 1, h: 0 }; fake.pose = { k: 'rush', t: 1 }; }
  else if (k >= 5.5 && k < 5.9) fake.pose = { k: 'slash', t: 5.9 - k };
  else if (k >= 7 && k < 8) fake.dash = { kind: 'kick', t: 8 - k, T: 1, h: 0.8 };
  prevModel.update(fake, dt); prevModel.rot.rotation.y = prevRot;
  prevCam.aspect = r.width / r.height; prevCam.fov = prevCam.aspect < 0.8 ? 42 : 32; prevCam.updateProjectionMatrix();
  const mh = prevModel.h || 2.3; prevCam.position.set(0, mh * 0.65, mh * 2.45); prevCam.lookAt(0, mh * 0.48, 0);
  renderer.setScissorTest(false); renderer.setClearColor(0x050814, 1); renderer.clear();
  const y = innerHeight - r.bottom;
  renderer.setScissorTest(true); renderer.setViewport(r.left, y, r.width, r.height); renderer.setScissor(r.left, y, r.width, r.height);
  renderer.render(prevScene, prevCam);
  renderer.setScissorTest(false); renderer.setViewport(0, 0, innerWidth, innerHeight);
  return true;
}

// ---------- Vòng lặp ----------
let sendT = 0, last = performance.now(), idle = 0;
function sync(p, dt) {
  const m = p.mesh, u = m.userData;
  m.visible = p.alive; if (!p.alive) return;
  const lift = p.float > 0 ? 2.2 * Math.min(1, (p.floatMax - p.float) * 4, p.float * 4) : 0; // bị nâng lơ lửng
  m.position.set(p.pos.x, lift + (p.y || 0), p.pos.z);
  const off = lift + (p.y || 0); // vòng/bóng/dấu nằm lại mặt đất khi nhảy
  u.ring.position.y = 0.05 - off; u.shadow.position.y = 0.04 - off; u.curse.position.y = 0.09 - off; u.mark.position.y = 0.11 - off;
  u.rot.rotation.y = p.face;
  p.bob += dt * 10;
  u.model.update(p, dt);
  const r = Math.max(0.001, p.hp / p.maxhp);
  u.fg.scale.x = r; u.fg.position.x = -(1 - r) * 0.8;
  u.bar.quaternion.copy(camera.quaternion);
  const fc = p.hitF > 0 ? 0x777777 : p.frozen > 0 ? 0x2a88dd : p.stun > 0 ? 0x888800 : p.shield > 0 ? 0x2244aa : 0x000000;
  for (const m of u.model.flash) m.emissive.setHex(fc);
  u.curse.visible = !!(p.slow && p.slow.m < 1); u.curse.rotation.z += dt * 2;
  u.mark.visible = !!p.mark; u.mark.rotation.z += dt * 3;
  u.aura.visible = p.inv > 0; if (p.inv > 0) { u.aura.rotation.y += dt * 2; u.aura.scale.setScalar(1 + Math.sin(performance.now() / 150) * 0.06); }
}

function update(dt) {
  G.time -= dt;
  if (controls.hold0) tryCast(0); // giữ nút đánh: tự đánh liên tục
  sendT += dt; const sendNow = sendT > 0.066; if (sendNow) sendT = 0;
  for (const p of G.players.values()) {
    for (let i = 0; i < 5; i++) if (p.cd[i] > 0) p.cd[i] -= dt;
    if (p.stun > 0) p.stun -= dt;
    if (p.swing > 0) p.swing -= dt;
    p.oc += dt;
    if (p.slow && (p.slow.t -= dt) <= 0) p.slow = null;
    if (p.mark && (p.mark.t -= dt) <= 0) p.mark = null;
    if (p.comboT > 0) p.comboT -= dt;
    if (p.inv > 0) p.inv -= dt;
    if (p.dcd > 0) p.dcd -= dt;
    if (p.hitF > 0) p.hitF -= dt;
    if (p.frozen > 0) p.frozen -= dt;
    if (p.fzT > 0 && (p.fzT -= dt) <= 0) p.fz = 0;
    if (p.float > 0) p.float -= dt;
    if (p.stkT > 0 && (p.stkT -= dt) <= 0) p.stk = 0;
    const EN = HEROES[p.hero].energy; // hồi năng lượng (gấp 3 khi đủ điểm Aether)
    if (EN) p.en = Math.min(EN.max, p.en + EN.regen * ((p.stk || 0) >= EN.boostStacks ? EN.boostMult : 1) * dt);
    if (p.ctl && p.alive) for (const z of combat.zones) if (Math.hypot(p.pos.x - z.x, p.pos.z - z.z) < z.r) p.slow = { m: p.team === z.team ? z.haste : z.slow, t: 0.25 };
    if (p.alive && (p.hT += dt) >= 0.2) { p.hT = 0; p.hist.push({ x: p.pos.x, z: p.pos.z, hp: p.hp }); if (p.hist.length > 40) p.hist.shift(); } // lịch sử 8s cho Time Rewind
    if (p.buff && (p.buff.t -= dt) <= 0) p.buff = null;
    if (p.shieldT > 0 && (p.shieldT -= dt) <= 0) p.shield = 0;
    if (p.alive) {
      const H = HEROES[p.hero];
      const rr = (H.regen || 0) + (G.adv && !p.mob && p.oc > 4 ? p.maxhp * 0.02 : 0); // Phiêu Lưu: ngoài giao tranh tự hồi 2%/s
      if (G.auth && rr && p.hp < p.maxhp) { p.rg += rr * dt; if (p.rg >= 10) { combat.heal(p, Math.floor(p.rg)); p.rg = 0; } }
      if (p.ctl) {
        let mv = { x: 0, z: 0 };
        if (p === G.me) {
          const m = controls.getMove(), fx = Math.sin(G.yaw), fz = Math.cos(G.yaw); // tiến = hướng camera, phải = (-fz, fx)
          mv = { x: fx * -m.z - fz * m.x, z: fz * -m.z + fx * m.x };
        } else if (p.bot) mv = botAI(p, dt);
        else if (p.mob) mv = mobAI(p, dt);
        step(p, dt, mv.x, mv.z);
        if (p === G.me && G.lock && !p.dash) p.face = G.yaw; // khóa vai
        if (sendNow && G.net) G.net.send({ t: 'st', id: p.id, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2), f: +p.face.toFixed(2), y: +(p.y || 0).toFixed(2) });
      } else {
        const k = Math.min(1, dt * 12), t = p.tg;
        p.moving = Math.hypot(t.x - p.pos.x, t.z - p.pos.z) > 0.05;
        p.pos.x += (t.x - p.pos.x) * k; p.pos.z += (t.z - p.pos.z) * k;
        const df = ((t.f - p.face + Math.PI * 3) % (Math.PI * 2)) - Math.PI; p.face += df * k; p.y += ((t.y || 0) - p.y) * k;
      }
    }
    if (p.pose && (p.pose.t -= dt) <= 0) p.pose = null;
    if (p.dash && (p.dash.t -= dt) <= 0) { const nx = p.dash.next; p.dash = nx ? { ...nx } : null; }
    if (p.buff && p.buff.speed >= 1.4 && p.moving && Math.random() < 0.5) combat.burst(p.pos, HEROES[p.hero].color, 1, 0.6); // tàn ảnh
    sync(p, dt);
  }
  combat.update(dt);
  // vùng an toàn
  const Z = zoneAt(G); zoneMesh.scale.set(Z.r, 1, Z.r);
  G.zt += dt;
  if (G.zt >= 1) {
    G.zt = 0;
    if (G.auth) for (const p of G.players.values()) if (p.alive && Math.hypot(p.pos.x - Z.cx, p.pos.z - Z.cz) > Z.r) combat.zoneHit(p, p.maxhp * 0.04);
  }
  if (G.auth && !G.ended) { const e = checkEnd(G); if (e) endGame(e); }
  // Camera góc nhìn thứ 3: sau lưng, lệch vai phải, khoảng cách theo chiều cao hero, tránh xuyên cây/tường, mượt
  const lk = controls.takeLook(); G.yaw -= lk.dx; G.pitch = Math.max(-0.1, Math.min(0.7, G.pitch + lk.dy)); G.zoom = Math.max(0.55, Math.min(1.7, G.zoom * lk.zm));
  const t = G.me ? G.me.pos : { x: 0, z: 0 };
  const mh = (G.me && G.me.mesh.userData.model.h) || 2.3, D = (2.0 + mh * 1.7) * G.zoom * (G.lock ? 0.78 : 1), OFF = G.lock ? 1.0 : 0.7;
  const cfx = Math.sin(G.yaw), cfz = Math.cos(G.yaw), crx = -cfz, crz = cfx, cp = Math.cos(G.pitch), sp = Math.sin(G.pitch);
  G.camD = D; G.camOff = OFF;
  const py = 1.6 * (mh / 2.3) + (G.me ? G.me.y || 0 : 0), dxp = -cfx * D * cp + crx * OFF, dzp = -cfz * D * cp + crz * OFF, dyp = D * sp + 0.5;
  let kfree = 1;
  for (let i = 1; i <= 12; i++) if (arena.blocked(t.x + dxp * (i / 12), t.z + dzp * (i / 12), 1.3)) { kfree = Math.max(0.15, (i - 1.8) / 12); break; }
  const wx = t.x + dxp * kfree, wy = py + dyp * kfree, wz = t.z + dzp * kfree;
  const ltx = t.x + cfx * 8 + crx * OFF, lty = py * 0.9, ltz = t.z + cfz * 8 + crz * OFF;
  const cm = G.cam || (G.cam = { x: wx, y: wy, z: wz, tx: ltx, ty: lty, tz: ltz });
  if (Math.hypot(wx - cm.x, wz - cm.z) > 8) { cm.x = wx; cm.y = wy; cm.z = wz; cm.tx = ltx; cm.ty = lty; cm.tz = ltz; } // dịch chuyển xa: bám ngay
  const ck = 1 - Math.exp(-26 * dt);
  cm.x += (wx - cm.x) * ck; cm.y += (wy - cm.y) * ck; cm.z += (wz - cm.z) * ck;
  cm.tx += (ltx - cm.tx) * ck; cm.ty += (lty - cm.ty) * ck; cm.tz += (ltz - cm.tz) * ck;
  const shk = G.shake || 0; G.shake = shk * Math.exp(-7 * dt);
  camera.position.set(cm.x + (Math.random() - 0.5) * shk, cm.y + (Math.random() - 0.5) * shk, cm.z + (Math.random() - 0.5) * shk); camera.lookAt(cm.tx, cm.ty, cm.tz);
  // HUD
  const me = G.me;
  if (me) {
    const di = $('.dsh i'); if (di) di.textContent = me.dcd > 0 ? me.dcd.toFixed(1) : '';
    const EH = HEROES[me.hero].energy; // thanh năng lượng Aether
    $('#en').classList.toggle('hide', !EH);
    if (EH) { $('#enf').style.width = (me.en / EH.max * 100) + '%'; $('#ent').textContent = Math.floor(me.en) + ' ⚡' + (me.stk ? '   Aether x' + me.stk : ''); }
    $('#hpf').style.width = (Math.max(0, me.hp) / me.maxhp * 100) + '%';
    $('#hpt').textContent = Math.max(0, Math.round(me.hp)) + ' / ' + me.maxhp + (me.alive ? '' : ' — hồi sinh sau ít giây');
    document.querySelectorAll('#btns button[data-i]').forEach(b => {
      const c = me.cd[+b.dataset.i]; b.classList.toggle('cd', c > 0);
      const kc = HEROES[me.hero].skills[+b.dataset.i].cost; b.classList.toggle('noen', !!(kc && me.en < kc));
      b.querySelector('i').textContent = c > 0 ? c.toFixed(1) : '';
    });
  }
  const s = Math.max(0, G.time | 0);
  $('#time').textContent = G.adv ? '⚔ Phiêu Lưu' : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  $('#score').textContent = scoreText(G);
  if (G.adv && me) { // nhiệm vụ + thanh kinh nghiệm
    const q = me.quest;
    $('#quest').textContent = q ? 'Nhiệm vụ: Hạ ' + CAMPS[q.camp].name + ' ' + q.got + '/' + q.need + ' (+' + q.xp + ' XP)' : '';
    $('#xpf').style.width = (me.xp / xpNeed(me.lvl) * 100) + '%'; $('#xpt').textContent = 'Lv ' + me.lvl + '  ' + me.xp + '/' + xpNeed(me.lvl);
  }
  $('#warn').classList.toggle('hide', !(me && me.alive && Math.hypot(me.pos.x - Z.cx, me.pos.z - Z.cz) > Z.r));
  // tâm ngắm đổi đỏ + khung khóa mục tiêu trên đầu kẻ địch
  const lf = me && me.alive ? findTarget(me) : null;
  xhEl.classList.toggle('lock', !!lf);
  if (lf) {
    _v.set(lf.t.pos.x, 1.4, lf.t.pos.z).project(camera);
    if (_v.z < 1) {
      lockEl.style.display = 'block';
      lockEl.style.left = ((_v.x * 0.5 + 0.5) * innerWidth) + 'px'; lockEl.style.top = ((-_v.y * 0.5 + 0.5) * innerHeight) + 'px';
      lockEl.firstChild.textContent = Math.round(lf.d) + ' m';
    } else lockEl.style.display = 'none';
  } else lockEl.style.display = 'none';
  drawMini(Z);
}
const xhEl = $('#xh'), lockEl = $('#lock'), _v = new THREE.Vector3();

// bản đồ nhỏ: vùng an toàn, đồng đội, địch trong tầm 110 m
const mini = $('#mini'), mg = mini.getContext('2d');
function drawMini(Z) {
  const S = mini.width, kk = S / (WORLD * 2), X = x => (x + WORLD) * kk, Y = z => (z + WORLD) * kk;
  mg.clearRect(0, 0, S, S); mg.fillStyle = 'rgba(20,40,20,.8)'; mg.fillRect(0, 0, S, S);
  mg.fillStyle = '#d8cfb4'; mg.fillRect(X(-18), Y(-32), 36 * kk, 64 * kk);
  mg.strokeStyle = '#ff3b30'; mg.lineWidth = 2; mg.beginPath(); mg.arc(X(Z.cx), Y(Z.cz), Z.r * kk, 0, 6.283); mg.stroke();
  const me = G.me;
  for (const p of G.players.values()) {
    if (!p.alive || !me) continue;
    const mine = p === me, ally = p.team === me.team, close = Math.hypot(p.pos.x - me.pos.x, p.pos.z - me.pos.z) < 110;
    if (!ally && !close) continue;
    mg.fillStyle = mine ? '#fff' : hex(TEAM_COLORS[p.team % TEAM_COLORS.length]);
    mg.beginPath(); mg.arc(X(p.pos.x), Y(p.pos.z), mine ? 4 : 3, 0, 6.283); mg.fill();
    if (mine) { mg.strokeStyle = '#fff'; mg.lineWidth = 1.5; mg.beginPath(); mg.moveTo(X(p.pos.x), Y(p.pos.z)); mg.lineTo(X(p.pos.x) + Math.sin(G.yaw) * 12, Y(p.pos.z) + Math.cos(G.yaw) * 12); mg.stroke(); }
  }
}

function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (G.running) update(dt);
  else if (!G.ended) { idle += dt * 0.2; camera.position.set(Math.cos(idle) * 40, 32, Math.sin(idle) * 55); camera.lookAt(0, 0, 0); }
  if (!(G.phase === 'pick' && !G.running && renderPreview(dt))) renderer.render(scene, camera);
}
requestAnimationFrame(loop);
