import * as THREE from 'three';
import { HEROES } from './hero_classes.js';
import { Combat } from './combat_system.js';
import { MODES, TEAM_COLORS, assign, registerKill, checkEnd, scoreText } from './game_modes.js';
import { Controls } from './controls.js';
import { Net } from './network.js';
import { buildArena } from './arena.js';

const $ = s => document.querySelector(s);
const hex = c => '#' + c.toString(16).padStart(6, '0');
const G = {
  players: new Map(), running: false, ended: false, auth: true, net: null, myId: 'host', me: null,
  mode: null, score: {}, stats: {}, time: 0, lobby: [], hero: 'knight', modeKey: '1v1', R: 22
};
window.G = G;

// ---------- Three.js scene ----------
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x14210f);
scene.fog = new THREE.Fog(0x14210f, 45, 95);
const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 150);
G.scene = scene; G.camera = camera;
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

scene.add(new THREE.HemisphereLight(0xaaccff, 0x222244, 1.1));
const sun = new THREE.DirectionalLight(0xffffff, 1.2); sun.position.set(10, 25, 10); scene.add(sun);
const arena = buildArena(scene);
G.hitsWall = arena.hits;

const combat = new Combat(G); G.combat = combat;
const controls = new Controls(canvas, i => tryCast(i));
const ray = new THREE.Raycaster();

// ---------- Người chơi ----------
function label(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const x = c.getContext('2d');
  x.font = 'bold 34px sans-serif'; x.textAlign = 'center'; x.lineWidth = 5; x.strokeStyle = '#000'; x.fillStyle = hex(color);
  x.strokeText(text, 128, 44); x.fillText(text, 128, 44);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
  s.scale.set(3, 0.75, 1); return s;
}

function makeMesh(p) {
  const H = HEROES[p.hero], root = new THREE.Group(), rot = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.45, 0.9, 4, 10), new THREE.MeshStandardMaterial({ color: H.color }));
  body.position.y = 1; rot.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), new THREE.MeshStandardMaterial({ color: 0xffd7b0 }));
  head.position.y = 1.95; rot.add(head);
  const wp = new THREE.Group();
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 1.3), new THREE.MeshStandardMaterial({ color: 0xdddddd, emissive: H.color, emissiveIntensity: 0.6 }));
  blade.position.z = 0.65; wp.add(blade); wp.position.set(0.6, 1.1, 0.2); rot.add(wp);
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.8, 1, 24), new THREE.MeshBasicMaterial({ color: TEAM_COLORS[p.team % 6], side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.y = 0.05; root.add(ring);
  root.add(rot);
  const bar = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.18), new THREE.MeshBasicMaterial({ color: 0x000000, depthTest: false }));
  const fg = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.18), new THREE.MeshBasicMaterial({ color: p.id === G.myId ? 0x4ade80 : 0xff5252, depthTest: false }));
  fg.position.z = 0.01; bg.renderOrder = 10; fg.renderOrder = 11; bar.add(bg, fg); bar.position.y = 2.7; root.add(bar);
  const nm = label(p.name, TEAM_COLORS[p.team % 6]); nm.position.y = 3.2; root.add(nm);
  root.userData = { rot, wp, bar, fg, body };
  scene.add(root); return root;
}

function addPlayer(i) {
  const H = HEROES[i.hero];
  const p = {
    id: i.id, name: i.name, hero: i.hero, team: i.team, bot: i.bot, hp: H.hp, maxhp: H.hp,
    pos: new THREE.Vector3(i.x, 0, i.z), spawn: { x: i.x, z: i.z }, kv: { x: 0, z: 0 }, cd: [0, 0, 0, 0, 0],
    stun: 0, alive: true, face: Math.atan2(-i.x, -i.z), swing: 0, dash: null, buff: null, shield: 0, shieldT: 0,
    ai: { t: 0, s: 1, a: 0.5 }, tg: { x: i.x, z: i.z, f: 0 }, bob: 0, moving: false, rg: 0
  };
  p.ctl = p.id === G.myId || (p.bot && G.auth);
  p.mesh = makeMesh(p);
  G.players.set(p.id, p); return p;
}

function removePlayer(id) {
  const p = G.players.get(id); if (!p) return;
  scene.remove(p.mesh); G.players.delete(id);
}

// ---------- Di chuyển ----------
function step(p, dt, mx, mz) {
  const H = HEROES[p.hero];
  let vx = 0, vz = 0;
  const l = Math.hypot(mx, mz);
  if (p.dash) { vx = p.dash.vx; vz = p.dash.vz; }
  else if (p.stun <= 0 && l > 0.05) {
    const sp = H.speed * (p.buff ? p.buff.speed : 1);
    vx = (mx / Math.max(l, 1)) * sp; vz = (mz / Math.max(l, 1)) * sp;
    p.face = Math.atan2(mx, mz);
  }
  p.moving = Math.hypot(vx, vz) > 0.5;
  const k = Math.exp(-7 * dt); p.kv.x *= k; p.kv.z *= k;
  p.pos.x += (vx + p.kv.x) * dt; p.pos.z += (vz + p.kv.z) * dt;
  arena.resolve(p.pos, 0.5);
}

// ---------- Bot AI (chỉ chạy trên host) ----------
function botAI(p, dt) {
  const en = combat.enemies(p);
  if (!en.length || p.stun > 0) return { x: 0, z: 0 };
  let tg = en[0], bd = 1e9;
  for (const t of en) { const d = Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z); if (d < bd) { bd = d; tg = t; } }
  const dx = tg.pos.x - p.pos.x, dz = tg.pos.z - p.pos.z, d = Math.hypot(dx, dz) || 1, nx = dx / d, nz = dz / d;
  const H = HEROES[p.hero], ranged = H.skills[0].type === 'projectile', pref = ranged ? 9 : 2.2;
  p.ai.t -= dt; if (p.ai.t <= 0) { p.ai.t = 1 + Math.random() * 1.5; p.ai.s = Math.random() < 0.5 ? -1 : 1; }
  let mx = 0, mz = 0;
  if (d > pref + 1) { mx = nx; mz = nz; } else if (ranged && d < pref - 2) { mx = -nx; mz = -nz; }
  mx += -nz * p.ai.s * 0.5; mz += nx * p.ai.s * 0.5;
  p.ai.a -= dt;
  if (p.ai.a <= 0) {
    for (const i of [4, 1, 2, 3, 0]) {
      const s = H.skills[i]; if (p.cd[i] > 0) continue;
      let ok = false;
      if (s.type === 'melee') ok = d < s.range + 0.5;
      else if (s.type === 'projectile') ok = d < 14;
      else if (s.type === 'dash') ok = s.dmg > 0 ? (d < s.dist + 1 && d > 2.5) : (d < 4 && p.hp < p.maxhp * 0.4);
      else if (s.type === 'aoe') ok = d < (s.offset || 0) + s.radius;
      else if (s.type === 'buff') ok = d < 10;
      else if (s.type === 'heal') ok = p.hp < p.maxhp * 0.7 || (s.dmg && d < s.radius);
      if (ok && (i !== 4 || Math.random() < 0.5)) {
        combat.cast(p, i, nx, nz);
        if (G.net) G.net.bcast({ t: 'cast', id: p.id, i, dx: nx, dz: nz });
        break;
      }
    }
    p.ai.a = 0.3 + Math.random() * 0.4;
  }
  return { x: mx * 0.9, z: mz * 0.9 };
}

// ---------- Cast của người chơi ----------
function aimDir(p) {
  if (!controls.touch) {
    ray.setFromCamera(controls.mouse, camera);
    const o = ray.ray.origin, d = ray.ray.direction, t = -o.y / d.y;
    const ax = o.x + d.x * t - p.pos.x, az = o.z + d.z * t - p.pos.z, l = Math.hypot(ax, az);
    if (l > 0.3) return { x: ax / l, z: az / l };
  } else {
    let best = null, bd = 18;
    for (const t of combat.enemies(p)) { const d = Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z); if (d < bd) { bd = d; best = t; } }
    if (best) return { x: (best.pos.x - p.pos.x) / bd, z: (best.pos.z - p.pos.z) / bd };
  }
  return { x: Math.sin(p.face), z: Math.cos(p.face) };
}

function tryCast(i) {
  const p = G.me;
  if (!G.running || !p || !p.alive || p.stun > 0 || p.cd[i] > 0) return;
  const a = aimDir(p);
  combat.cast(p, i, a.x, a.z);
  if (G.net) G.net.send({ t: 'cast', id: p.id, i, dx: a.x, dz: a.z });
}

// ---------- Hạ gục / hồi sinh / kết thúc ----------
function feed(t) {
  const d = document.createElement('div'); d.textContent = t; $('#feed').appendChild(d);
  setTimeout(() => d.remove(), 4000);
}
function onDead(m) {
  const v = G.players.get(m.id); if (!v) return;
  v.alive = false; v.hp = 0; v.dash = null; v.mesh.visible = false;
  G.score = m.score; G.stats = m.stats;
  const k = m.by && G.players.get(m.by);
  feed(`${k ? k.name : '?'} ⚔ ${v.name}`);
  combat.burst(v.pos, HEROES[v.hero].color, 24, 6);
}
function respawn(m) {
  const p = G.players.get(m.id); if (!p) return;
  p.alive = true; p.hp = p.maxhp; p.pos.set(m.x, 0, m.z); p.tg = { x: m.x, z: m.z, f: p.face };
  p.stun = 0; p.kv = { x: 0, z: 0 }; p.shield = 0; p.mesh.visible = true;
  combat.ring(m.x, m.z, 0xffffff, 3, 0.6);
}
G.kill = function (v, src) {
  if (!v.alive) return;
  registerKill(G, v, src);
  const m = { t: 'dead', id: v.id, by: src ? src.id : null, score: G.score, stats: G.stats };
  if (G.net) G.net.bcast(m);
  onDead(m);
  setTimeout(() => {
    if (!G.running) return;
    const r = { t: 'respawn', id: v.id, x: v.spawn.x, z: v.spawn.z };
    if (G.net) G.net.bcast(r);
    respawn(r);
  }, 3000);
};
function endGame(labelText) {
  if (G.ended) return;
  const m = { t: 'end', label: labelText, stats: G.stats, score: G.score };
  if (G.net) G.net.bcast(m);
  showEnd(m);
}
function showEnd(m) {
  if (G.ended) return;
  G.ended = true; G.running = false; G.stats = m.stats;
  const rows = [...G.players.values()].sort((a, b) => (G.stats[b.id]?.[0] || 0) - (G.stats[a.id]?.[0] || 0))
    .map(p => `<tr><td>${p.name}</td><td>${HEROES[p.hero].name}</td><td>${G.stats[p.id]?.[0] || 0}</td><td>${G.stats[p.id]?.[1] || 0}</td></tr>`).join('');
  $('#endTitle').textContent = m.label;
  $('#endTable').innerHTML = '<tr><th>Tên</th><th>Tướng</th><th>Hạ</th><th>Chết</th></tr>' + rows;
  $('#end').classList.remove('hide');
}
$('#bBack').onclick = () => location.reload();

// ---------- Bắt đầu ván ----------
function startGame(mode, list) {
  for (const p of G.players.values()) scene.remove(p.mesh);
  G.players.clear(); combat.reset();
  G.mode = mode; G.stats = {}; G.score = {}; G.ended = false;
  list.forEach(i => { addPlayer(i); G.stats[i.id] = [0, 0]; G.score[i.team] = 0; });
  G.me = G.players.get(G.myId);
  G.time = MODES[mode].time; G.running = true;
  $('#menu').classList.add('hide'); $('#pick').classList.add('hide'); clearInterval(G.pt); $('#hud').classList.remove('hide'); $('#end').classList.add('hide');
  $('#feed').innerHTML = '';
  const H = HEROES[G.me.hero];
  document.querySelectorAll('#btns button').forEach(b => { b.querySelector('b').textContent = H.skills[+b.dataset.i].n; });
  combat.sfx('buff');
}
function hostStart() {
  clearInterval(G.pt); G.phase = 'play';
  const keys = Object.keys(HEROES);
  G.lobby.forEach(x => { if (!HEROES[x.hero]) x.hero = keys[Math.floor(Math.random() * keys.length)]; });
  const list = assign(G.modeKey, G.lobby);
  if (G.net) G.net.bcast({ t: 'start', mode: G.modeKey, players: list });
  startGame(G.modeKey, list);
}

// ---------- Mạng ----------
function onMsg(m, conn) {
  const host = G.net && G.net.isHost;
  switch (m.t) {
    case 'join': {
      if (!host || G.running || !HEROES[m.hero]) return;
      const pid = conn.peer, nmv = String(m.name || 'Player').slice(0, 12);
      const e = G.lobby.find(x => x.id === pid);
      if (e) { e.name = nmv; e.hero = m.hero; e.ready = !!m.ready; }
      else if (G.phase !== 'pick' && G.lobby.length < 6) G.lobby.push({ id: pid, name: nmv, hero: m.hero, ready: false });
      G.net.bcast({ t: 'lobby', list: G.lobby }); renderLobby(); checkAllReady(); break;
    }
    case 'lobby': G.lobby = m.list; renderLobby(); break;
    case 'pick': openPick(m.mode, m.secs); break;
    case 'start': startGame(m.mode, m.players); break;
    case 'st': {
      if (host && m.id !== conn.peer) break;
      const p = G.players.get(m.id);
      if (p && !p.ctl) p.tg = { x: m.x, z: m.z, f: m.f };
      if (host) G.net.bcast(m, conn);
      break;
    }
    case 'cast': {
      if (host && m.id !== conn.peer) break;
      const p = G.players.get(m.id);
      if (p && !p.ctl && p.alive) combat.cast(p, m.i, m.dx, m.dz);
      if (host) G.net.bcast(m, conn);
      break;
    }
    case 'hit': combat.applyHit(m); break;
    case 'dead': onDead(m); break;
    case 'respawn': respawn(m); break;
    case 'end': showEnd(m); break;
    case 'left': removePlayer(m.id); break;
  }
}
function onClose(id) {
  if (G.net && G.net.isHost) {
    G.lobby = G.lobby.filter(x => x.id !== id);
    if (G.running) { removePlayer(id); G.net.bcast({ t: 'left', id }); } else { G.net.bcast({ t: 'lobby', list: G.lobby }); renderLobby(); checkAllReady(); }
  } else { alert('Mất kết nối với chủ phòng.'); location.reload(); }
}

// ---------- Menu ----------
const ICON = { knight: '🛡️', mage: '🔮', assassin: '🗡️', priest: '✨' };
const TYPE_VI = { melee: 'Cận chiến', projectile: 'Đạn bay', dash: 'Lướt', aoe: 'Vùng', buff: 'Tăng cường', heal: 'Hồi máu' };
const SLOT = ['Đánh thường', 'Kỹ năng 1', 'Kỹ năng 2', 'Kỹ năng 3', 'Tuyệt chiêu'];
const MODE_DESC = { '1v1': 'Song đấu', '2v2': 'Đội 2 người', '3v3': 'Đội 3 người', 'ffa': '6 người tự đấu' };
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nm = () => ($('#name').value.trim() || 'Hero').slice(0, 12);
const msg = t => { $('#msg').textContent = t; };
G.locked = false; G.phase = 'menu';

function checkAllReady() {
  if (G.phase === 'pick' && G.auth && G.lobby.length && G.lobby.every(x => x.ready)) hostStart();
}
function syncLobbyMe() {
  if (!G.net || G.net.isHost) {
    const e = G.lobby.find(x => x.id === 'host');
    if (e) { e.name = nm(); e.hero = G.hero; e.ready = !!G.locked; }
    if (G.net) G.net.bcast({ t: 'lobby', list: G.lobby });
    renderLobby(); checkAllReady();
  } else G.net.send({ t: 'join', id: G.myId, name: nm(), hero: G.hero, ready: !!G.locked });
}

// chế độ chơi
const mc = $('#modes');
for (const k in MODES) {
  const b = document.createElement('button');
  b.className = 'mode' + (k === G.modeKey ? ' sel' : '');
  b.innerHTML = `<b>${MODES[k].label}</b><small>${MODE_DESC[k]}</small>`;
  b.onclick = () => { G.modeKey = k; [...mc.children].forEach(c => c.classList.remove('sel')); b.classList.add('sel'); };
  mc.appendChild(b);
}

// màn chọn tướng (hiện khi bắt đầu trận)
const hc = $('#heroes');
for (const k in HEROES) {
  const H = HEROES[k], d = document.createElement('div');
  d.className = 'tile'; d.dataset.k = k; d.style.setProperty('--c', hex(H.color));
  d.innerHTML = `<span class="ic">${ICON[k]}</span><b>${H.name}</b><small>${H.role}</small>`;
  d.onclick = () => { if (G.locked) return; G.hero = k; showHero(); syncLobbyMe(); };
  hc.appendChild(d);
}
function showHero() {
  const H = HEROES[G.hero];
  [...hc.children].forEach(t => t.classList.toggle('sel', t.dataset.k === G.hero));
  const dt = $('#detail'); dt.style.setProperty('--c', hex(H.color));
  dt.innerHTML = `<div class="dn"><span>${ICON[G.hero]}</span><div><h3>${H.name}</h3><em>${H.role}</em></div></div>
    <div class="st"><label>Máu</label><i><u style="width:${H.hp / 12}%"></u></i><span>${H.hp}</span></div>
    <div class="st"><label>Tốc độ</label><i><u style="width:${(H.speed / 7.4) * 100}%"></u></i><span>${H.speed}</span></div>
    <p class="pas">⭐ ${H.passive}</p>
    <ul>${H.skills.map((s, i) => `<li><b>${SLOT[i]}: ${s.n}</b><small>${TYPE_VI[s.type]} · hồi chiêu ${s.cd}s</small></li>`).join('')}</ul>`;
}
function renderLobby() {
  $('#plist').innerHTML = G.lobby.map(x => `<div class="pl"><span>${x.id === 'host' ? '👑' : '👤'} ${esc(x.name)}</span></div>`).join('');
  $('#roster').innerHTML = G.lobby.map(x => `<div class="pl"><span>${esc(x.name)}</span><em class="${x.ready ? 'ok' : ''}">${x.ready && HEROES[x.hero] ? '✓ ' + HEROES[x.hero].name : 'đang chọn…'}</em></div>`).join('');
}
const pkTick = () => { $('#pkTime').textContent = '⏱ ' + Math.max(0, G.pickT) + 's'; };
function openPick(mode, secs) {
  G.modeKey = mode; G.phase = 'pick'; G.locked = false;
  $('#menu').classList.add('hide'); $('#pick').classList.remove('hide');
  $('#pkMode').textContent = MODES[mode].label;
  const b = $('#bReady'); b.disabled = false; b.textContent = 'SẴN SÀNG'; hc.classList.remove('lock');
  showHero(); renderLobby(); syncLobbyMe();
  clearInterval(G.pt); G.pickT = secs; pkTick();
  G.pt = setInterval(() => { G.pickT--; pkTick(); if (G.pickT <= 0) { clearInterval(G.pt); if (G.auth) hostStart(); } }, 1000);
}
function beginPick() {
  G.lobby.forEach(x => { x.ready = false; });
  if (G.net) { G.net.bcast({ t: 'pick', mode: G.modeKey, secs: 25 }); G.net.bcast({ t: 'lobby', list: G.lobby }); }
  openPick(G.modeKey, 25);
}
$('#bReady').onclick = () => {
  if (G.locked) return;
  G.locked = true; $('#bReady').disabled = true; $('#bReady').textContent = 'ĐÃ SẴN SÀNG ✓'; hc.classList.add('lock');
  syncLobbyMe();
};
$('#bLeave').onclick = () => location.reload();

function showLobby(code, isHost) {
  $('#home').classList.add('hide'); $('#lobby').classList.remove('hide');
  $('#rc').textContent = code; renderLobby();
  $('#bStart').classList.toggle('hide', !isHost); $('#wait').classList.toggle('hide', isHost);
  mc.classList.toggle('dis', !isHost);
}
$('#bOff').onclick = () => {
  G.auth = true; G.net = null; G.myId = 'host';
  G.lobby = [{ id: 'host', name: nm(), hero: G.hero, ready: false }]; beginPick();
};
$('#bHost').onclick = async () => {
  const code = String(Math.floor(10000 + Math.random() * 90000)), net = new Net();
  net.onmsg = onMsg; net.onclose = onClose; msg('Đang tạo phòng…');
  try { await net.host(code); } catch (e) { msg('Không tạo được phòng: ' + (e.type || e)); return; }
  msg(''); G.net = net; G.auth = true; G.myId = 'host';
  G.lobby = [{ id: 'host', name: nm(), hero: G.hero, ready: false }]; showLobby(code, true);
};
$('#bJoin').onclick = async () => {
  const code = $('#code').value.trim(); if (!code) { msg('Nhập mã phòng'); return; }
  const net = new Net(); net.onmsg = onMsg; net.onclose = onClose; msg('Đang vào phòng…');
  try { await net.join(code); } catch (e) { msg('Không vào được phòng: ' + (e.type || e)); return; }
  msg(''); G.net = net; G.auth = false; G.myId = net.id;
  net.send({ t: 'join', id: net.id, name: nm(), hero: G.hero, ready: false }); showLobby(code, false);
};
$('#bStart').onclick = beginPick;

// ---------- Vòng lặp ----------
let sendT = 0, last = performance.now(), idle = 0;
function sync(p, dt) {
  const m = p.mesh, u = m.userData;
  m.visible = p.alive; if (!p.alive) return;
  m.position.set(p.pos.x, 0, p.pos.z);
  u.rot.rotation.y = p.face;
  p.bob += dt * 10; u.rot.position.y = p.moving ? Math.abs(Math.sin(p.bob)) * 0.1 : 0;
  u.wp.rotation.x = p.swing > 0 ? -1.4 + (1 - p.swing / 0.25) * 2.4 : 0;
  const r = Math.max(0.001, p.hp / p.maxhp);
  u.fg.scale.x = r; u.fg.position.x = -(1 - r) * 0.8;
  u.bar.quaternion.copy(camera.quaternion);
  u.body.material.emissive.setHex(p.stun > 0 ? 0x888800 : p.shield > 0 ? 0x2244aa : 0x000000);
}

function update(dt) {
  G.time -= dt;
  sendT += dt; const sendNow = sendT > 0.066; if (sendNow) sendT = 0;
  for (const p of G.players.values()) {
    for (let i = 0; i < 5; i++) if (p.cd[i] > 0) p.cd[i] -= dt;
    if (p.stun > 0) p.stun -= dt;
    if (p.swing > 0) p.swing -= dt;
    if (p.buff && (p.buff.t -= dt) <= 0) p.buff = null;
    if (p.shieldT > 0 && (p.shieldT -= dt) <= 0) p.shield = 0;
    if (p.alive) {
      const H = HEROES[p.hero];
      if (G.auth && H.regen && p.hp < p.maxhp) { p.rg += H.regen * dt; if (p.rg >= 10) { combat.heal(p, Math.floor(p.rg)); p.rg = 0; } }
      if (p.ctl) {
        let mv = { x: 0, z: 0 };
        if (p === G.me) mv = controls.getMove(); else if (p.bot) mv = botAI(p, dt);
        step(p, dt, mv.x, mv.z);
        if (sendNow && G.net) G.net.send({ t: 'st', id: p.id, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2), f: +p.face.toFixed(2) });
      } else {
        const k = Math.min(1, dt * 12), t = p.tg;
        p.moving = Math.hypot(t.x - p.pos.x, t.z - p.pos.z) > 0.05;
        p.pos.x += (t.x - p.pos.x) * k; p.pos.z += (t.z - p.pos.z) * k;
        const df = ((t.f - p.face + Math.PI * 3) % (Math.PI * 2)) - Math.PI; p.face += df * k;
      }
    }
    if (p.dash && (p.dash.t -= dt) <= 0) p.dash = null;
    sync(p, dt);
  }
  combat.update(dt);
  if (G.auth && !G.ended) { const e = checkEnd(G); if (e) endGame(e); }
  // Camera
  const t = G.me ? G.me.pos : { x: 0, z: 0 };
  camera.position.x += (t.x - camera.position.x) * Math.min(1, dt * 6);
  camera.position.z += (t.z + 11 - camera.position.z) * Math.min(1, dt * 6);
  camera.position.y = 15;
  camera.lookAt(camera.position.x, 0, camera.position.z - 11);
  // HUD
  const me = G.me;
  if (me) {
    $('#hpf').style.width = (Math.max(0, me.hp) / me.maxhp * 100) + '%';
    $('#hpt').textContent = Math.max(0, Math.round(me.hp)) + ' / ' + me.maxhp + (me.alive ? '' : ' — hồi sinh sau ít giây');
    document.querySelectorAll('#btns button').forEach(b => {
      const c = me.cd[+b.dataset.i]; b.classList.toggle('cd', c > 0);
      b.querySelector('i').textContent = c > 0 ? c.toFixed(1) : '';
    });
  }
  const s = Math.max(0, G.time | 0);
  $('#time').textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  $('#score').textContent = scoreText(G);
}

function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (G.running) update(dt);
  else if (!G.ended) { idle += dt * 0.2; camera.position.set(Math.cos(idle) * 40, 32, Math.sin(idle) * 55); camera.lookAt(0, 0, 0); }
  renderer.render(scene, camera);
}
requestAnimationFrame(loop);
