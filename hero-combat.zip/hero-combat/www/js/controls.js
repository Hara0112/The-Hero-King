// Điều khiển: joystick ảo + nút skill (điện thoại), WASD/chuột/phím skill (PC)
const KEYMAP = { Space: 0, KeyJ: 0, KeyQ: 1, KeyE: 2, KeyR: 3, KeyF: 4 };

export class Controls {
  constructor(canvas, onAction) {
    this.onAction = onAction;
    this.joy = { x: 0, z: 0 };
    this.keys = {};
    this.touch = false;
    this.mouse = { x: 0, y: 0 };
    this.lookD = { dx: 0, dy: 0 };

    const base = document.getElementById('joy'), knob = document.getElementById('knob');
    let pid = null, cx = 0, cy = 0;
    const R = 55;
    const upd = e => {
      let dx = e.clientX - cx, dy = e.clientY - cy;
      const l = Math.hypot(dx, dy);
      if (l > R) { dx *= R / l; dy *= R / l; }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      this.joy.x = dx / R; this.joy.z = dy / R;
    };
    base.addEventListener('pointerdown', e => {
      this.touch = e.pointerType === 'touch' || this.touch;
      pid = e.pointerId; base.setPointerCapture(pid);
      const r = base.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      upd(e); e.preventDefault();
    });
    base.addEventListener('pointermove', e => { if (e.pointerId === pid) upd(e); });
    const end = e => {
      if (e.pointerId !== pid) return;
      pid = null; this.joy.x = this.joy.z = 0; knob.style.transform = '';
    };
    base.addEventListener('pointerup', end);
    base.addEventListener('pointercancel', end);

    document.querySelectorAll('#btns button').forEach(b => {
      b.addEventListener('pointerdown', e => {
        e.preventDefault();
        if (e.pointerType === 'touch') this.touch = true;
        this.onAction(+b.dataset.i);
      });
    });

    addEventListener('keydown', e => {
      this.keys[e.code] = true;
      if (e.code in KEYMAP) { if (!e.repeat) this.onAction(KEYMAP[e.code]); e.preventDefault(); }
    });
    addEventListener('keyup', e => { this.keys[e.code] = false; });

    // xoay camera: vuốt ngón tay (điện thoại) hoặc di chuột (PC, bấm vào màn hình để khóa chuột)
    let lookId = null, lx = 0, ly = 0;
    canvas.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') {
        if (e.button === 0) { this.onAction(0); if (document.pointerLockElement !== canvas && canvas.requestPointerLock) canvas.requestPointerLock(); }
      } else if (lookId === null) {
        this.touch = true; lookId = e.pointerId; lx = e.clientX; ly = e.clientY; canvas.setPointerCapture(e.pointerId);
      }
    });
    canvas.addEventListener('pointermove', e => {
      if (e.pointerType === 'mouse') {
        this.touch = false;
        if (document.pointerLockElement === canvas) { this.lookD.dx += e.movementX * 0.0025; this.lookD.dy += e.movementY * 0.002; }
      } else if (e.pointerId === lookId) {
        this.lookD.dx += (e.clientX - lx) * 0.006; this.lookD.dy += (e.clientY - ly) * 0.004; lx = e.clientX; ly = e.clientY;
      }
    });
    const endLook = e => { if (e.pointerId === lookId) lookId = null; };
    canvas.addEventListener('pointerup', endLook); canvas.addEventListener('pointercancel', endLook);
  }

  takeLook() { const l = this.lookD; this.lookD = { dx: 0, dy: 0 }; return l; }

  getMove() {
    const k = this.keys;
    let x = this.joy.x + ((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0);
    let z = this.joy.z + ((k.KeyS || k.ArrowDown) ? 1 : 0) - ((k.KeyW || k.ArrowUp) ? 1 : 0);
    const l = Math.hypot(x, z);
    if (l > 1) { x /= l; z /= l; }
    return { x, z };
  }
}
