// Điều khiển kiểu Blox Fruits: joystick/WASD, xoay camera, zoom, nhảy, lướt, khóa vai, giữ để đánh liên tục
// PC: WASD đi, chuột xoay (bấm để khóa chuột), lăn chuột zoom, Space nhảy (bấm 2 lần = nhảy đôi), Q lướt,
//     Shift khóa vai, chuột trái / J giữ để đánh, Z X C = chiêu 1-3, V hoặc F = tuyệt chiêu.
const KEYMAP = { Space: 'jump', KeyJ: 0, KeyZ: 1, KeyX: 2, KeyC: 3, KeyV: 4, KeyF: 4, KeyQ: 'dash', ShiftLeft: 'lock', ShiftRight: 'lock' };

export class Controls {
  constructor(canvas, onAction) {
    this.onAction = onAction;
    this.joy = { x: 0, z: 0 };
    this.keys = {};
    this.touch = false;
    this.lookD = { dx: 0, dy: 0, zm: 1 };
    this.hold0 = false; // giữ nút đánh thường: tự đánh liên tục

    const base = document.getElementById('joy'), knob = document.getElementById('knob');
    let pid = null, cx = 0, cy = 0;
    const R = 55;
    const upd = e => {
      let dx = e.clientX - cx, dy = e.clientY - cy;
      const l = Math.hypot(dx, dy);
      if (l > R) { dx *= R / l; dy *= R / l; }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      this.joy.x = dx / R; this.joy.z = dy / R;
    };
    base.addEventListener('pointerdown', e => {
      this.touch = e.pointerType === 'touch' || this.touch;
      pid = e.pointerId; base.setPointerCapture(pid);
      const r = base.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      upd(e); e.preventDefault();
    });
    base.addEventListener('pointermove', e => { if (e.pointerId === pid) upd(e); });
    const end = e => {
      if (e.pointerId !== pid) return;
      pid = null; this.joy.x = this.joy.z = 0; knob.style.transform = '';
    };
    base.addEventListener('pointerup', end);
    base.addEventListener('pointercancel', end);

    document.querySelectorAll('#btns button').forEach(b => {
      const act = b.dataset.a !== undefined ? b.dataset.a : +b.dataset.i;
      b.addEventListener('pointerdown', e => {
        e.preventDefault();
        if (e.pointerType === 'touch') this.touch = true;
        if (act === 0) this.hold0 = true;
        this.onAction(act);
      });
      const up = () => { if (act === 0) this.hold0 = false; };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('pointerleave', up);
    });

    addEventListener('keydown', e => {
      this.keys[e.code] = true;
      if (e.code in KEYMAP) {
        if (!e.repeat) { const a = KEYMAP[e.code]; if (a === 0) this.hold0 = true; this.onAction(a); }
        e.preventDefault();
      }
    });
    addEventListener('keyup', e => { this.keys[e.code] = false; if (KEYMAP[e.code] === 0) this.hold0 = false; });
    addEventListener('pointerup', e => { if (e.pointerType === 'mouse') this.hold0 = false; });

    // xoay camera + zoom: vuốt 1 ngón = xoay, chụm 2 ngón = zoom, chuột (khóa chuột) = xoay, lăn chuột = zoom
    const tp = new Map();
    canvas.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') {
        if (e.button === 0) { this.hold0 = true; this.onAction(0); if (document.pointerLockElement !== canvas && canvas.requestPointerLock) canvas.requestPointerLock(); }
      } else {
        this.touch = true; tp.set(e.pointerId, { x: e.clientX, y: e.clientY }); canvas.setPointerCapture(e.pointerId);
      }
    });
    canvas.addEventListener('pointermove', e => {
      if (e.pointerType === 'mouse') {
        this.touch = false;
        if (document.pointerLockElement === canvas) { this.lookD.dx += e.movementX * 0.0025; this.lookD.dy += e.movementY * 0.002; }
        return;
      }
      const o = tp.get(e.pointerId); if (!o) return;
      if (tp.size === 2) {
        const [a, b] = [...tp.values()], d0 = Math.hypot(a.x - b.x, a.y - b.y);
        o.x = e.clientX; o.y = e.clientY;
        const d1 = Math.hypot(a.x - b.x, a.y - b.y);
        if (d0 > 5 && d1 > 5) this.lookD.zm *= d0 / d1; // tách ngón = phóng to (camera gần lại)
      } else {
        this.lookD.dx += (e.clientX - o.x) * 0.006; this.lookD.dy += (e.clientY - o.y) * 0.004; o.x = e.clientX; o.y = e.clientY;
      }
    });
    const endLook = e => { tp.delete(e.pointerId); };
    canvas.addEventListener('pointerup', endLook); canvas.addEventListener('pointercancel', endLook);
    canvas.addEventListener('wheel', e => { this.lookD.zm *= 1 + Math.sign(e.deltaY) * 0.1; e.preventDefault(); }, { passive: false });
  }

  takeLook() { const l = this.lookD; this.lookD = { dx: 0, dy: 0, zm: 1 }; return l; }

  getMove() {
    const k = this.keys;
    let x = this.joy.x + ((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0);
    let z = this.joy.z + ((k.KeyS || k.ArrowDown) ? 1 : 0) - ((k.KeyW || k.ArrowUp) ? 1 : 0);
    const l = Math.hypot(x, z);
    if (l > 1) { x /= l; z /= l; }
    return { x, z };
  }
}
