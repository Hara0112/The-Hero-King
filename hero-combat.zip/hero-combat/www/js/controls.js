// Điều khiển: joystick ảo + nút skill (điện thoại), WASD/chuột/phím skill (PC)
const KEYMAP = { Space: 0, KeyJ: 0, KeyQ: 1, KeyE: 2, KeyR: 3, KeyF: 4 };

export class Controls {
  constructor(canvas, onAction) {
    this.onAction = onAction;
    this.joy = { x: 0, z: 0 };
    this.keys = {};
    this.touch = false;
    this.mouse = { x: 0, y: 0 };

    const base = document.getElementById('joy'), knob = document.getElementById('knob');
    let pid = null, cx = 0, cy = 0;
    const R = 55;
    const upd = e => {
      let dx = e.clientX - cx, dy = e.clientY - cy;
      const l = Math.hypot(dx, dy);
      if (l > R) { dx *= R / l; dy *= R / l; }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      this.joy.x = dx / R; this.joy.z = dy / R;
    };
    base.addEventListener('pointerdown', e => {
      this.touch = e.pointerType === 'touch' || this.touch;
      pid = e.pointerId; base.setPointerCapture(pid);
      const r = base.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      upd(e); e.preventDefault();
    });
    base.addEventListener('pointermove', e => { if (e.pointerId === pid) upd(e); });
    const end = e => {
      if (e.pointerId !== pid) return;
      pid = null; this.joy.x = this.joy.z = 0; knob.style.transform = '';
    };
    base.addEventListener('pointerup', end);
    base.addEventListener('pointercancel', end);

    document.querySelectorAll('#btns button').forEach(b => {
      b.addEventListener('pointerdown', e => {
        e.preventDefault();
        if (e.pointerType === 'touch') this.touch = true;
        this.onAction(+b.dataset.i);
      });
    });

    addEventListener('keydown', e => {
      this.keys[e.code] = true;
      if (e.code in KEYMAP) { if (!e.repeat) this.onAction(KEYMAP[e.code]); e.preventDefault(); }
    });
    addEventListener('keyup', e => { this.keys[e.code] = false; });

    canvas.addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      this.touch = false;
      this.mouse.x = (e.clientX / innerWidth) * 2 - 1;
      this.mouse.y = -(e.clientY / innerHeight) * 2 + 1;
    });
    canvas.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button === 0) this.onAction(0);
    });
  }

  getMove() {
    const k = this.keys;
    let x = this.joy.x + ((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0);
    let z = this.joy.z + ((k.KeyS || k.ArrowDown) ? 1 : 0) - ((k.KeyW || k.ArrowUp) ? 1 : 0);
    const l = Math.hypot(x, z);
    if (l > 1) { x /= l; z /= l; }
    return { x, z };
  }
}
