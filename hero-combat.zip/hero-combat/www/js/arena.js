import * as THREE from 'three';

// Bản đồ tàn tích: sân chữ nhật dọc, quảng trường tròn ở giữa, cổng vòm, đường lát đá, tường đổ, cây rừng.
const AX = 18, AZ = 32; // sân tàn tích trung tâm (nửa rộng / nửa dài)
export const WORLD = 80; // nửa cạnh bản đồ: 80 -> sân đấu 160 x 160 m cho 7-8 người (lớn hơn 120 sẽ dùng bố cục bản đồ rộng)
export const TEAM_Z = Math.round(WORLD * 0.8), FFA_R = Math.round(WORLD * 0.74);
export function sitePoints() { // 4 cụm tàn tích = 4 trại quái của chế độ Phiêu Lưu (khớp với bố cục sân nhỏ)
  return [52.5, 142.5, 232.5, 322.5].map(deg => { const a = (deg * Math.PI) / 180; return { x: Math.cos(a) * WORLD * 0.62, z: Math.sin(a) * WORLD * 0.62 }; });
}
export function spawnPoints() {
  const out = [-7.5, -2.5, 2.5, 7.5].flatMap(x => [[x, TEAM_Z], [x, -TEAM_Z]]);
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2 + Math.PI / 6; out.push([Math.cos(a) * FFA_R, Math.sin(a) * FFA_R]); }
  return out;
}

export function buildArena(scene) {
  let seed = 7;
  const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296; // cố định -> mọi máy giống nhau
  // lưới không gian để va chạm nhanh trên bản đồ lớn
  const CELL = 24, grid = new Map();
  const cellsOf = (x0, x1, z0, z1, fn) => { for (let i = Math.floor(x0 / CELL); i <= Math.floor(x1 / CELL); i++) for (let j = Math.floor(z0 / CELL); j <= Math.floor(z1 / CELL); j++) fn((i + 200) * 1000 + (j + 200)); };
  const gput = (q, x0, x1, z0, z1) => cellsOf(x0, x1, z0, z1, key => { const L = grid.get(key); if (L) L.push(q); else grid.set(key, [q]); });
  const addC = (x, z, r, h = 99) => gput({ x, z, r, h }, x - r, x + r, z - r, z + r);
  const addR = (x0, x1, z0, z1, h = 99) => gput({ x0, x1, z0, z1, h }, x0, x1, z0, z1);
  const circles = { push: o => addC(o.x, o.z, o.r, o.h) }, rects = { push: o => addR(o.x0, o.x1, o.z0, o.z1, o.h) };

  // ---------- Texture nền vẽ bằng canvas ----------
  const CW = 512, CH = Math.round(CW * AZ / AX);
  const cv = document.createElement('canvas'); cv.width = CW; cv.height = CH;
  const c = cv.getContext('2d');
  const S = CW / (2 * AX), U = x => (x + AX) * S, V = z => (z + AZ) * S;
  const blob = (x, y, r, col, a) => {
    c.globalAlpha = a; c.fillStyle = col; c.beginPath();
    c.ellipse(x, y, r, r * (0.6 + rnd() * 0.5), rnd() * 3, 0, 6.283); c.fill(); c.globalAlpha = 1;
  };
  c.fillStyle = '#5f9a3c'; c.fillRect(0, 0, CW, CH);
  for (let i = 0; i < 110; i++) blob(rnd() * CW, rnd() * CH, 18 + rnd() * 40, rnd() < 0.5 ? '#86c455' : '#4d8a32', 0.35);
  for (let i = 0; i < 70; i++) { // mảng đất xám, dồn ra rìa
    const x = rnd() * CW, y = rnd() * CH;
    const edge = Math.abs(x - CW / 2) > CW * 0.28 || Math.abs(y - CH / 2) > CH * 0.4;
    if (!edge && rnd() < 0.7) continue;
    blob(x, y, 20 + rnd() * 45, '#77776f', 0.6); blob(x + 6, y + 4, 10 + rnd() * 18, '#95958b', 0.5);
  }
  c.globalAlpha = 0.5;
  for (let i = 0; i < 1800; i++) { c.fillStyle = rnd() < 0.5 ? '#b4e47a' : '#3e7a2a'; c.fillRect(rnd() * CW, rnd() * CH, 2, 2); }
  c.globalAlpha = 1;

  // đường lát đá
  const PATH = [[0, 9], [-1.5, 14], [1, 19], [-0.5, 24], [0.5, 33]];
  const PATH2 = [[0, -5], [0.3, -9], [0, -14]];
  const stroke = (pts, w, col) => {
    c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath();
    pts.forEach((p, i) => (i ? c.lineTo(U(p[0]), V(p[1])) : c.moveTo(U(p[0]), V(p[1])))); c.stroke();
  };
  for (const P of [PATH, PATH2]) { stroke(P, 3.6 * S, '#8c8166'); stroke(P, 3.0 * S, '#cfc3a1'); }
  c.globalAlpha = 0.55;
  for (const P of [PATH, PATH2]) for (let k = 0; k < P.length - 1; k++) for (let row = 0; row < 3; row++) for (let t = 0; t < 1; t += 0.05) {
    const x = P[k][0] + (P[k + 1][0] - P[k][0]) * t + (rnd() - 0.5) * 2.4, z = P[k][1] + (P[k + 1][1] - P[k][1]) * t;
    c.fillStyle = rnd() < 0.5 ? '#b3a684' : '#e2d8ba'; c.fillRect(U(x), V(z), S * 0.6, S * 0.35);
  }
  c.globalAlpha = 1;

  // quảng trường tròn + biểu tượng gió
  const cx = U(0), cy = V(2);
  const disc = (r, fill, line) => {
    c.beginPath(); c.arc(cx, cy, r * S, 0, 6.283);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (line) { c.strokeStyle = line; c.lineWidth = 0.15 * S; c.stroke(); }
  };
  disc(7.6, '#8f866f'); disc(7.2, '#d8cfb4', '#8f866f'); disc(6.2, '#c9bfa3', '#8f866f'); disc(4.6, '#ddd5bd', '#8f866f');
  c.strokeStyle = '#a79e86'; c.lineWidth = 0.08 * S;
  for (let k = 0; k < 24; k++) {
    const a = (k / 24) * 6.283; c.beginPath();
    c.moveTo(cx + Math.cos(a) * 4.6 * S, cy + Math.sin(a) * 4.6 * S); c.lineTo(cx + Math.cos(a) * 7.2 * S, cy + Math.sin(a) * 7.2 * S); c.stroke();
  }
  disc(3.2, null, '#6d6a62');
  c.strokeStyle = '#6d6a62'; c.lineWidth = 0.28 * S; c.lineCap = 'round';
  for (let k = -1; k <= 1; k++) {
    const y = cy + k * S;
    c.beginPath(); c.moveTo(cx - 2 * S, y);
    c.bezierCurveTo(cx - 0.8 * S, y - 0.9 * S, cx + 0.8 * S, y + 0.9 * S, cx + 1.8 * S, y - 0.2 * S);
    c.arc(cx + 1.5 * S, y - 0.45 * S, 0.35 * S, 0.5, 4.2); c.stroke();
  }
  // mép sân trung tâm mờ dần để hòa vào nền rộng
  c.globalCompositeOperation = 'destination-out';
  const mask = (x0, y0, x1, y1, rx, ry, rw, rh) => {
    const g = c.createLinearGradient(x0, y0, x1, y1);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(rx, ry, rw, rh);
  };
  mask(0, 0, 60, 0, 0, 0, 60, CH); mask(CW, 0, CW - 60, 0, CW - 60, 0, 60, CH);
  mask(0, 0, 0, 60, 0, 0, CW, 60); mask(0, CH, 0, CH - 60, 0, CH - 60, CW, 60);
  c.globalCompositeOperation = 'source-over';

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2 * AX, 2 * AZ), new THREE.MeshStandardMaterial({ map: tex, roughness: 1, transparent: true }));
  ground.rotation.x = -Math.PI / 2; ground.position.y = 0.03; scene.add(ground);

  // ---------- Vật liệu & hàm dựng ----------
  const stone = new THREE.MeshStandardMaterial({ color: 0xd9d1ba, roughness: 1, flatShading: true });
  const stoneD = new THREE.MeshStandardMaterial({ color: 0xb4ab92, roughness: 1, flatShading: true });
  const trunkM = new THREE.MeshStandardMaterial({ color: 0x6b4a2b, roughness: 1 });
  const leaf = [0x4f9a3a, 0x5fb046, 0x3f8a34].map(col => new THREE.MeshStandardMaterial({ color: col, flatShading: true, roughness: 1, transparent: true, opacity: 0.85 }));
  const BOXG = new THREE.BoxGeometry(1, 1, 1), CYL = new THREE.CylinderGeometry(1, 1, 1, 10), ICO = new THREE.IcosahedronGeometry(1, 0);
  const add = (geo, mat, x, y, z, sx, sy, sz, ry = 0) => {
    const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.rotation.y = ry; scene.add(m); return m;
  };
  const wall = (x, z, w, d, h) => {
    add(BOXG, stone, x, h / 2, z, w, h, d);
    add(BOXG, stoneD, x, h + 0.08, z, w + 0.15, 0.16, d + 0.15);
    rects.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2, h });
    for (let i = 0; i < 3; i++) add(BOXG, stoneD, x + (rnd() - 0.5) * (w + 1.5), 0.15, z + (rnd() - 0.5) * (d + 1.5), 0.4 + rnd() * 0.4, 0.3, 0.4 + rnd() * 0.4, rnd() * 3);
  };
  const pillar = (x, z, h = 3.4) => {
    add(BOXG, stoneD, x, 0.2, z, 1.4, 0.4, 1.4);
    add(CYL, stone, x, h / 2, z, 0.5, h, 0.5);
    add(BOXG, stoneD, x, h + 0.1, z, 1.2, 0.25, 1.2);
    circles.push({ x, z, r: 0.7, h });
  };
  const stump = (x, z) => {
    add(BOXG, stoneD, x, 0.2, z, 1.4, 0.4, 1.4);
    add(CYL, stone, x, 0.7, z, 0.5, 1.2, 0.5).rotation.z = 0.15;
    circles.push({ x, z, r: 0.7, h: 1.2 });
  };
  const fallen = (x, z, len, ry) => { add(CYL, stone, x, 0.45, z, 0.45, len / 2, 0.45).rotation.set(0, ry, Math.PI / 2); };
  const arc = (ox, oz, r, a0, a1, h) => {
    const n = Math.max(2, Math.round(((a1 - a0) * r) / 1.6)), seg = ((a1 - a0) * r) / n;
    for (let k = 0; k <= n; k++) {
      const a = a0 + ((a1 - a0) * k) / n, x = ox + Math.cos(a) * r, z = oz + Math.sin(a) * r, hh = h * (0.7 + rnd() * 0.5);
      add(BOXG, stone, x, hh / 2, z, seg + 0.15, hh, 0.9, -(a + Math.PI / 2));
      circles.push({ x, z, r: 0.6, h: hh });
    }
  };
  const arch = (x, z) => {
    pillar(x - 2.2, z, 3.6); pillar(x + 2.2, z, 3.6);
    const t = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.4, 8, 18, Math.PI), stone); t.position.set(x, 3.7, z); scene.add(t);
  };
  const tree = (x, z, s = 1, solid = true) => {
    add(CYL, trunkM, x, 1.5 * s, z, 0.35 * s, 1.5 * s, 0.35 * s);
    for (let i = 0; i < 3; i++) add(ICO, leaf[i % 3], x + (rnd() - 0.5) * 1.6 * s, (3.6 + i * 0.5) * s, z + (rnd() - 0.5) * 1.6 * s, (1.5 + rnd() * 0.5) * s, (1.2 + rnd() * 0.4) * s, (1.5 + rnd() * 0.5) * s, rnd() * 3);
    if (solid) circles.push({ x, z, r: 0.9 * s, h: 5 });
  };

  // ---------- Bố cục ----------
  // tường viền đổ nát
  wall(-17.2, -23, 1, 12, 2.4); wall(-17.2, 5, 1, 18, 2.0); wall(17.2, -19, 1, 14, 2.2); wall(17.2, 9, 1, 14, 1.8);
  wall(-9, -31.3, 10, 1, 2.2); wall(9.5, -31.3, 9, 1, 1.6); wall(-10, 31.3, 8, 1, 1.8); wall(11, 31.3, 7, 1, 2.4);
  // phòng đổ nát
  wall(11.5, 17.5, 9, 1, 2.0); wall(7.5, 21, 1, 7, 2.0);        // dưới phải (chữ L)
  wall(-10, 17.5, 9, 1, 2.0); wall(-10, 21, 1, 7, 2.2);         // dưới trái (chữ T)
  wall(-10, -17, 1, 5, 1.8); wall(-8, -19.5, 5, 1, 1.8); wall(-6, -22, 1, 5, 1.8); // trên trái (zíc-zắc)
  wall(10, -17.5, 8, 1, 2.0); wall(14, -21.5, 1, 8, 2.2); wall(8, -22, 3, 1, 1.2); // trên phải
  // cổng vòm + cột
  arch(0, -14);
  pillar(-7, -6); pillar(7, -7); pillar(-12, 6); pillar(12, 7);
  stump(-13, -3); stump(11, -2); stump(-3, 16); stump(5, 14);
  // vòng cung đổ quanh quảng trường
  arc(0, 2, 11, 2.3, 3.5, 1.7); arc(0, 2, 11, -0.35, 0.75, 1.7); arc(0, 2, 11, 4.0, 4.9, 1.5);
  // cột nằm ngang + đá vụn
  fallen(-8, 2, 4, 0.5); fallen(9, 4, 4, -0.3); fallen(-6, -10, 3, 1.2); fallen(6, -11, 3, 0.2); fallen(-4, 12, 3, 0.9); fallen(4, -3, 2.5, 1.9);
  for (let i = 0; i < 40; i++) {
    const x = (rnd() - 0.5) * 2 * (AX - 2), z = (rnd() - 0.5) * 2 * (AZ - 2);
    if (Math.abs(x) < 2 && z > 8) continue; // chừa đường đi
    add(BOXG, stoneD, x, 0.15, z, 0.3 + rnd() * 0.5, 0.3, 0.3 + rnd() * 0.5, rnd() * 3);
  }
  // cây trong sân (có va chạm) và rừng bao quanh (trang trí)
  tree(-16, -29, 1.1); tree(16, -29, 1.2); tree(-16, 28, 1.2); tree(16.5, 27, 1.1);
  tree(-15.5, -12, 1); tree(15, -7, 1); tree(-15.5, 14, 1.1); tree(15, 13, 1);
  for (let i = 0; i < 24; i++) {
    const side = i % 4, o = 2.5 + rnd() * 6, t = (rnd() - 0.5) * 2;
    const x = side < 2 ? (side ? 1 : -1) * (AX + o) : t * (AX + 6), z = side < 2 ? t * (AZ + 6) : (side === 2 ? 1 : -1) * (AZ + o);
    tree(x, z, 1.2 + rnd() * 0.6, false);
  }

  // ================= THẾ GIỚI RỘNG ~2 km² =================
  const W = WORLD, SIZE = W * 2, spawns = spawnPoints();
  const SMALL = W <= 120, SS = SMALL ? 0.6 : 1, NS = SMALL ? 0.2 : 1, CLR = SMALL ? 12 : 28; // thông số cho sân đấu nhỏ
  const hash = (a, b) => { let n = (Math.imul(a, 374761393) + Math.imul(b, 668265263)) | 0; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; };
  const noise = (x, z, sc) => {
    const fx = x / sc, fz = z / sc, i = Math.floor(fx), j = Math.floor(fz), u = fx - i, v = fz - j, su = u * u * (3 - 2 * u), sv = v * v * (3 - 2 * v);
    return (hash(i, j) * (1 - su) + hash(i + 1, j) * su) * (1 - sv) + (hash(i, j + 1) * (1 - su) + hash(i + 1, j + 1) * su) * sv;
  };
  const dens = (x, z) => noise(x, z, 120 * NS) * 0.65 + noise(x, z, 45 * NS) * 0.35;

  // các điểm tàn tích rải khắp bản đồ + mạng đường nối
  const sites = [];
  if (SMALL) { // 4 cụm tàn tích đối xứng quanh sân trung tâm, nằm giữa các điểm xuất phát
    [52.5, 142.5, 232.5, 322.5].forEach((deg, i) => { const a = (deg * Math.PI) / 180; sites.push({ x: Math.cos(a) * W * 0.62, z: Math.sin(a) * W * 0.62, kind: i % 3 }); });
  } else for (let t = 0; t < 600 && sites.length < Math.round(16 * (W / 700) ** 2); t++) {
    const x = (rnd() * 2 - 1) * (W - 90), z = (rnd() * 2 - 1) * (W - 90);
    if (Math.hypot(x, z) < 130 || spawns.some(p => Math.hypot(x - p[0], z - p[1]) < 90) || sites.some(p => Math.hypot(x - p.x, z - p.z) < 150)) continue;
    sites.push({ x, z, kind: sites.length % 3 });
  }
  const roads = [], linked = [{ x: 0, z: 0 }];
  const connect = (a, b) => {
    const n = Math.max(2, Math.round(Math.hypot(b.x - a.x, b.z - a.z) / 60)), pts = [[a.x, a.z]];
    for (let q = 1; q < n; q++) { const t = q / n; pts.push([a.x + (b.x - a.x) * t + (rnd() - 0.5) * Math.min(30, W * 0.1), a.z + (b.z - a.z) * t + (rnd() - 0.5) * Math.min(30, W * 0.1)]); }
    pts.push([b.x, b.z]); roads.push(pts);
  };
  const nearest = p => linked.reduce((m, q) => (Math.hypot(q.x - p.x, q.z - p.z) < Math.hypot(m.x - p.x, m.z - p.z) ? q : m));
  [...sites].sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z)).forEach(p => { connect(nearest(p), p); linked.push(p); });
  [{ x: 0, z: TEAM_Z }, { x: 0, z: -TEAM_Z }].forEach(p => connect(nearest(p), p));
  const nearRoad = (x, z, w) => {
    for (const pts of roads) for (let i = 0; i < pts.length - 1; i++) {
      const ax = pts[i][0], az = pts[i][1], dx = pts[i + 1][0] - ax, dz = pts[i + 1][1] - az;
      const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz || 1)));
      if (Math.hypot(x - ax - dx * t, z - az - dz * t) < w) return true;
    }
    return false;
  };

  // texture nền toàn bản đồ (1024 px) + texture chi tiết lặp lại
  const MS = SMALL ? 512 : 1024, mc = document.createElement('canvas'); mc.width = mc.height = MS;
  const mx = mc.getContext('2d'), img = mx.createImageData(MS, MS), px = img.data, ks = SIZE / MS;
  for (let j = 0; j < MS; j++) for (let i = 0; i < MS; i++) {
    const x = (i + 0.5) * ks - W, z = (j + 0.5) * ks - W, n = dens(x, z), m = noise(x + 999, z - 500, 200 * NS);
    let r = 100 - n * 50 + m * 20, g = 170 - n * 70 + m * 15, b = 62 - n * 28;
    if (m > 0.62) { const t = Math.min(1, (m - 0.62) * 6) * 0.7; r += (118 - r) * t; g += (118 - g) * t; b += (110 - b) * t; }
    const o = (j * MS + i) * 4; px[o] = r; px[o + 1] = g; px[o + 2] = b; px[o + 3] = 255;
  }
  mx.putImageData(img, 0, 0);
  const P = (x, z) => [(x + W) / ks, (z + W) / ks];
  const patch = (x, z, r, col) => { const q = P(x, z); mx.fillStyle = col; mx.beginPath(); mx.arc(q[0], q[1], r / ks, 0, 6.283); mx.fill(); };
  for (const p of sites) { patch(p.x, p.z, 36 * SS, 'rgba(120,118,108,.55)'); patch(p.x, p.z, 20 * SS, 'rgba(190,180,150,.4)'); }
  for (const p of spawns) patch(p[0], p[1], 14, 'rgba(200,190,160,.5)');
  mx.lineCap = 'round'; mx.lineJoin = 'round';
  for (const pts of roads) {
    mx.beginPath(); pts.forEach((p, i) => { const q = P(p[0], p[1]); if (i) mx.lineTo(q[0], q[1]); else mx.moveTo(q[0], q[1]); });
    mx.strokeStyle = '#8a7f66'; mx.lineWidth = 7 / ks; mx.stroke();
    mx.strokeStyle = '#bfb392'; mx.lineWidth = 5 / ks; mx.stroke();
  }
  const macroTex = new THREE.CanvasTexture(mc); macroTex.colorSpace = THREE.SRGBColorSpace; macroTex.anisotropy = 4;
  const dc = document.createElement('canvas'); dc.width = dc.height = 128;
  const dctx = dc.getContext('2d'), dimg = dctx.createImageData(128, 128);
  for (let i = 0; i < 128 * 128; i++) { const v = 128 + (rnd() - 0.5) * 110; dimg.data[i * 4] = dimg.data[i * 4 + 1] = dimg.data[i * 4 + 2] = v; dimg.data[i * 4 + 3] = 255; }
  dctx.putImageData(dimg, 0, 0);
  const detailTex = new THREE.CanvasTexture(dc); detailTex.wrapS = detailTex.wrapT = THREE.RepeatWrapping;
  const gm = new THREE.MeshStandardMaterial({ map: macroTex, roughness: 1 });
  gm.onBeforeCompile = sh => {
    sh.uniforms.detail = { value: detailTex };
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform sampler2D detail;')
      .replace('#include <map_fragment>', '#include <map_fragment>\n  diffuseColor.rgb *= 0.6 + 0.8 * texture2D(detail, vMapUv * ' + (SIZE / 5).toFixed(1) + ').r;');
  };
  const big = new THREE.Mesh(new THREE.PlaneGeometry(SIZE, SIZE), gm); big.rotation.x = -Math.PI / 2; scene.add(big);
  const outer = new THREE.Mesh(new THREE.PlaneGeometry(SIZE * 3, SIZE * 3), new THREE.MeshStandardMaterial({ color: 0x1f3d1a, roughness: 1 }));
  outer.rotation.x = -Math.PI / 2; outer.position.y = -0.05; scene.add(outer);

  // instancing theo chunk: hàng nghìn cây/tường vẫn nhẹ vì chỉ vẽ chunk trong tầm nhìn
  const CHUNK = 140, sets = {}, dummy = new THREE.Object3D(), tmpC = new THREE.Color();
  const mk = (name, geo, mat) => { sets[name] = { geo, mat, ch: new Map() }; };
  mk('trunk', new THREE.CylinderGeometry(0.28, 0.4, 1, 5).translate(0, 0.5, 0), trunkM);
  mk('canopy', new THREE.IcosahedronGeometry(1, 0), new THREE.MeshStandardMaterial({ color: 0xffffff, flatShading: true, roughness: 1 }));
  mk('wall', new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), stone);
  mk('pillar', new THREE.CylinderGeometry(1, 1, 1, 8).translate(0, 0.5, 0), stone);
  mk('rubble', new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), stoneD);
  mk('rock', new THREE.DodecahedronGeometry(1, 0), new THREE.MeshStandardMaterial({ color: 0x8d8d84, flatShading: true, roughness: 1 }));
  const inst = (name, x, y, z, sx, sy, sz, ry, col) => {
    const st = sets[name], key = Math.floor((x + W + 200) / CHUNK) * 100 + Math.floor((z + W + 200) / CHUNK);
    let L = st.ch.get(key); if (!L) { L = []; st.ch.set(key, L); }
    L.push([x, y, z, sx, sy, sz, ry, col]);
  };
  const finish = () => {
    for (const name in sets) {
      const st = sets[name];
      for (const L of st.ch.values()) {
        const im = new THREE.InstancedMesh(st.geo, st.mat, L.length);
        L.forEach((e, i) => {
          dummy.position.set(e[0], e[1], e[2]); dummy.scale.set(e[3], e[4], e[5]); dummy.rotation.set(0, e[6], 0); dummy.updateMatrix();
          im.setMatrixAt(i, dummy.matrix); if (e[7] !== undefined) im.setColorAt(i, tmpC.setHex(e[7]));
        });
        im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
        im.computeBoundingSphere(); scene.add(im);
      }
    }
  };
  const TCOL = [0x4f9a3a, 0x5fb046, 0x3f8a34, 0x2f7a30];
  const addTree = (x, z, s, solid) => {
    const h = 3.2 * s; inst('trunk', x, 0, z, s, h, s, 0);
    for (let i = 0; i < 2; i++) inst('canopy', x + (rnd() - 0.5) * s, h * (0.9 + i * 0.35), z + (rnd() - 0.5) * s, (1.7 - i * 0.4) * s, 1.3 * s, (1.7 - i * 0.4) * s, rnd() * 3, TCOL[Math.floor(rnd() * 4)]);
    if (solid) addC(x, z, 0.8 * s, 5);
  };
  const clear = (x, z) => spawns.some(p => Math.hypot(x - p[0], z - p[1]) < CLR) || (Math.abs(x) < AX + 8 && Math.abs(z) < AZ + 8) || sites.some(p => Math.hypot(x - p.x, z - p.z) < 24 * SS);

  // rừng: dày/thưa theo noise
  const nTrees = SMALL ? Math.round((W * 2) ** 2 / 150) : Math.round(2600 * (W / 700) ** 2), ROCKS = SMALL ? 50 : 400;
  for (let t = 0, n = 0; t < nTrees * 4 && n < nTrees; t++) {
    const x = (rnd() * 2 - 1) * (W - 6), z = (rnd() * 2 - 1) * (W - 6);
    if (rnd() > Math.pow(dens(x, z), 2.2) * 2.6) continue;
    if (clear(x, z) || nearRoad(x, z, 5)) continue;
    addTree(x, z, 0.9 + rnd() * 0.7, true); n++;
  }
  // dải rừng dày ở rìa bản đồ
  for (let i = 0; i < (SMALL ? 240 : 700); i++) {
    const o = W - (SMALL ? 10 : 20) + rnd() * (SMALL ? 40 : 75), a = (rnd() * 2 - 1) * (W + (SMALL ? 40 : 70)), side = i % 4;
    const x = side === 0 ? o : side === 1 ? -o : a, z = side === 2 ? o : side === 3 ? -o : a;
    addTree(x, z, 1.1 + rnd() * 0.9, Math.abs(x) < W + 5 && Math.abs(z) < W + 5);
  }
  // đá rải rác
  for (let i = 0, n = 0; i < 2000 && n < ROCKS; i++) {
    const x = (rnd() * 2 - 1) * (W - 6), z = (rnd() * 2 - 1) * (W - 6);
    if (clear(x, z)) continue;
    const s2 = 0.5 + rnd() * 1.2; inst('rock', x, 0.15, z, s2, s2 * 0.7, s2, rnd() * 3); n++;
  }

  // các điểm tàn tích
  const wallI = (x, z, w, d, h) => { inst('wall', x, 0, z, w, h, d, 0); addR(x - w / 2, x + w / 2, z - d / 2, z + d / 2, h); };
  const pillarI = (x, z, h) => { inst('pillar', x, 0, z, 0.55, h, 0.55, 0); addC(x, z, 0.7, h); };
  const room = (ox, oz, w, d) => {
    const door = Math.floor(rnd() * 4), h0 = 1.8 + rnd();
    const seg = (x, z, ww, dd, idx) => {
      if (idx !== door) { wallI(x, z, ww, dd, h0 * (0.5 + rnd() * 0.7)); return; }
      if (ww > dd) { const half = (ww - 3.2) / 2; wallI(x - ww / 2 + half / 2, z, half, dd, h0); wallI(x + ww / 2 - half / 2, z, half, dd, h0 * 0.6); }
      else { const half = (dd - 3.2) / 2; wallI(x, z - dd / 2 + half / 2, ww, half, h0); wallI(x, z + dd / 2 - half / 2, ww, half, h0 * 0.6); }
    };
    seg(ox, oz - d / 2, w, 1, 0); seg(ox, oz + d / 2, w, 1, 1); seg(ox - w / 2, oz, 1, d, 2); seg(ox + w / 2, oz, 1, d, 3);
  };
  for (const p of sites) {
    if (p.kind === 0) { for (let q = 0; q < 3; q++) { const a = rnd() * 6.283, r = (8 + rnd() * 14) * SS; room(p.x + Math.cos(a) * r, p.z + Math.sin(a) * r, 9 + rnd() * 5, 8 + rnd() * 4); } }
    else if (p.kind === 1) { for (let q = 0; q < 10; q++) { const a = (q / 10) * 6.283; if (rnd() < 0.2) continue; pillarI(p.x + Math.cos(a) * 11 * SS, p.z + Math.sin(a) * 11 * SS, rnd() < 0.3 ? 1.2 : 3.4); } wallI(p.x, p.z, 4, 4, 1.2); }
    else { room(p.x, p.z, 18 * SS, 14 * SS); for (const [dx, dz] of [[-12, -10], [12, -10], [-12, 10], [12, 10]]) pillarI(p.x + dx * SS, p.z + dz * SS, 2.6 + rnd()); }
    for (let q = 0; q < 14; q++) inst('rubble', p.x + (rnd() - 0.5) * 40 * SS, 0, p.z + (rnd() - 0.5) * 40 * SS, 0.4 + rnd() * 0.8, 0.4, 0.4 + rnd() * 0.8, rnd() * 3);
  }
  finish();

  // ---------- Va chạm ----------
  function resolve(pos, rad, y = 0) { // rad <= 0: đang bay trên không, chỉ giới hạn biên bản đồ
    if (rad > 0) cellsOf(pos.x - rad, pos.x + rad, pos.z - rad, pos.z + rad, key => {
      const L = grid.get(key); if (!L) return;
      for (const q of L) {
        if (y >= q.h - 0.15) continue; // đang ở trên đỉnh vật cản thì không bị chặn ngang
        if (q.r !== undefined) {
          const dx = pos.x - q.x, dz = pos.z - q.z, dd = Math.hypot(dx, dz), m = q.r + rad;
          if (dd < m) { const s2 = m / (dd || 1); pos.x = q.x + dx * s2; pos.z = q.z + dz * s2; }
        } else {
          const nx = Math.max(q.x0, Math.min(pos.x, q.x1)), nz = Math.max(q.z0, Math.min(pos.z, q.z1));
          const dx = pos.x - nx, dz = pos.z - nz, dd = Math.hypot(dx, dz);
          if (dd < rad) {
            if (dd > 1e-6) { const s2 = rad / dd; pos.x = nx + dx * s2; pos.z = nz + dz * s2; }
            else {
              const l = pos.x - q.x0, rr = q.x1 - pos.x, t = pos.z - q.z0, b = q.z1 - pos.z, m = Math.min(l, rr, t, b);
              if (m === l) pos.x = q.x0 - rad; else if (m === rr) pos.x = q.x1 + rad; else if (m === t) pos.z = q.z0 - rad; else pos.z = q.z1 + rad;
            }
          }
        }
      }
    });
    pos.x = Math.max(-W + 0.8, Math.min(W - 0.8, pos.x));
    pos.z = Math.max(-W + 0.8, Math.min(W - 0.8, pos.z));
  }
  function hits(x, z) { // đạn chạm tường/cột/cây
    const L = grid.get((Math.floor(x / CELL) + 200) * 1000 + Math.floor(z / CELL) + 200);
    if (!L) return false;
    for (const q of L) {
      if (q.r !== undefined) { if (Math.hypot(x - q.x, z - q.z) < q.r) return true; }
      else if (x > q.x0 && x < q.x1 && z > q.z0 && z < q.z1) return true;
    }
    return false;
  }
  function floorAt(x, z, y) { // độ cao mặt đứng được: đỉnh tường/cột/đá thấp hơn chân nhân vật
    let f = 0;
    cellsOf(x - 0.3, x + 0.3, z - 0.3, z + 0.3, key => {
      const L = grid.get(key); if (!L) return;
      for (const q of L) {
        if (q.h > y + 0.35) continue;
        const inside = q.r !== undefined ? Math.hypot(x - q.x, z - q.z) < q.r + 0.15 : (x > q.x0 - 0.15 && x < q.x1 + 0.15 && z > q.z0 - 0.15 && z < q.z1 + 0.15);
        if (inside && q.h > f) f = q.h;
      }
    });
    return f;
  }
  function blocked(x, z, pad) { // dùng cho camera: có vật cản trong bán kính pad không
    let hit = false;
    cellsOf(x - pad, x + pad, z - pad, z + pad, key => {
      if (hit) return;
      const L = grid.get(key); if (!L) return;
      for (const q of L) {
        if (q.r !== undefined ? Math.hypot(x - q.x, z - q.z) < q.r + pad : (x > q.x0 - pad && x < q.x1 + pad && z > q.z0 - pad && z < q.z1 + pad)) { hit = true; return; }
      }
    });
    return hit;
  }
  return { resolve, hits, blocked, floorAt };
}
