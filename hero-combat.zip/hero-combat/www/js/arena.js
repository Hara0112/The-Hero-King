import * as THREE from 'three';

// Bản đồ tàn tích: sân chữ nhật dọc, quảng trường tròn ở giữa, cổng vòm, đường lát đá, tường đổ, cây rừng.
export const HX = 18, HZ = 32; // nửa rộng / nửa dài (đơn vị thế giới)

export function buildArena(scene) {
  let seed = 7;
  const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296; // cố định -> mọi máy giống nhau
  const circles = [], rects = [];

  // ---------- Texture nền vẽ bằng canvas ----------
  const CW = 512, CH = Math.round(CW * HZ / HX);
  const cv = document.createElement('canvas'); cv.width = CW; cv.height = CH;
  const c = cv.getContext('2d');
  const S = CW / (2 * HX), U = x => (x + HX) * S, V = z => (z + HZ) * S;
  const blob = (x, y, r, col, a) => {
    c.globalAlpha = a; c.fillStyle = col; c.beginPath();
    c.ellipse(x, y, r, r * (0.6 + rnd() * 0.5), rnd() * 3, 0, 6.283); c.fill(); c.globalAlpha = 1;
  };
  c.fillStyle = '#5f9a3c'; c.fillRect(0, 0, CW, CH);
  for (let i = 0; i < 110; i++) blob(rnd() * CW, rnd() * CH, 18 + rnd() * 40, rnd() < 0.5 ? '#86c455' : '#4d8a32', 0.35);
  for (let i = 0; i < 70; i++) { // mảng đất xám, dồn ra rìa
    const x = rnd() * CW, y = rnd() * CH;
    const edge = Math.abs(x - CW / 2) > CW * 0.28 || Math.abs(y - CH / 2) > CH * 0.4;
    if (!edge && rnd() < 0.7) continue;
    blob(x, y, 20 + rnd() * 45, '#77776f', 0.6); blob(x + 6, y + 4, 10 + rnd() * 18, '#95958b', 0.5);
  }
  c.globalAlpha = 0.5;
  for (let i = 0; i < 1800; i++) { c.fillStyle = rnd() < 0.5 ? '#b4e47a' : '#3e7a2a'; c.fillRect(rnd() * CW, rnd() * CH, 2, 2); }
  c.globalAlpha = 1;

  // đường lát đá
  const PATH = [[0, 9], [-1.5, 14], [1, 19], [-0.5, 24], [0.5, 33]];
  const PATH2 = [[0, -5], [0.3, -9], [0, -14]];
  const stroke = (pts, w, col) => {
    c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round'; c.beginPath();
    pts.forEach((p, i) => (i ? c.lineTo(U(p[0]), V(p[1])) : c.moveTo(U(p[0]), V(p[1])))); c.stroke();
  };
  for (const P of [PATH, PATH2]) { stroke(P, 3.6 * S, '#8c8166'); stroke(P, 3.0 * S, '#cfc3a1'); }
  c.globalAlpha = 0.55;
  for (const P of [PATH, PATH2]) for (let k = 0; k < P.length - 1; k++) for (let row = 0; row < 3; row++) for (let t = 0; t < 1; t += 0.05) {
    const x = P[k][0] + (P[k + 1][0] - P[k][0]) * t + (rnd() - 0.5) * 2.4, z = P[k][1] + (P[k + 1][1] - P[k][1]) * t;
    c.fillStyle = rnd() < 0.5 ? '#b3a684' : '#e2d8ba'; c.fillRect(U(x), V(z), S * 0.6, S * 0.35);
  }
  c.globalAlpha = 1;

  // quảng trường tròn + biểu tượng gió
  const cx = U(0), cy = V(2);
  const disc = (r, fill, line) => {
    c.beginPath(); c.arc(cx, cy, r * S, 0, 6.283);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (line) { c.strokeStyle = line; c.lineWidth = 0.15 * S; c.stroke(); }
  };
  disc(7.6, '#8f866f'); disc(7.2, '#d8cfb4', '#8f866f'); disc(6.2, '#c9bfa3', '#8f866f'); disc(4.6, '#ddd5bd', '#8f866f');
  c.strokeStyle = '#a79e86'; c.lineWidth = 0.08 * S;
  for (let k = 0; k < 24; k++) {
    const a = (k / 24) * 6.283; c.beginPath();
    c.moveTo(cx + Math.cos(a) * 4.6 * S, cy + Math.sin(a) * 4.6 * S); c.lineTo(cx + Math.cos(a) * 7.2 * S, cy + Math.sin(a) * 7.2 * S); c.stroke();
  }
  disc(3.2, null, '#6d6a62');
  c.strokeStyle = '#6d6a62'; c.lineWidth = 0.28 * S; c.lineCap = 'round';
  for (let k = -1; k <= 1; k++) {
    const y = cy + k * S;
    c.beginPath(); c.moveTo(cx - 2 * S, y);
    c.bezierCurveTo(cx - 0.8 * S, y - 0.9 * S, cx + 0.8 * S, y + 0.9 * S, cx + 1.8 * S, y - 0.2 * S);
    c.arc(cx + 1.5 * S, y - 0.45 * S, 0.35 * S, 0.5, 4.2); c.stroke();
  }
  // viền rừng tối ở mép
  const fade = (x0, y0, x1, y1, rx, ry, rw, rh) => {
    const g = c.createLinearGradient(x0, y0, x1, y1);
    g.addColorStop(0, 'rgba(25,55,20,.6)'); g.addColorStop(1, 'rgba(25,55,20,0)');
    c.fillStyle = g; c.fillRect(rx, ry, rw, rh);
  };
  fade(0, 0, 60, 0, 0, 0, 60, CH); fade(CW, 0, CW - 60, 0, CW - 60, 0, 60, CH);
  fade(0, 0, 0, 60, 0, 0, CW, 60); fade(0, CH, 0, CH - 60, 0, CH - 60, CW, 60);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2 * HX, 2 * HZ), new THREE.MeshStandardMaterial({ map: tex, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; scene.add(ground);
  const outer = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), new THREE.MeshStandardMaterial({ color: 0x1f3d1a, roughness: 1 }));
  outer.rotation.x = -Math.PI / 2; outer.position.y = -0.03; scene.add(outer);

  // ---------- Vật liệu & hàm dựng ----------
  const stone = new THREE.MeshStandardMaterial({ color: 0xd9d1ba, roughness: 1, flatShading: true });
  const stoneD = new THREE.MeshStandardMaterial({ color: 0xb4ab92, roughness: 1, flatShading: true });
  const trunkM = new THREE.MeshStandardMaterial({ color: 0x6b4a2b, roughness: 1 });
  const leaf = [0x4f9a3a, 0x5fb046, 0x3f8a34].map(col => new THREE.MeshStandardMaterial({ color: col, flatShading: true, roughness: 1, transparent: true, opacity: 0.85 }));
  const BOXG = new THREE.BoxGeometry(1, 1, 1), CYL = new THREE.CylinderGeometry(1, 1, 1, 10), ICO = new THREE.IcosahedronGeometry(1, 0);
  const add = (geo, mat, x, y, z, sx, sy, sz, ry = 0) => {
    const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.rotation.y = ry; scene.add(m); return m;
  };
  const wall = (x, z, w, d, h) => {
    add(BOXG, stone, x, h / 2, z, w, h, d);
    add(BOXG, stoneD, x, h + 0.08, z, w + 0.15, 0.16, d + 0.15);
    rects.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 });
    for (let i = 0; i < 3; i++) add(BOXG, stoneD, x + (rnd() - 0.5) * (w + 1.5), 0.15, z + (rnd() - 0.5) * (d + 1.5), 0.4 + rnd() * 0.4, 0.3, 0.4 + rnd() * 0.4, rnd() * 3);
  };
  const pillar = (x, z, h = 3.4) => {
    add(BOXG, stoneD, x, 0.2, z, 1.4, 0.4, 1.4);
    add(CYL, stone, x, h / 2, z, 0.5, h, 0.5);
    add(BOXG, stoneD, x, h + 0.1, z, 1.2, 0.25, 1.2);
    circles.push({ x, z, r: 0.7 });
  };
  const stump = (x, z) => {
    add(BOXG, stoneD, x, 0.2, z, 1.4, 0.4, 1.4);
    add(CYL, stone, x, 0.7, z, 0.5, 1.2, 0.5).rotation.z = 0.15;
    circles.push({ x, z, r: 0.7 });
  };
  const fallen = (x, z, len, ry) => { add(CYL, stone, x, 0.45, z, 0.45, len / 2, 0.45).rotation.set(0, ry, Math.PI / 2); };
  const arc = (ox, oz, r, a0, a1, h) => {
    const n = Math.max(2, Math.round(((a1 - a0) * r) / 1.6)), seg = ((a1 - a0) * r) / n;
    for (let k = 0; k <= n; k++) {
      const a = a0 + ((a1 - a0) * k) / n, x = ox + Math.cos(a) * r, z = oz + Math.sin(a) * r, hh = h * (0.7 + rnd() * 0.5);
      add(BOXG, stone, x, hh / 2, z, seg + 0.15, hh, 0.9, -(a + Math.PI / 2));
      circles.push({ x, z, r: 0.6 });
    }
  };
  const arch = (x, z) => {
    pillar(x - 2.2, z, 3.6); pillar(x + 2.2, z, 3.6);
    const t = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.4, 8, 18, Math.PI), stone); t.position.set(x, 3.7, z); scene.add(t);
  };
  const tree = (x, z, s = 1, solid = true) => {
    add(CYL, trunkM, x, 1.5 * s, z, 0.35 * s, 1.5 * s, 0.35 * s);
    for (let i = 0; i < 3; i++) add(ICO, leaf[i % 3], x + (rnd() - 0.5) * 1.6 * s, (3.6 + i * 0.5) * s, z + (rnd() - 0.5) * 1.6 * s, (1.5 + rnd() * 0.5) * s, (1.2 + rnd() * 0.4) * s, (1.5 + rnd() * 0.5) * s, rnd() * 3);
    if (solid) circles.push({ x, z, r: 0.9 * s });
  };

  // ---------- Bố cục ----------
  // tường viền đổ nát
  wall(-17.2, -23, 1, 12, 2.4); wall(-17.2, 5, 1, 18, 2.0); wall(17.2, -19, 1, 14, 2.2); wall(17.2, 9, 1, 14, 1.8);
  wall(-9, -31.3, 10, 1, 2.2); wall(9.5, -31.3, 9, 1, 1.6); wall(-10, 31.3, 8, 1, 1.8); wall(11, 31.3, 7, 1, 2.4);
  // phòng đổ nát
  wall(11.5, 17.5, 9, 1, 2.0); wall(7.5, 21, 1, 7, 2.0);        // dưới phải (chữ L)
  wall(-10, 17.5, 9, 1, 2.0); wall(-10, 21, 1, 7, 2.2);         // dưới trái (chữ T)
  wall(-10, -17, 1, 5, 1.8); wall(-8, -19.5, 5, 1, 1.8); wall(-6, -22, 1, 5, 1.8); // trên trái (zíc-zắc)
  wall(10, -17.5, 8, 1, 2.0); wall(14, -21.5, 1, 8, 2.2); wall(8, -22, 3, 1, 1.2); // trên phải
  // cổng vòm + cột
  arch(0, -14);
  pillar(-7, -6); pillar(7, -7); pillar(-12, 6); pillar(12, 7);
  stump(-13, -3); stump(11, -2); stump(-3, 16); stump(5, 14);
  // vòng cung đổ quanh quảng trường
  arc(0, 2, 11, 2.3, 3.5, 1.7); arc(0, 2, 11, -0.35, 0.75, 1.7); arc(0, 2, 11, 4.0, 4.9, 1.5);
  // cột nằm ngang + đá vụn
  fallen(-8, 2, 4, 0.5); fallen(9, 4, 4, -0.3); fallen(-6, -10, 3, 1.2); fallen(6, -11, 3, 0.2); fallen(-4, 12, 3, 0.9); fallen(4, -3, 2.5, 1.9);
  for (let i = 0; i < 40; i++) {
    const x = (rnd() - 0.5) * 2 * (HX - 2), z = (rnd() - 0.5) * 2 * (HZ - 2);
    if (Math.abs(x) < 2 && z > 8) continue; // chừa đường đi
    add(BOXG, stoneD, x, 0.15, z, 0.3 + rnd() * 0.5, 0.3, 0.3 + rnd() * 0.5, rnd() * 3);
  }
  // cây trong sân (có va chạm) và rừng bao quanh (trang trí)
  tree(-16, -29, 1.1); tree(16, -29, 1.2); tree(-16, 28, 1.2); tree(16.5, 27, 1.1);
  tree(-15.5, -12, 1); tree(15, -7, 1); tree(-15.5, 14, 1.1); tree(15, 13, 1);
  for (let i = 0; i < 24; i++) {
    const side = i % 4, o = 2.5 + rnd() * 6, t = (rnd() - 0.5) * 2;
    const x = side < 2 ? (side ? 1 : -1) * (HX + o) : t * (HX + 6), z = side < 2 ? t * (HZ + 6) : (side === 2 ? 1 : -1) * (HZ + o);
    tree(x, z, 1.2 + rnd() * 0.6, false);
  }

  // ---------- Va chạm ----------
  function resolve(pos, rad) {
    for (const k of circles) {
      const dx = pos.x - k.x, dz = pos.z - k.z, d = Math.hypot(dx, dz), m = k.r + rad;
      if (d < m) { const s = m / (d || 1); pos.x = k.x + dx * s; pos.z = k.z + dz * s; }
    }
    for (const r of rects) {
      const nx = Math.max(r.x0, Math.min(pos.x, r.x1)), nz = Math.max(r.z0, Math.min(pos.z, r.z1));
      const dx = pos.x - nx, dz = pos.z - nz, d = Math.hypot(dx, dz);
      if (d < rad) {
        if (d > 1e-6) { const s = rad / d; pos.x = nx + dx * s; pos.z = nz + dz * s; }
        else {
          const l = pos.x - r.x0, rr = r.x1 - pos.x, t = pos.z - r.z0, b = r.z1 - pos.z, m = Math.min(l, rr, t, b);
          if (m === l) pos.x = r.x0 - rad; else if (m === rr) pos.x = r.x1 + rad; else if (m === t) pos.z = r.z0 - rad; else pos.z = r.z1 + rad;
        }
      }
    }
    pos.x = Math.max(-HX + 0.8, Math.min(HX - 0.8, pos.x));
    pos.z = Math.max(-HZ + 0.8, Math.min(HZ - 0.8, pos.z));
  }
  function hits(x, z) { // đạn chạm tường/cột/cây
    for (const k of circles) if (Math.hypot(x - k.x, z - k.z) < k.r) return true;
    for (const r of rects) if (x > r.x0 && x < r.x1 && z > r.z0 && z < r.z1) return true;
    return false;
  }
  return { resolve, hits };
}
