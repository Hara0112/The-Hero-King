// Mỗi tướng: skills[0]=đánh thường, [1..3]=kỹ năng, [4]=tuyệt chiêu (ult). d = mô tả hiển thị.
// Các hero cũ đã bị xóa. Skin 3D của Asasin nằm ở hero_models.js
export const HEROES = {
  asasin: {
    name: 'Asasin', role: 'Sát thủ công nghệ', color: 0x2aa8ff, hp: 900, speed: 7.2, ls: 0.12,
    passive: 'Lưỡi Năng Lượng: hút 12% sát thương gây ra. Ngoài giao tranh 4 giây chạy nhanh x1,9.',
    skills: [
      { n: 'Chém Song Kiếm', type: 'melee', cd: 0.4, dmg: 45, range: 2.6, arc: 1.7, knock: 1,
        d: 'Chém nhanh bằng hai lưỡi kiếm ở cổ tay.' },
      { n: 'Nhảy Mèo', type: 'leap', cd: 6, dist: 9, speed: 20, dmg: 70, radius: 3, stun: 0.5, knock: 3,
        d: 'Bật nhảy qua tường, cột, cây; tiếp đất gây sát thương vùng và choáng nhẹ.' },
      { n: 'Đạp Tường', type: 'dash', kick: true, cd: 9, dist: 5.5, speed: 34, dmg: 90, stun: 0.6, knock: 5,
        rebound: { dist: 7, speed: 24 },
        d: 'Lao tới đạp kẻ địch (hiện tường lưới sáng) rồi bật ngược ra sau để rút lui.' },
      { n: 'Chạy Ảnh', type: 'buff', cd: 12, speed: 1.9, dur: 4,
        d: 'Tăng tốc chạy x1,9 trong 4 giây, để lại tàn ảnh xanh.' },
      { n: 'Bão Kiếm Chém', type: 'storm', cd: 40, wind: 0.5, dist: 9, speed: 45, rushDmg: 100, dmg: 260, range: 7.5, arc: 2.8,
        stun: 1.2, knock: 8, exec: 0.25, ult: true,
        d: 'Khoanh hai kiếm (0,5s, bị choáng sẽ hủy), rút katana lao tới rồi chém vòng cung. Kẻ địch dưới 25% máu bị xử tử.' }
    ]
  },
  // Time Clown: skin 3D đã xong; bộ chiêu bên dưới là TẠM THỜI (dùng các kiểu chiêu có sẵn), chờ làm đúng theo thiết kế
  timeclown: {
    name: 'Time Clown', role: 'Pháp sư / Sát thủ', color: 0xb06bff, hp: 850, speed: 6.6,
    passive: 'Nguyền Rủa Thời Gian: (đang chờ làm).',
    skills: [
      { n: 'Ném Bài', type: 'projectile', cd: 0.6, dmg: 40, speed: 24, life: 0.8, radius: 0.3, color: 0xffd36a, d: 'Ném lá bài vàng về phía trước.' },
      { n: 'Time Card', type: 'projectile', cd: 5, dmg: 60, speed: 20, life: 1.1, radius: 0.6, count: 3, spread: 0.25, stun: 0.4, knock: 3, color: 0xb06bff, d: 'Tung 3 lá bài thời gian tỏa quạt.' },
      { n: 'Time Warp', type: 'aoe', cd: 10, dmg: 40, radius: 5, stun: 1.5, knock: 2, d: 'Bóp méo thời gian quanh người, làm choáng kẻ địch gần.' },
      { n: 'Dịch Pha', type: 'dash', cd: 8, dmg: 0, dist: 8, speed: 60, d: 'Dịch chuyển nhanh về phía trước.' },
      { n: 'Time Rewind', type: 'heal', cd: 40, amount: 300, dmg: 120, radius: 9, stun: 0.8, knock: 6, ult: true, d: 'Đảo ngược thời gian: hồi máu bản thân và đồng đội, đẩy lùi kẻ địch.' }
    ]
  }
};
