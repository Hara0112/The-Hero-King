// Mỗi tướng: skills[0]=đánh thường, [1..3]=kỹ năng, [4]=tuyệt chiêu (ult). d = mô tả hiển thị.
// Nguyên tắc cân bằng: cận chiến đánh nhanh nhưng phải áp sát; đánh xa sát thương thấp hơn; chiêu di chuyển
// sát thương thấp, hồi chiêu dài; khống chế (choáng/chậm) ngắn; ult hồi chiêu 45-60s.
export const HEROES = {
  asasin: {
    name: 'Asasin', role: 'Sát thủ Aether', color: 0x2aa8ff, hp: 900, speed: 7.2,
    stackMax: 15, stackDmg: 0.02, stackSpeed: 0.015,
    energy: { max: 1000, regen: 30, boostStacks: 5, boostMult: 3 },
    passive: 'Gia Tốc Aether: mỗi đòn trúng cộng 1 điểm Aether (tối đa 15, 5s không đánh thì tan): +2% sát thương và +1,5% tốc chạy mỗi điểm. Dòng Điện Quá Tải: từ 5 điểm trở lên, năng lượng hồi nhanh gấp 3 (+200%).',
    skills: [
      { n: 'Chém Song Kiếm', type: 'melee', combo: true, comboN: 4, cd: 0.45, dmg: 42, range: 2.6, arc: 1.7, knock: 1,
        d: 'Chém cận chiến, GIỮ nút để đánh liên tục: combo 4 nhát (nhát 4 mạnh hơn 60%, hất lùi). Mỗi nhát trúng cộng điểm Aether.' },
      { n: 'Lôi Vịnh Kích', type: 'dash', cd: 12, cost: 300, dist: 11, speed: 50, dmg: 110, trueDmg: true, shock: true, stun: 0.4, beamfx: true,
        d: 'Tốn 300 năng lượng. Lao xuyên 11m, cắt qua mọi kẻ địch trên đường: 110 SÁT THƯƠNG CHUẨN (bỏ qua giáp, khiên), giật lôi choáng 0,4s.' },
      { n: 'Thiên Huyền Bao', type: 'aoe', cd: 12, cost: 300, radius: 6.5, dmg: 120, float: 1.6, bubble: true,
        d: 'Tốn 300 năng lượng. Nổ quầng sáng Aether quanh người: 120 sát thương, kẻ địch bị nâng LƠ LỬNG bất động 1,6s (không gian bất động).' },
      { n: 'Móc Aether', type: 'hook', cd: 10, range: 22, free: 14, speed: 55, dmg: 40,
        d: 'Bắn móc kéo bản thân bay vút tới mục tiêu trong tầm ngắm (tối đa 22m, gây 40 sát thương, choáng nhẹ). Không có mục tiêu thì lao tới điểm ngắm 14m, bay qua mọi vật cản.' },
      { n: 'Bão Tố Cực Quang', type: 'aurora', cd: 100, dur: 10, tick: 0.5, radius: 7, dmg: 25, final: 160, ult: true,
        d: 'Trong 10s: BẤT TỬ, xóa sạch hiệu ứng xấu, miễn khống chế, chạy nhanh +30%, phóng sóng Aether mỗi 0,5s (25 sát thương, bán kính 7m); sóng cuối 160 sát thương hất văng.' }
    ]
  },
  // Time Clown – Hề Thời Gian (pháp sư / sát thủ)
  timeclown: {
    name: 'Time Clown', role: 'Pháp sư / Sát thủ', color: 0xb06bff, hp: 850, speed: 6.6,
    curse: { dur: 1.5, mult: 0.75 },
    passive: 'Nguyền Rủa Thời Gian: mọi đòn trúng làm mục tiêu chậm 25% trong 1,5s (hiện vòng tím dưới chân).',
    skills: [
      { n: 'Ném Bài', type: 'projectile', card: true, cd: 0.55, dmg: 36, speed: 26, life: 0.75, radius: 0.35, color: 0xffd36a,
        d: 'Ném lá bài vàng xoay tít về phía trước (36 sát thương, tầm khoảng 19m).' },
      { n: 'Time Card', type: 'projectile', card: true, pierce: true, cd: 7, dmg: 90, speed: 22, life: 1.2, radius: 1.0, stun: 0.3, knock: 2, color: 0xffb400,
        d: 'Lá bài khổng lồ xuyên qua mọi kẻ địch trên đường bay, mỗi người trúng một lần (90 sát thương).' },
      { n: 'Time Warp', type: 'warp', cd: 14, offset: 7, radius: 5.5, dur: 3.5, slow: 0.6, haste: 1.2,
        d: 'Mở vùng xoáy thời gian 3,5s cách bạn 7m: kẻ địch bên trong chậm 40%, đồng đội bên trong nhanh thêm 20%.' },
      { n: 'Dịch Pha', type: 'dash', cd: 9, dmg: 0, dist: 9, speed: 70,
        d: 'Dịch chuyển nhanh 9m về phía trước để né chiêu hoặc kéo giãn khoảng cách.' },
      { n: 'Time Rewind', type: 'rewind', cd: 60, back: 4, radius: 8, dmg: 70, stun: 1.2, ult: true,
        d: 'Đóng băng kẻ địch trong 8m 1,2s (70 sát thương), quay ngược về vị trí và máu của 4s trước, hoàn lại hồi chiêu 4 kỹ năng đầu.' }
    ]
  },
  // ===== Đợt 1 của đội hình 15 tướng =====
  frostempress: {
    name: 'Frost Empress', role: 'Pháp sư băng', color: 0x7fd8ff, hp: 800, speed: 6.4,
    frost: { freeze: 1.0 }, curse: { dur: 1.5, mult: 0.85 },
    passive: 'Hàn Băng Tích Tụ: mỗi đòn trúng làm chậm 15% và cộng 1 lớp băng lên mục tiêu; đủ 3 lớp thì ĐÓNG BĂNG 1s.',
    skills: [
      { n: 'Băng Châm', type: 'projectile', blade: true, cd: 0.6, dmg: 34, speed: 26, life: 0.8, radius: 0.35, color: 0x9fe0ff, d: 'Bắn phi châm băng (34 sát thương).' },
      { n: 'Băng Tiễn', type: 'projectile', pierce: true, cd: 6, dmg: 80, speed: 24, life: 1.1, radius: 0.9, color: 0xbfefff, d: 'Mũi tên băng xuyên mọi kẻ địch (80 sát thương), mỗi người trúng cộng 1 lớp băng.' },
      { n: 'Tuyết Lở', type: 'aoe', cd: 11, offset: 5, radius: 6, dmg: 60, slowDur: 2.5, slowMult: 0.55, bubble: true, d: 'Tuyết lở cách 5m: 60 sát thương, làm chậm 45% trong 2,5s.' },
      { n: 'Gương Băng', type: 'buff', cd: 12, shield: 250, dur: 4, speed: 1.15, d: 'Khiên băng 250 máu và chạy nhanh +15% trong 4s.' },
      { n: 'Bão Tuyết Vĩnh Cửu', type: 'aoe', cd: 55, offset: 6, radius: 8, delay: 0.8, dmg: 200, stun: 1.8, bubble: true, ult: true, d: 'Sau 0,8s bão tuyết quét vùng 8m: 200 sát thương và đóng băng 1,8s.' }
    ]
  },
  crimsonsamurai: {
    name: 'Crimson Samurai', role: 'Kiếm sĩ', color: 0xe53935, hp: 1000, speed: 6.8, stackMax: 10, stackDmg: 0.03, stackSpeed: 0.01,
    passive: 'Khí Thế: mỗi đòn trúng cộng 1 điểm Khí Thế (tối đa 10, 5s không đánh thì tan): +3% sát thương, +1% tốc chạy mỗi điểm.',
    skills: [
      { n: 'Chém Katana', type: 'melee', combo: true, comboN: 3, cd: 0.55, dmg: 55, range: 3.0, arc: 1.9, knock: 1, d: 'Chém kiếm, GIỮ nút để chém liên tục: combo 3 nhát, nhát 3 mạnh hơn 60% và hất lùi.' },
      { n: 'Rút Kiếm', type: 'dash', cd: 8, dist: 8, speed: 40, dmg: 100, stun: 0.3, beamfx: true, nobolt: true, d: 'Lao 8m rút kiếm chém xuyên mọi kẻ địch trên đường (100 sát thương, choáng 0,3s).' },
      { n: 'Trảm Gió', type: 'projectile', blade: true, pierce: true, cd: 7, dmg: 85, speed: 22, life: 1.0, radius: 1.1, color: 0xff7043, d: 'Phát ra sóng kiếm xuyên qua kẻ địch (85 sát thương).' },
      { n: 'Huyết Chiến', type: 'buff', cd: 14, speed: 1.25, dmg: 1.25, dur: 5, d: 'Trong 5s: chạy nhanh +25%, sát thương +25%.' },
      { n: 'Nhất Thiểm', type: 'dash', cd: 50, dist: 14, speed: 70, dmg: 260, stun: 0.8, beamfx: true, nobolt: true, ult: true, d: 'Lướt một nhát xuyên 14m cực nhanh (260 sát thương, choáng 0,8s) qua cả hàng địch.' }
    ]
  },
  titanbrawler: {
    name: 'Titan Brawler', role: 'Võ sĩ trâu', color: 0xff8f00, hp: 1400, speed: 5.8, dr: 0.15, rage: 10, stackDmg: 0.04,
    passive: 'Nộ Khí: mỗi lần bị trúng đòn cộng 1 điểm Nộ (tối đa 10, 5s không bị đánh thì tan): +4% sát thương mỗi điểm. Giảm 15% sát thương nhận.',
    skills: [
      { n: 'Đấm Thép', type: 'melee', combo: true, comboN: 3, cd: 0.7, dmg: 60, range: 2.8, arc: 1.8, knock: 2, d: 'Đấm cận chiến, GIỮ nút để đấm liên tục: combo 3 nhát, nhát 3 hất văng.' },
      { n: 'Đấm Địa Chấn', type: 'aoe', cd: 9, radius: 5, dmg: 90, stun: 0.8, knock: 4, d: 'Đấm xuống đất: vùng 5m, 90 sát thương, choáng 0,8s, hất lùi.' },
      { n: 'Ném Đá', type: 'projectile', cd: 7, dmg: 110, speed: 16, life: 1.2, radius: 1.1, knock: 4, stun: 0.4, color: 0x8d6e63, d: 'Ném tảng đá lớn (110 sát thương, choáng 0,4s, hất lùi).' },
      { n: 'Giáp Đá', type: 'buff', cd: 14, shield: 400, dur: 5, speed: 1, d: 'Giáp đá hấp thụ 400 sát thương trong 5s.' },
      { n: 'Động Đất', type: 'aoe', cd: 60, radius: 9, delay: 0.6, dmg: 200, float: 1.5, knock: 3, ult: true, d: 'Sau 0,6s mặt đất nổ tung 9m: 200 sát thương, hất địch lơ lửng 1,5s.' }
    ]
  }
};

// ---- Quái vật cho chế độ Phiêu Lưu (không hiện ở màn chọn tướng) ----
const mobSkill = (type, range, cd) => type === 'projectile'
  ? { n: 'Bắn', type: 'projectile', cd, dmg: 10, speed: 20, life: 0.9, radius: 0.35, color: 0xffab40 }
  : { n: 'Đòn đánh', type: 'melee', cd, dmg: 10, range, arc: 1.8, knock: 1 };
const mob = (name, color, scale, speed, skill) => ({ mob: true, name, role: 'Quái', color, scale, hp: 200, speed, passive: '', skills: [skill, skill, skill, skill, skill] });
HEROES.mob_bandit = mob('Bandit', 0x8d6e63, 1.0, 4.6, mobSkill('melee', 2.2, 1.2));
HEROES.mob_monkey = mob('Khỉ Rừng', 0xa1887f, 0.9, 6.0, mobSkill('melee', 2.0, 0.9));
HEROES.mob_pirate = mob('Cướp Biển', 0xc62828, 1.05, 4.8, mobSkill('projectile', 0, 1.6));
HEROES.mob_gorilla = mob('Khỉ Đột', 0x546e7a, 1.4, 4.2, mobSkill('melee', 3.0, 1.4));
HEROES.mob_boss = mob('Vua Khỉ Đột', 0x6a1b9a, 2.1, 4.8, mobSkill('melee', 4.0, 1.6));
