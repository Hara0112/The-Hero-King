// Mỗi tướng: skills[0]=đánh thường, [1..3]=kỹ năng, [4]=tuyệt chiêu (ult). d = mô tả hiển thị.
// Nguyên tắc cân bằng: cận chiến đánh nhanh nhưng phải áp sát; đánh xa sát thương thấp hơn; chiêu di chuyển
// sát thương thấp, hồi chiêu dài; khống chế (choáng/chậm) ngắn; ult hồi chiêu 45-60s.
export const HEROES = {
  asasin: {
    name: 'Asasin', role: 'Sát thủ công nghệ', color: 0x2aa8ff, hp: 900, speed: 7.2, ls: 0.12, markBonus: 1.25,
    passive: 'Lưỡi Năng Lượng: hút 12% sát thương thành máu. Mục tiêu bị đánh dấu sẽ nhận thêm 25% từ đòn kế tiếp của Asasin (xóa dấu).',
    skills: [
      { n: 'Chém Song Kiếm', type: 'melee', combo: true, cd: 0.45, dmg: 42, range: 2.6, arc: 1.7, knock: 1,
        d: 'Chém cận chiến. Combo 3 nhát liên tiếp (trong 1,2s): nhát thứ 3 mạnh hơn 60%, hất lùi và choáng nhẹ.' },
      { n: 'Phi Tiêu Điện', type: 'projectile', blade: true, cd: 5, dmg: 32, speed: 28, life: 0.7, radius: 0.3, count: 3, spread: 0.3, mark: 3, color: 0x66ccff,
        d: 'Phóng 3 phi tiêu tỏa quạt (32 sát thương/phi tiêu) và ĐÁNH DẤU mục tiêu 3s: đòn kế tiếp gây thêm 25%.' },
      { n: 'Nhảy Mèo', type: 'leap', cd: 8, dist: 9, speed: 20, dmg: 60, radius: 3, stun: 0.4, knock: 3,
        d: 'Bật nhảy 9m qua tường, cột, cây. Tiếp đất gây 60 sát thương vùng, choáng 0,4s. Dùng để áp sát hoặc thoát hiểm.' },
      { n: 'Đạp Tường', type: 'dash', kick: true, cd: 10, dist: 5.5, speed: 34, dmg: 80, stun: 0.5, knock: 5,
        rebound: { dist: 6, speed: 24 },
        d: 'Lao tới đạp địch (80 sát thương, choáng 0,5s), tường lưới sáng hiện ra rồi bật ngược 6m ra sau để rút lui.' },
      { n: 'Bão Kiếm Chém', type: 'storm', cd: 45, wind: 0.5, dist: 8, speed: 45, rushDmg: 80, dmg: 230, range: 7, arc: 2.6,
        stun: 1, knock: 7, exec: 0.2, ult: true,
        d: 'Khoanh kiếm 0,5s (bị choáng thì hủy), lao 8m rồi chém vòng cung 230 sát thương. Kẻ địch dưới 20% máu bị xử tử.' }
    ]
  },
  // Time Clown – Hề Thời Gian (pháp sư / sát thủ)
  timeclown: {
    name: 'Time Clown', role: 'Pháp sư / Sát thủ', color: 0xb06bff, hp: 850, speed: 6.6,
    curse: { dur: 1.5, mult: 0.75 },
    passive: 'Nguyền Rủa Thời Gian: mọi đòn trúng làm mục tiêu chậm 25% trong 1,5s (hiện vòng tím dưới chân).',
    skills: [
      { n: 'Ném Bài', type: 'projectile', card: true, cd: 0.55, dmg: 36, speed: 26, life: 0.75, radius: 0.35, color: 0xffd36a,
        d: 'Ném lá bài vàng xoay tít về phía trước (36 sát thương, tầm khoảng 19m).' },
      { n: 'Time Card', type: 'projectile', card: true, pierce: true, cd: 7, dmg: 90, speed: 22, life: 1.2, radius: 1.0, stun: 0.3, knock: 2, color: 0xffb400,
        d: 'Lá bài khổng lồ xuyên qua mọi kẻ địch trên đường bay, mỗi người trúng một lần (90 sát thương).' },
      { n: 'Time Warp', type: 'warp', cd: 14, offset: 7, radius: 5.5, dur: 3.5, slow: 0.6, haste: 1.2,
        d: 'Mở vùng xoáy thời gian 3,5s cách bạn 7m: kẻ địch bên trong chậm 40%, đồng đội bên trong nhanh thêm 20%.' },
      { n: 'Dịch Pha', type: 'dash', cd: 9, dmg: 0, dist: 9, speed: 70,
        d: 'Dịch chuyển nhanh 9m về phía trước để né chiêu hoặc kéo giãn khoảng cách.' },
      { n: 'Time Rewind', type: 'rewind', cd: 60, back: 4, radius: 8, dmg: 70, stun: 1.2, ult: true,
        d: 'Đóng băng kẻ địch trong 8m 1,2s (70 sát thương), quay ngược về vị trí và máu của 4s trước, hoàn lại hồi chiêu 4 kỹ năng đầu.' }
    ]
  }
};
