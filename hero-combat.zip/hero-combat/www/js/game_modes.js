import { HEROES } from './hero_classes.js';
import { WORLD, TEAM_Z, FFA_R, sitePoints } from './arena.js';

export const MODES = {
  '1v1': { label: '1v1', teams: 2, per: 1, kills: 5, time: 180 },
  '2v2': { label: '2v2', teams: 2, per: 2, kills: 10, time: 240 },
  '3v3': { label: '3v3', teams: 2, per: 3, kills: 15, time: 300 },
  '4v4': { label: '4v4', teams: 2, per: 4, kills: 20, time: 300 },
  'ffa': { label: 'Hỗn Chiến', teams: 0, total: 8, kills: 10, time: 300 },
  'adv': { label: 'Phiêu Lưu', adv: true, teams: 1, per: 8, kills: 0, time: 99999 }
};

// ---- Chế độ Phiêu Lưu (kiểu Blox Fruits): trại quái theo cấp, nhiệm vụ, trùm, lên cấp + điểm chỉ số ----
export const LV_MAX = 50;
export const CAMPS = [
  { name: 'Bandit', hero: 'mob_bandit', lvl: 3, n: 6, minLvl: 1, need: 6 },
  { name: 'Khỉ Rừng', hero: 'mob_monkey', lvl: 12, n: 6, minLvl: 10, need: 8 },
  { name: 'Cướp Biển', hero: 'mob_pirate', lvl: 22, n: 6, minLvl: 20, need: 8 },
  { name: 'Khỉ Đột', hero: 'mob_gorilla', lvl: 30, n: 5, minLvl: 30, need: 6, boss: { name: 'Vua Khỉ Đột', hero: 'mob_boss', lvl: 40 } }
];
export const xpNeed = lvl => 100 + lvl * 70;
export function mobStats(lvl, boss) {
  return { hp: Math.round((120 + lvl * 45) * (boss ? 8 : 1)), dm: ((20 + lvl * 6) / 10) * (boss ? 2 : 1),
    xp: Math.round((20 + lvl * 6) * (boss ? 12 : 1)), beli: Math.round((8 + lvl * 4) * (boss ? 10 : 1)) };
}
export function questFor(lvl) {
  let idx = 0; CAMPS.forEach((c, i) => { if (c.minLvl <= lvl) idx = i; });
  return { camp: idx, need: CAMPS[idx].need, got: 0, xp: 150 + idx * 250, beli: 100 + idx * 200 };
}
export const TEAM_COLORS = [0x3b82f6, 0xef4444, 0x22c55e, 0xeab308, 0xa855f7, 0xf97316, 0x06b6d4, 0xec4899];
const TEAM_NAMES = ['Xanh', 'Đỏ'];

// Xếp người chơi thật + bot vào đội và vị trí xuất phát
export function assign(key, humans) {
  const M = MODES[key], total = M.teams ? M.teams * M.per : M.total;
  const keys = Object.keys(HEROES).filter(k => !HEROES[k].mob), out = [], cnt = {};
  if (M.adv) { // người chơi quanh quảng trường trung tâm (khu an toàn) + quái ở 4 trại
    const hs = humans.slice(0, 8);
    hs.forEach((h, i) => { const a = (i / Math.max(1, hs.length)) * Math.PI * 2; out.push({ id: h.id, name: h.name, hero: h.hero, bot: false, team: 0, x: Math.cos(a) * 4, z: 2 + Math.sin(a) * 4 }); });
    const sites = sitePoints();
    CAMPS.forEach((c, ci) => {
      const st0 = sites[ci];
      for (let k = 0; k < c.n; k++) {
        const a = (k / c.n) * Math.PI * 2, r = 6 + (k % 2) * 4, st = mobStats(c.lvl, false);
        out.push({ id: 'mob' + ci + '_' + k, name: c.name + ' Lv' + c.lvl, hero: c.hero, bot: false, mob: true, team: 99, x: st0.x + Math.cos(a) * r, z: st0.z + Math.sin(a) * r, lvl: c.lvl, camp: ci, mhp: st.hp, dmgMul: st.dm, xpv: st.xp, beliv: st.beli });
      }
      if (c.boss) { const st = mobStats(c.boss.lvl, true); out.push({ id: 'boss' + ci, name: c.boss.name + ' Lv' + c.boss.lvl, hero: c.boss.hero, bot: false, mob: true, boss: true, team: 99, x: st0.x, z: st0.z, lvl: c.boss.lvl, camp: ci, mhp: st.hp, dmgMul: st.dm, xpv: st.xp, beliv: st.beli }); }
    });
    return out;
  }
  for (let i = 0; i < total; i++) {
    const h = humans[i], team = M.teams ? i % M.teams : i;
    const n = cnt[team] = (cnt[team] || 0) + 1, idx = n - 1;
    let x, z;
    if (M.teams) { z = team === 0 ? TEAM_Z : -TEAM_Z; x = (idx - (M.per - 1) / 2) * 5; }
    else { const a = (i / total) * Math.PI * 2 + Math.PI / 6; x = Math.cos(a) * FFA_R; z = Math.sin(a) * FFA_R; }
    const info = h ? { id: h.id, name: h.name, hero: h.hero, bot: false }
      : { id: 'bot' + i, name: 'Bot ' + (i + 1), hero: keys[i % keys.length], bot: true };
    out.push({ ...info, team, x, z });
  }
  return out;
}

export function teamLabel(G, t) {
  if (MODES[G.mode].teams) return 'Đội ' + TEAM_NAMES[t];
  const p = [...G.players.values()].find(x => x.team == t);
  return p ? p.name : '?';
}

export function registerKill(G, v, s) {
  G.stats[v.id][1]++;
  if (s && s.team !== v.team) { G.stats[s.id][0]++; G.score[s.team] = (G.score[s.team] || 0) + 1; }
}

// Trả về chuỗi người thắng hoặc null nếu chưa kết thúc
export function checkEnd(G) {
  const M = MODES[G.mode];
  if (M.adv) return null; // Phiêu Lưu không có hồi kết
  let best = -1, bt = null, tie = false;
  for (const t in G.score) {
    const v = G.score[t];
    if (v > best) { best = v; bt = Number(t); tie = false; } else if (v === best) tie = true;
  }
  if (best >= M.kills && !tie) return teamLabel(G, bt) + ' chiến thắng!';
  if (G.time <= 0) return tie ? 'Hòa!' : teamLabel(G, bt) + ' chiến thắng!';
  return null;
}

export function scoreText(G) {
  const M = MODES[G.mode];
  if (M.adv) { const me = G.me; return me ? 'Lv ' + me.lvl + ' · XP ' + me.xp + '/' + xpNeed(me.lvl) + ' · ' + me.beli + ' Beli' : ''; }
  if (M.teams) return `Xanh ${G.score[0] || 0} : ${G.score[1] || 0} Đỏ (đến ${M.kills})`;
  const me = G.me && G.stats[G.me.id] ? G.stats[G.me.id][0] : 0;
  const top = Math.max(0, ...Object.values(G.score));
  return `Bạn ${me} hạ · Dẫn đầu ${top}/${M.kills}`;
}

// Vùng an toàn thu nhỏ dần về tâm bản đồ (ép người chơi gặp nhau trên bản đồ lớn)
export function zoneAt(G) {
  if (MODES[G.mode].adv) return { cx: 0, cz: 0, r: 99999 };
  const M = MODES[G.mode], el = M.time - G.time, T = M.time * 0.75;
  const tt = Math.max(0, Math.min(1, (el - 30) / (T - 30)));
  return { cx: 0, cz: 0, r: WORLD * 1.45 * (1 - tt) + Math.max(12, WORLD * 0.18) * tt };
}
