# ⚔ Apex Hero Arena

Game đấu tướng 3D (Three.js + PeerJS). Chế độ: 1v1, 2v2, 3v3, Hỗn Chiến. 4 tướng: Hiệp Sĩ, Pháp Sư, Sát Thủ, Thầy Tế (mỗi tướng 3 skill + ULT + nội tại).

## Chạy trên điện thoại (không cần PC)
1. Upload toàn bộ nội dung thư mục `www/` lên repo GitHub (đặt ở thư mục gốc hoặc `docs/`).
2. Repo → **Settings → Pages** → Deploy from branch → chọn `main` và thư mục `/ (root)` hoặc `/docs`.
3. Mở link `https://<user>.github.io/<repo>/` bằng Chrome/Safari.

## Chơi
- **Offline**: bấm "Chơi Offline" → bot lấp đầy đội.
- **Online**: một người bấm "Tạo phòng", gửi mã 5 số; người khác nhập mã → "Vào phòng". Chủ phòng bấm "Bắt đầu" (chỗ trống do bot lấp). Cần HTTPS + internet (PeerJS cloud để bắt tay WebRTC).

## Điều khiển
- Điện thoại: joystick trái, nút phải (Đánh, S1, S2, S3, ULT). Tự nhắm kẻ địch gần nhất.
- PC: WASD di chuyển, chuột nhắm, Click/Space = đánh, Q/E/R = skill, F = ULT.

## Kiến trúc
Host là trọng tài tính sát thương, client gửi vị trí/skill; host phát lại cho mọi người (mô hình sao qua PeerJS).

## Build APK (chỉ cần điện thoại)
1. Upload `hero-combat.zip` lên **thư mục gốc** repo GitHub.
2. Tạo file `.github/workflows/build-apk.yml` (Add file → Create new file), dán nội dung file `build-apk.yml`.
3. Tab **Actions** → "Build APK" → Run workflow. Xong tải artifact **ApexHeroArena-apk** → cài `app-debug.apk`.

## Bản đồ lớn (~2 km²)
- Thế giới 1400 x 1400 m (đổi `WORLD` trong `www/js/arena.js`: 500 ≈ 1 km², 700 ≈ 2 km², 870 ≈ 3 km²).
- Sân tàn tích ở trung tâm, 16 điểm tàn tích rải khắp nơi, đường lát đá nối các điểm, rừng dày/thưa, dải rừng bao quanh rìa.
- Hai đội xuất phát hai đầu bản đồ. **Vùng an toàn thu nhỏ dần** về tâm (ngoài vùng mất 4% máu/giây) để mọi người gặp nhau.
- Ngoài giao tranh 4 giây sẽ **chạy nhanh x1,9**. Có bản đồ nhỏ góc trái.
