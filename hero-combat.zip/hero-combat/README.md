# ⚔ Apex Hero Arena

Game đấu tướng 3D (Three.js + PeerJS). Chế độ: 1v1, 2v2, 3v3, Hỗn Chiến. 4 tướng: Hiệp Sĩ, Pháp Sư, Sát Thủ, Thầy Tế (mỗi tướng 3 skill + ULT + nội tại).

## Chạy trên điện thoại (không cần PC)
1. Upload toàn bộ nội dung thư mục `www/` lên repo GitHub (đặt ở thư mục gốc hoặc `docs/`).
2. Repo → **Settings → Pages** → Deploy from branch → chọn `main` và thư mục `/ (root)` hoặc `/docs`.
3. Mở link `https://<user>.github.io/<repo>/` bằng Chrome/Safari.

## Chơi
- **Offline**: bấm "Chơi Offline" → bot lấp đầy đội.
- **Online**: một người bấm "Tạo phòng", gửi mã 5 số; người khác nhập mã → "Vào phòng". Chủ phòng bấm "Bắt đầu" (chỗ trống do bot lấp). Cần HTTPS + internet (PeerJS cloud để bắt tay WebRTC).

## Điều khiển
- Điện thoại: joystick trái, nút phải (Đánh, S1, S2, S3, ULT). Tự nhắm kẻ địch gần nhất.
- PC: WASD di chuyển, chuột nhắm, Click/Space = đánh, Q/E/R = skill, F = ULT.

## Kiến trúc
Host là trọng tài tính sát thương, client gửi vị trí/skill; host phát lại cho mọi người (mô hình sao qua PeerJS).

## Build APK (chỉ cần điện thoại)
1. Upload `hero-combat.zip` lên **thư mục gốc** repo GitHub.
2. Tạo file `.github/workflows/build-apk.yml` (Add file → Create new file), dán nội dung file `build-apk.yml`.
3. Tab **Actions** → "Build APK" → Run workflow. Xong tải artifact **ApexHeroArena-apk** → cài `app-debug.apk`.

## Bản đồ (1 km² = 1000 x 1000 m)
- Thế giới 1000 x 1000 m (đổi `WORLD` trong `www/js/arena.js`: 500 = 1 km², 700 ≈ 2 km², 870 ≈ 3 km²).
- Sân tàn tích ở trung tâm, 16 điểm tàn tích rải khắp nơi, đường lát đá nối các điểm, rừng dày/thưa, dải rừng bao quanh rìa.
- Hai đội xuất phát hai đầu bản đồ. **Vùng an toàn thu nhỏ dần** về tâm (ngoài vùng mất 4% máu/giây) để mọi người gặp nhau.
- Ngoài giao tranh 4 giây sẽ **chạy nhanh x1,9**. Có bản đồ nhỏ góc trái.

## Hero
Đã xóa hero cũ. Hiện có **Asasin** (ninja công nghệ mặt nạ sọ, giáp carbon đen + neon xanh, khăn navy, katana sau lưng, 2 lưỡi kiếm năng lượng ở cổ tay). Skin 3D dựng bằng code trong `www/js/hero_models.js`; bộ chiêu trong `hero_classes.js` đang là tạm thời.

## Kỹ năng Asasin (theo bảng hoạt ảnh)
- **Chém Song Kiếm** – đánh thường cận chiến.
- **Nhảy Mèo** – bật nhảy qua tường/cột/cây, tiếp đất nổ vùng.
- **Đạp Tường** – lao tới đạp địch (tường lưới sáng) rồi bật ngược ra sau.
- **Chạy Ảnh** – tăng tốc x1,9 trong 4s, để lại tàn ảnh.
- **Bão Kiếm Chém (ult)** – khoanh kiếm 0,5s (bị choáng thì hủy) → rút katana lao tới → chém vòng cung xanh; địch dưới 25% máu bị xử tử (hiện đầu lâu).

## Góc nhìn thứ 3
Camera sau lưng nhân vật, lệch vai phải. Điện thoại: vuốt ngón tay ở vùng trống để xoay camera, joystick đi theo hướng camera, chiêu bắn theo tâm ngắm (tự hút vào địch gần tâm). PC: bấm vào màn hình để khóa chuột rồi di chuột xoay camera.

## Time Clown
Hề Thời Gian (pháp sư/sát thủ): mũ hề 3 sừng có chuông, áo khoác ca-rô đen/trắng/tím viền vàng, đồng hồ cát nổi, 3 lá bài bay quanh người, vòng đồng hồ vàng. Skin trong `hero_models.js`; bộ chiêu trong `hero_classes.js` đang tạm thời.

## Kỹ năng Time Clown
- **Nội tại – Nguyền Rủa Thời Gian:** mọi đòn trúng làm mục tiêu chậm 30% trong 2,5s (vòng tím dưới chân).
- **Ném Bài:** lá bài vàng xoay tít.
- **Time Card:** lá bài khổng lồ xuyên qua mọi kẻ địch trên đường bay.
- **Time Warp:** vùng xoáy thời gian 4s: địch chậm 55%, đồng đội nhanh thêm 25%.
- **Dịch Pha:** dịch chuyển nhanh.
- **Time Rewind (ult):** đóng băng địch quanh người 1,5s, quay ngược về vị trí + máu của 4s trước, hoàn lại hồi chiêu.

## Cân bằng & camera (cập nhật)
- Asasin: Chém 42 / 0,45s; Nhảy Mèo 8s; Đạp Tường 10s; Chạy Ảnh +50% tốc độ, +30% sát thương 4s (14s); Bão Kiếm Chém 45s, xử tử dưới 20% máu.
- Time Clown: nguyền chậm 25% / 1,5s; Time Card 7s; Time Warp 14s (địch chậm 40%); Time Rewind 60s.
- Camera: khoảng cách theo chiều cao hero, tự kéo sát khi có cây/tường phía sau, chuyển động mượt, nhắm bù lệch vai.

## Sân đấu 7-8 người
- Map thu gọn còn 160 x 160 m (`WORLD = 80` trong `www/js/arena.js`): sân tàn tích ở giữa, 4 cụm tàn tích đối xứng, rừng bao quanh.
- Chế độ: 1v1, 2v2, 3v3, **4v4** và **Hỗn chiến 8 người**. Vùng an toàn thu về bán kính 14 m; trận ngắn hơn (3-5 phút).

## Bộ chiêu Asasin (thiết kế lại)
- **Chém Song Kiếm:** combo 3 nhát (nhát 3 mạnh hơn 60%, hất lùi).
- **Phi Tiêu Điện:** 3 phi tiêu tỏa quạt, đánh dấu mục tiêu 3s (đòn kế tiếp +25%).
- **Nhảy Mèo:** bật qua vật cản, tiếp đất nổ vùng.
- **Đạp Tường:** lao đạp rồi bật ngược rút lui.
- **Bão Kiếm Chém (ult):** khoanh kiếm → lao tới → chém vòng cung, xử tử dưới 20% máu.

## Asasin – bộ chiêu theo ảnh AETHER_REAVER
- **Nội tại – Gia Tốc Aether / Dòng Điện Quá Tải:** mỗi đòn trúng +1 điểm Aether (tối đa 15): +2% sát thương, +1,5% tốc chạy; từ 5 điểm năng lượng hồi nhanh gấp 3.
- **Chém Song Kiếm:** combo 3 nhát.
- **Lôi Vịnh Kích (300 NL, 12s):** lao xuyên 11m, 110 sát thương chuẩn, giật lôi choáng.
- **Thiên Huyền Bao (300 NL, 12s):** nổ quầng Aether 120 sát thương, nâng địch lơ lửng bất động 1,6s.
- **Móc Aether (10s):** móc kéo bản thân bay tới mục tiêu/điểm ngắm, bay qua vật cản.
- **Bão Tố Cực Quang (ult, 100s):** 10s bất tử, xóa hiệu ứng xấu, sóng Aether mỗi 0,5s, sóng cuối hất văng.

## Phong cách hình ảnh (tham khảo game MOBA mobile, không dùng tài nguyên của ai)
Nhân vật dùng đổ bóng hoạt hình 3 bậc (cel-shading), viền đen quanh người, ánh sáng viền (rim-light) theo màu hero, đầu to hơn một chút, bóng đổ dưới chân; hạt hiệu ứng là các đốm sáng mềm cộng sáng.

## Chế độ Phiêu Lưu (kiểu Blox Fruits, co-op PvE)
- Chọn **Phiêu Lưu** ở menu: mọi người chơi cùng phe, quảng trường trung tâm là khu an toàn.
- 4 trại quái ở 4 cụm tàn tích: Bandit (Lv3), Khỉ Rừng (Lv12), Cướp Biển (Lv22, bắn xa), Khỉ Đột (Lv30) + trùm **Vua Khỉ Đột** (Lv40, hồi sinh sau 90s).
- Hạ quái nhận XP + Beli (mọi người trong 25m quanh quái đều nhận). Lên cấp (tối đa 50): +25 máu, +3% sát thương, +3 điểm chỉ số (Sinh lực / Sát thương / Tốc độ).
- Nhiệm vụ tự giao theo cấp (hạ N quái của trại tương ứng), hoàn thành nhận thêm XP + Beli. Chết mất 10% Beli. Ngoài giao tranh tự hồi 2% máu/giây.

## Cơ chế điều khiển kiểu Blox Fruits
- **Camera:** xoay tự do sau lưng (vuốt ngón tay / di chuột), zoom (chụm 2 ngón / lăn chuột), **khóa vai** (nút 🔒 / Shift): nhân vật luôn quay theo camera, camera lệch vai.
- **Di chuyển:** đi theo hướng camera; **Nhảy** (Space / nút Nhảy), bấm lần 2 trên không = **nhảy đôi**; nhảy qua tường thấp, **đứng được trên đỉnh tường/cột**; **Lướt** (Q / nút Lướt, hồi 2,5s).
- **Chiến đấu:** **giữ** nút Đánh (hoặc chuột trái / J) để đánh liên tục, combo nhiều nhát nhát cuối hất lùi; chiêu Z/X/C, ult V/F; nhắm theo tâm ngắm; hiện số sát thương, nhân vật nhấp nháy khi trúng, màn hình rung khi bị đánh, quái thường bị khựng khi trúng đòn.

## Đội hình 15 tướng – đợt 1
Frost Empress (pháp sư băng, 3 lớp băng thì đóng băng), Crimson Samurai (kiếm sĩ, tích Khí Thế), Titan Brawler (võ sĩ trâu, bị đánh thì tích Nộ). Dựng bằng khung `rig()` trong `hero_models.js` nên thêm tướng mới nhanh.
